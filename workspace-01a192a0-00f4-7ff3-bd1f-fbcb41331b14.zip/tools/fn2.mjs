import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('PAGEERR',e.message));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
console.log('HUNT', JSON.stringify(await page.evaluate(()=>{
  const g=window.__HF_GAME,p=g.player; p.runTime=20;
  const st={}; let dmg=0; const hp0=p.hp;
  for(let i=0;i<60*45;i++){ g.update(1/60); for(const f of g.fish.fish) if(f.alive) st[f.state]=(st[f.state]||0)+1; }
  return {st, dmg:hp0-p.hp, hunters:g.fish.fish.filter(f=>['chase','windup','lunge'].includes(f.state)).length};
})));
console.log('CANNON', JSON.stringify(await page.evaluate(()=>{
  const g=window.__HF_GAME,p=g.player;
  window.__HF.setSize(20);
  const c=g.entities.targets.find(t=>t.kind==='cruiser');
  p.pos.set(c.x+60,-3,c.z+40); p.maxHp=2000;p.hp=2000;
  for(let i=0;i<60*40;i++) g.update(1/60);
  return {shots:g.entities.cannonShots||0, bombs:g.entities.bombs.length, shells:g.entities.shells.length, harp:g.entities.harpoons.length, dmg:2000-p.hp, depth:+p.depth.toFixed(1)};
})));
await page.screenshot({path:'shots/fn-cruiser2.png'});
await browser.close();
