import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('ERR',e.message));
page.on('console',m=>{ if(m.type()==='error'&&!m.text().includes('404')) console.log('CONSOLE', m.text().slice(0,300)); });
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
const snap = async (label) => {
  const i = await page.evaluate(()=>window.__HF.info());
  console.log(label, JSON.stringify({t:+i.time.toFixed(0), size:+i.size.toFixed(2), eaten:i.eaten, lvl:i.level, pts:i.points, hp:+i.hp.toFixed(0), depth:+i.depth.toFixed(0), fish:i.fishCount, bombs:i.bombs, shells:i.shells, chests:i.chests, calls:i.drawCalls, tris:i.triangles}));
};
await page.evaluate(()=>window.__HF.simulate(30));
await snap('after 30s');
await page.evaluate(()=>window.__HF.simulate(60));
await snap('after 90s');
// тест роста до крупных размеров
await page.evaluate(()=>{ window.__HF.setSize(10); });
await page.evaluate(()=>window.__HF.simulate(20));
await snap('L=10 20s');
await page.screenshot({path:'shots/sim-L10.png'});
await page.evaluate(()=>{ window.__HF.setSize(60); window.__HF.tp(1500,-60,0); });
await page.evaluate(()=>window.__HF.simulate(30));
await snap('L=60 30s');
await page.screenshot({path:'shots/sim-L60.png'});
await page.evaluate(()=>{ window.__HF.setSize(140); window.__HF.tp(2100,-110,0); });
await page.evaluate(()=>window.__HF.simulate(40));
await snap('L=140 40s');
await page.screenshot({path:'shots/sim-L140.png'});
// уровни/улучшения
const upg = await page.evaluate(()=>{ const g=window.__HF_GAME; const p=g.player; p.points=5; const before=p.permSize; const ok1=p.buy('size'); const ok2=p.buy('hp'); p.buy('speed'); g.ui.updateHUD(); return {ok1,ok2,before,after:p.permSize,maxHp:p.maxHp,hp:p.hp,upg:p.upg,pts:p.points}; });
console.log('upgrades', JSON.stringify(upg));
await page.screenshot({path:'shots/sim-after-upg.png'});
await browser.close();
