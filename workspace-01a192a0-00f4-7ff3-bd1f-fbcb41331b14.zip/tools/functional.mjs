import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('PAGEERR',e.message));
page.on('console',m=>{ if(m.type()==='error'&&!m.text().includes('404')) console.log('CONSOLE', m.text().slice(0,300)); });
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
const log = (...a)=>console.log(...a);

// 1. хищники атакуют
log('--- хищники');
const hunt = await page.evaluate(()=>{
  const g=window.__HF_GAME, p=g.player;
  p.runTime=10;
  const res={states:{},damage:0};
  for(let i=0;i<60*40;i++){
    g.update(1/60);
    for(const f of g.fish.fish) if(f.alive) res.states[f.state]=(res.states[f.state]||0)+1;
  }
  res.hp=p.hp; res.damage=100-p.hp;
  res.hunting = g.fish.fish.filter(f=>['chase','windup','lunge'].includes(f.state)).length;
  return res;
});
log(JSON.stringify(hunt));

// 2. оружие крейсера
log('--- крейсер');
const weap = await page.evaluate(()=>{
  const g=window.__HF_GAME, p=g.player;
  window.__HF.setSize(8);
  const cruiser = g.entities.targets.find(t=>t.kind==='cruiser');
  p.pos.set(cruiser.x+40, -6, cruiser.z+30); p.hp=400; p.maxHp=400; p.god=false;
  let maxBombs=0,maxShells=0,maxHarp=0,dmg=0;
  const startHp=p.hp;
  for(let i=0;i<60*30;i++){ g.update(1/60); maxBombs=Math.max(maxBombs,g.entities.bombs.length); maxShells=Math.max(maxShells,g.entities.shells.length); maxHarp=Math.max(maxHarp,g.entities.harpoons.length); }
  return {maxBombs,maxShells,maxHarp, dmg:startHp-p.hp, hp:p.hp, cages:g.entities.cages.length, alive:!p.dead};
});
log(JSON.stringify(weap));
await page.screenshot({path:'shots/fn-cruiser.png'});

// 3. сундук
log('--- сундук');
const chest = await page.evaluate(()=>{
  const g=window.__HF_GAME, p=g.player;
  const c=g.entities.chests[0];
  p.hp=p.maxHp*0.5;
  p.pos.set(c.x, c.y, c.z);
  const before={hp:p.hp,size:p.permSize,xp:p.xp,speed:p.tempSpeed,ts:p.tempSize};
  for(let i=0;i<60*3;i++) g.update(1/60);
  return {before, after:{hp:p.hp,size:p.permSize,xp:p.xp,speed:p.tempSpeed,ts:p.tempSize}, chests:g.entities.chests.length, opened:c.opened};
});
log(JSON.stringify(chest));

// 4. победа
log('--- победа');
const win = await page.evaluate(async ()=>{
  const g=window.__HF_GAME, p=g.player;
  window.__HF.setSize(140);
  const cruiser = g.entities.targets.find(t=>t.kind==='cruiser');
  p.pos.set(cruiser.x, -1, cruiser.z);
  for(let i=0;i<60*4;i++) g.update(1/60);
  await new Promise(r=>setTimeout(r,700));
  return {state:g.state, victoryShown:g.victoryShown, eaten:p.eaten, cruiserAlive:!!g.entities.targets.find(t=>t.kind==='cruiser')};
});
log(JSON.stringify(win));
await page.screenshot({path:'shots/fn-victory.png'});

// 5. смерть
log('--- смерть');
const dead = await page.evaluate(async ()=>{
  const g=window.__HF_GAME, p=g.player;
  window.__HF.start();
  p.hp=5;
  for(let i=0;i<60*2;i++) g.update(1/60);
  const hurt = p.damage(200,'Тест');
  await new Promise(r=>setTimeout(r,1800));
  return {hurt, hp:p.hp, dead:p.dead, state:g.state};
});
log(JSON.stringify(dead));
await page.screenshot({path:'shots/fn-dead.png'});

// 6. прокачка: уровни, очки, покупки, стадии
log('--- прогресс');
const prog = await page.evaluate(()=>{
  const g=window.__HF_GAME, p=g.player;
  window.__HF.start();
  const out=[];
  for(let k=0;k<6;k++){
    window.__HF.setSize([1,2,3,8,30,80][k]);
    out.push({L:+p.permSize.toFixed(2), stage:g.ui.el.stage.textContent, goal:g.ui.el.goalname.textContent});
  }
  const xpTest = p.addXp(16);
  return {out, ups:xpTest, lvl:p.level, pts:p.points};
});
log(JSON.stringify(prog));
await browser.close();
