import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
await page.evaluateOnNewDocument(()=>{
  window.__errs=[];
  const ce=console.error, cw=console.warn;
  console.error=(...a)=>{ window.__errs.push(a.map(x=>{try{return typeof x==='string'?x:JSON.stringify(x)}catch(e){return String(x)}}).join(' ')); ce.apply(console,a); };
  console.warn=(...a)=>{ window.__errs.push('WARN '+a.map(x=>{try{return typeof x==='string'?x:JSON.stringify(x)}catch(e){return String(x)}}).join(' ')); cw.apply(console,a); };
});
page.on('pageerror', e=>console.log('[pageerror]', e.message));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await new Promise(r=>setTimeout(r,4000));
const errs = await page.evaluate(()=>window.__errs);
console.log(errs.join('\n---\n').slice(0,7000));
await browser.close();
