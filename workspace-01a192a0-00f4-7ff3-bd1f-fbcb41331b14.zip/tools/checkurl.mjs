import puppeteer from 'puppeteer';
const url = process.argv[2];
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
const errs=[];
page.on('pageerror',e=>errs.push('pageerror: '+e.message));
page.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text().slice(0,200));});
page.on('response',r=>{ if(r.status()>=400) errs.push(`http ${r.status()} ${r.url()}`); });
await page.goto(url,{waitUntil:'load',timeout:90000});
try { await page.waitForFunction('window.__HF_READY===true',{timeout:60000}); } catch(e){ errs.push('NOT READY'); }
await new Promise(r=>setTimeout(r,1500));
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
await new Promise(r=>setTimeout(r,3000));
await page.screenshot({path:'shots/prod-url.png'});
console.log('INFO', JSON.stringify(await page.evaluate(()=>window.__HF.info())));
console.log('ERRORS', JSON.stringify([...new Set(errs)]));
await browser.close();
