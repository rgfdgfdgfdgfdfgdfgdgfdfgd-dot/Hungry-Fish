import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('ERR',e.message));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
await new Promise(r=>setTimeout(r,2000));
console.log(await page.evaluate(()=>{
  const g=window.__HF_GAME;
  const near = g.fish.fish.slice(0,6).map(f=>({sp:f.species,size:+f.size.toFixed(2),pos:f.pos.toArray().map(v=>+v.toFixed(1)),state:f.state,alive:f.alive,tut:!!f.tutorial}));
  const meshCounts = Object.entries(g.fish.meshes).map(([k,m])=>k+':'+m.count).join(' ');
  const cam = g.camera.position.toArray().map(v=>+v.toFixed(2));
  const p = g.player.pos.toArray().map(v=>+v.toFixed(2));
  const proj = (()=>{ const f=g.fish.fish[0]; const v=f.pos.clone().project(g.camera); return [Math.round((v.x*0.5+0.5)*1280), Math.round((-v.y*0.5+0.5)*720)]; })();
  return JSON.stringify({near, meshCounts, cam, p, proj});
}));
await browser.close();
