import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('ERR',e.message));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
console.log(await page.evaluate(()=>{
  const g=window.__HF_GAME, p=g.player;
  window.__HF.setSize(60);
  window.__HF.tp(1500,-60,0);
  const out=[];
  for(let i=0;i<6;i++){
    g.update(1/60);
    out.push({y:+p.pos.y.toFixed(1), x:+p.pos.x.toFixed(0), z:+p.pos.z.toFixed(0), L:+p.curSize.toFixed(0), bottom:+(-g.world.terrainDepthAt? 0:0), td:+((()=>{ const {terrainDepth}=window.__HF_GAME; return 0;})()), worldL:+g.world.L.toFixed(1)});
  }
  const td = (()=>{ try { return eval('0') } catch(e){ return 0 } })();
  return JSON.stringify({out, depthNow:+p.pos.y.toFixed(1)});
}));
console.log(await page.evaluate(()=>{
  const g=window.__HF_GAME, p=g.player;
  const m = window.__hfmod;
  return JSON.stringify({L:g.world.L, pos:p.pos.toArray().map(v=>+v.toFixed(1)), cam:g.camera.position.toArray().map(v=>+v.toFixed(1)), far:g.camera.far});
}));
await browser.close();
