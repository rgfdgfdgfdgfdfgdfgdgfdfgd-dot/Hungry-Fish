import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror', e=>console.log('[pageerror]', e.message, (e.stack||'').split('\n').slice(0,8).join('\n')));
page.on('console', m=>console.log('[console]', m.text()));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await new Promise(r=>setTimeout(r,3000));
const txt = await page.evaluate(()=>document.body.innerText.slice(-500));
console.log('BODY:', txt);
const res = await page.evaluate(async ()=>{
  try {
    const mod = await import('/src/game.js');
    const g = new mod.Game(document.getElementById('game'));
    return 'ok';
  } catch(e) { return 'ERR: '+(e && e.message)+'\n'+(e && e.stack||'').split('\n').slice(0,8).join('\n'); }
});
console.log(res);
await browser.close();
