// Приёмка по кадрам и измерениям (раздел 11 WORLD_QUALITY.md).
// Запуск: node tools/verify.mjs [url]
import puppeteer from 'puppeteer';
import { PNG } from 'pngjs';
import fs from 'node:fs';
import path from 'node:path';

const URL = process.argv[2] || 'http://127.0.0.1:5173/';
const OUT = 'shots';
fs.mkdirSync(OUT, { recursive: true });

const V = (L) => Math.min(4000, 55 + 22 * L);
const D = (L) => 2.4 * L + 1.4;

const browser = await puppeteer.launch({
  headless: 'new',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle', '--use-angle=swiftshader',
    '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
});

const results = { shots: [], checks: {}, info: {}, errors: [] };

async function makePage(w, h, dpr) {
  const page = await browser.newPage();
  if (w < h) {
    await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1');
    await page.setViewport({ width: w, height: h, deviceScaleFactor: dpr, isMobile: true, hasTouch: true });
  } else {
    await page.setViewport({ width: w, height: h, deviceScaleFactor: dpr });
  }
  page.on('pageerror', e => results.errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') results.errors.push('console: ' + m.text()); });
  await page.goto(URL, { waitUntil: 'load', timeout: 90000 });
  await page.waitForFunction('window.__HF_READY === true', { timeout: 90000 });
  await page.evaluate(() => { document.getElementById('menu').classList.add('hidden'); window.__HF.start(); });
  await sleep(600);
  return page;
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function shot(page, name) {
  await sleep(700);
  const file = path.join(OUT, name + '.png');
  await page.screenshot({ path: file });
  // чистый кадр без интерфейса — для измерений A1/A2
  const data = await page.evaluate(() => window.__HF.snapshot());
  const raw = Buffer.from(data.split(',')[1], 'base64');
  const cleanFile = path.join(OUT, name + '-clean.png');
  fs.writeFileSync(cleanFile, raw);
  return cleanFile;
}

function analyze(file) {
  const png = PNG.sync.read(fs.readFileSync(file));
  const { width: w, height: h, data } = png;
  const lum = (x, y) => {
    const i = (y * w + x) * 4;
    return (0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2]) / 255;
  };
  // A2: яркость нижней половины
  let bright = 0, sum = 0, cnt = 0;
  const y0 = Math.floor(h * 0.5);
  for (let y = y0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const l = lum(x, y);
      sum += l; cnt++;
      if (l > 0.92) bright++;
    }
  }
  // A1: разрыв "горизонта" — сравнение строки выше/ниже на 4 пикселя
  let worstRow = -1, worstFrac = 0;
  for (let y = 10; y < h - 10; y += 2) {
    let hit = 0, total = 0;
    for (let x = 2; x < w - 2; x += 2) {
      const a = lum(x, y - 4), b = lum(x, y + 4);
      const rel = Math.abs(a - b) / Math.max(0.02, Math.max(a, b));
      total++;
      if (rel > 0.25) hit++;
    }
    const frac = hit / total;
    if (frac > worstFrac) { worstFrac = frac; worstRow = y; }
  }
  return {
    meanBottom: sum / cnt,
    brightFrac: bright / cnt,
    horizonRow: worstRow,
    horizonFrac: worstFrac,
    width: w, height: h,
  };
}

const states = [
  { id: 'S1', prep: null, desc: 'старт, L=0.78' },
  { id: 'S2', prep: () => { window.__HF.setSize(2); window.__HF.tp(120, -16, 0); }, desc: 'риф, L=2, 120 м' },
  { id: 'S3', prep: () => { window.__HF.setSize(2); window.__HF.tp(60, -4, 40); }, desc: 'у поверхности, L=2, 4 м' },
  { id: 'S4', prep: () => { window.__HF.setSize(6); window.__HF.tp(600, -34, 0); }, desc: 'поля, L=6, 600 м' },
  { id: 'S5', prep: () => { window.__HF.setSize(6); window.__HF.tp(600, 1.5, 0); }, desc: 'над водой, L=6' },
  { id: 'S6', prep: () => { window.__HF.setSize(20); window.__HF.tp(1300, -70, 0); }, desc: 'склон, L=20, 70 м' },
  { id: 'S7', prep: () => { window.__HF.setSize(60); window.__HF.tp(2000, -100, 0); }, desc: 'океан, L=60, 100 м' },
  { id: 'S8', prep: () => { window.__HF.setSize(140); window.__HF.tp(2200, -120, 0); }, desc: 'океан, L=140, 120 м' },
];

for (const vp of [{ name: 'desktop', w: 1280, h: 720, dpr: 1 }, { name: 'mobile', w: 390, h: 844, dpr: 2 }]) {
  const page = await makePage(vp.w, vp.h, vp.dpr);
  for (const st of states) {
    if (st.prep) await page.evaluate(st.prep);
    await sleep(st.id === 'S1' ? 3000 : 900);
    const file = await shot(page, `${st.id}-${vp.name}`);
    const info = await page.evaluate(() => window.__HF.info());
    const px = analyze(file);
    results.shots.push({ id: st.id, viewport: vp.name, file, desc: st.desc, info, px });
    results.info[st.id + '-' + vp.name] = info;
  }
  // S1: камера не под дном за 60 с симуляции + рельеф у старта
  await page.evaluate(() => { window.__HF.start(); });
  results.camCheck = await page.evaluate(() => window.__HF.camCheck(60));
  results.relief = await page.evaluate(() => window.__HF.relief(0, 0, 60, 180));
  // модели
  results.models = await page.evaluate(() => {
    const g = window.__HF_GAME;
    const fish = {};
    for (const id of Object.keys(g.fish.geos)) fish[id] = g.fish.geos[id].index.count / 3;
    const decor = {};
    for (const [id, arr] of g.world.decor.protos) decor[id] = Math.max(...arr.map(x => x.index.count / 3));
    return { fish, decor, player: g.playerMesh.geometry.index.count / 3 };
  });
  // A9: пересечения на телефоне
  if (vp.name === 'mobile') {
    await page.evaluate(() => { window.__HF.start(); });
    await page.evaluate(() => { window.__HF_GAME.ui.message('Проверка', 'подсказка', ''); window.__HF_GAME.ui.hint('Проверка подсказки'); });
    await sleep(600);
    results.overlap = await page.evaluate(() => {
      const rects = (sel) => Array.from(document.querySelectorAll(sel)).filter(e => e.offsetParent !== null)
        .map(e => ({ sel, r: e.getBoundingClientRect() })).filter(o => o.r.width > 0 && o.r.height > 0);
      const ui = [...rects('.msg'), ...rects('.hint'), ...rects('.goal'), ...rects('#msgs')];
      const ctl = [...rects('#joystick'), ...rects('#btn-boost'), ...rects('#btn-up'), ...rects('#btn-down'), ...rects('.goal')];
      const inter = (a, b) => !(a.right <= b.left || a.left >= b.right || a.bottom <= b.top || a.top >= b.bottom);
      const hits = [];
      for (const u of ui) for (const c of ctl) {
        if (u.sel === '.goal' && c.sel === '.goal') continue;
        if (inter(u.r, c.r)) hits.push({ ui: u.sel, ctl: c.sel, uiRect: [u.r.left, u.r.top, u.r.right, u.r.bottom], ctlRect: [c.r.left, c.r.top, c.r.right, c.r.bottom] });
      }
      return { hits, ui: ui.map(u => ({ sel: u.sel, r: [u.r.left, u.r.top, u.r.right, u.r.bottom] })), ctl: ctl.map(u => ({ sel: u.sel, r: [u.r.left, u.r.top, u.r.right, u.r.bottom] })) };
    });
  }
  await page.close();
}

// ---- проверки ----
const byId = (id, vp) => results.shots.find(s => s.id === id && s.viewport === vp);
const checks = {};
const d1 = byId('S1', 'desktop');
const m1 = byId('S1', 'mobile');
checks.A1 = {
  pass: [d1, m1].every(s => s.id === 'S5' || s.px.horizonFrac < 0.6),
  detail: results.shots.filter(s => s.id !== 'S5').map(s => `${s.id}-${s.viewport}: max ${(s.px.horizonFrac * 100).toFixed(0)}% на строке ${s.px.horizonRow}`),
};
checks.A2 = {
  pass: results.shots.every(s => s.px.brightFrac <= 0.01 && s.px.meanBottom >= 0.35 && s.px.meanBottom <= 0.70),
  detail: results.shots.map(s => `${s.id}-${s.viewport}: яркость низа ${(s.px.meanBottom * 100).toFixed(0)}%, пересвет ${(s.px.brightFrac * 100).toFixed(2)}%`),
};
checks.A3 = {
  pass: d1.info.decorWithin[5] >= 10 && d1.info.decorWithin[10] >= 40 && d1.info.decorWithin[20] >= 100 && d1.info.decorWithin[40] >= 250 &&
        m1.info.decorWithin[5] >= 6 && m1.info.decorWithin[10] >= 24 && m1.info.decorWithin[20] >= 60 && m1.info.decorWithin[40] >= 150,
  detail: `desktop ${JSON.stringify(d1.info.decorWithin)}, mobile ${JSON.stringify(m1.info.decorWithin)}`,
};
checks.A4 = { pass: results.relief.range >= 10, detail: `перепад дна в радиусе 60 м: ${results.relief.range.toFixed(1)} м (min ${results.relief.min.toFixed(1)}, max ${results.relief.max.toFixed(1)})` };
checks.A5 = {
  pass: results.shots.filter(s => s.id !== 'S5').every(s => {
    const L = s.info.size;
    return Math.abs(s.info.fogFar - V(L)) <= 0.2 * V(L) && s.info.fogNear <= 0.1 * V(L);
  }),
  detail: results.shots.filter(s => s.id !== 'S5').map(s => {
    const L = s.info.size;
    return `${s.id}-${s.viewport}: fogFar ${s.info.fogFar.toFixed(0)} / V ${V(L).toFixed(0)}, near ${s.info.fogNear.toFixed(1)}`;
  }).concat(['S5 (над водой): воздушный туман 900–3500 м']),
};
checks.A6 = {
  pass: results.shots.every(s => Math.abs(s.info.camDist - D(s.info.size)) <= 0.25 * D(s.info.size)) && (results.camCheck?.bad === 0),
  detail: results.shots.map(s => `${s.id}-${s.viewport}: camDist ${s.info.camDist.toFixed(2)} / D ${D(s.info.size).toFixed(2)}`) + ` camCheck ${JSON.stringify(results.camCheck)}`,
};
checks.A7 = {
  pass: Object.values(results.models.fish).every(v => v >= 360 && v <= 800) && Object.values(results.models.decor).every(v => v <= 300),
  detail: JSON.stringify(results.models),
};
checks.A8 = {
  pass: d1.info.drawCalls <= 60 && d1.info.triangles <= 150000,
  detail: `drawCalls ${d1.info.drawCalls}, triangles ${d1.info.triangles}`,
};
checks.A9 = {
  pass: (results.overlap?.hits?.length || 0) === 0,
  detail: JSON.stringify(results.overlap?.hits || []),
};
results.checks = checks;
results.errors = [...new Set(results.errors)].filter(e => !e.includes('favicon'));

fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify(results, null, 1));
const lines = Object.entries(checks).map(([k, v]) => `${k}: ${v.pass ? 'PASS' : 'FAIL'} — ${Array.isArray(v.detail) ? v.detail.join(' | ') : v.detail}`);
console.log(lines.join('\n'));
console.log('ERRORS:', results.errors.slice(0, 5));
await browser.close();
