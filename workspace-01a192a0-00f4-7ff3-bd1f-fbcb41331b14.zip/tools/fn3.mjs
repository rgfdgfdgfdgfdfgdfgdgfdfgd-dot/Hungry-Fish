import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('PAGEERR',e.message));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
console.log(JSON.stringify(await page.evaluate(()=>{
  const g=window.__HF_GAME,p=g.player; p.runTime=20;
  const threats0 = g.fish.fish.filter(f=>f.alive&&f.size>p.curSize*1.05).length;
  const tracker=[];
  for(let i=0;i<60*40;i++){ g.update(1/60);
    if(i%600===0){
      const th=g.fish.fish.filter(f=>f.alive&&f.size>p.curSize*1.05);
      tracker.push({t:i/60, n:th.length, minD:+Math.min(...th.map(f=>f.pos.distanceTo(p.pos))).toFixed(1), allow:g.allowHunt(), grace:th.length?+th[0].spawnGrace.toFixed(1):0, state:th.length?th[0].state:'-', size:th.length?+th[0].size.toFixed(2):0});
    }
  }
  return {threats0, tracker};
})));
await browser.close();
