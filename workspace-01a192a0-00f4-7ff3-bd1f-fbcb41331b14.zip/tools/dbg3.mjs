import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('ERR',e.message));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
await page.evaluate(()=>{ window.__HF.setSize(60); window.__HF.tp(1500,-60,0); });
await new Promise(r=>setTimeout(r,2500));
console.log(await page.evaluate(()=>{
  const g=window.__HF_GAME,p=g.player;
  const v=p.pos.clone().project(g.camera);
  return JSON.stringify({pos:p.pos.toArray().map(x=>+x.toFixed(1)), cam:g.camera.position.toArray().map(x=>+x.toFixed(1)),
    screen:[Math.round((v.x*0.5+0.5)*1280), Math.round((-v.y*0.5+0.5)*720), +v.z.toFixed(3)],
    meshVisible:g.playerMesh.visible, meshScale:g.playerMesh.scale.x, meshPos:g.playerMesh.position.toArray().map(x=>+x.toFixed(1)),
    camY:g.camera.position.y, fog:[g.scene.fog.near, g.scene.fog.far], state:g.state});
}));
await page.screenshot({path:'shots/dbg-L60.png'});
await browser.close();
