import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('ERR',e.message));
page.on('console',m=>{ if(m.type()==='error') console.log('CONSOLE', m.text().slice(0,200)); });
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
await new Promise(r=>setTimeout(r,500));
await page.keyboard.down('w');
for (let i=0;i<10;i++){
  await new Promise(r=>setTimeout(r,2000));
  const info = await page.evaluate(()=>window.__HF.info());
  console.log(i, JSON.stringify({t:+info.time.toFixed(1), size:+info.size.toFixed(2), eaten:info.eaten, lvl:info.level, xp:+info.xp.toFixed(0), pts:info.points, hp:+info.hp.toFixed(0), huntFish:info.fishCount, calls:info.drawCalls, tris:info.triangles, fps:+info.fps.toFixed(0)}));
}
await page.keyboard.up('w');
await page.screenshot({path:'shots/play.png'});
await browser.close();
