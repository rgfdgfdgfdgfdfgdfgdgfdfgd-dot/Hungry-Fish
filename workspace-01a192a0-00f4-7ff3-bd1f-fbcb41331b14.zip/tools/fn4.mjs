import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const page = await browser.newPage();
await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
page.on('pageerror',e=>console.log('PAGEERR',e.message));
await page.goto('http://127.0.0.1:5173/',{waitUntil:'load'});
await page.waitForFunction('window.__HF_READY===true');
await page.evaluate(()=>{document.getElementById('menu').classList.add('hidden'); window.__HF.start();});
console.log('CANNON', JSON.stringify(await page.evaluate(()=>{
  const g=window.__HF_GAME,p=g.player;
  window.__HF.setSize(20);
  const c=g.entities.targets.find(t=>t.kind==='cruiser');
  p.maxHp=2000;p.hp=2000;
  let maxS=0,maxB=0,maxH=0;
  for(let i=0;i<60*40;i++){
    p.pos.set(c.x+70,-1.5,c.z+40);   // держим у поверхности
    g.update(1/60);
    maxS=Math.max(maxS,g.entities.shells.length); maxB=Math.max(maxB,g.entities.bombs.length); maxH=Math.max(maxH,g.entities.harpoons.length);
  }
  return {shots:g.entities.cannonShots||0, maxBomb:maxB, maxShell:maxS, maxHarp:maxH, dmg:2000-p.hp};
})));
await page.screenshot({path:'shots/fn-cruiser3.png'});
await browser.close();
