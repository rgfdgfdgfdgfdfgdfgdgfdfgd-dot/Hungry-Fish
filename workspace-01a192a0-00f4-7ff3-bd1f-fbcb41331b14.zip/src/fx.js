// Частицы и эффекты: поедание, взрывы, пузыри, искры сундука, всплески.
import * as THREE from 'three';

const MAX = 900;

export class FX {
  constructor(scene) {
    this.pos = new Float32Array(MAX * 3);
    this.col = new Float32Array(MAX * 3);
    this.siz = new Float32Array(MAX);
    this.alp = new Float32Array(MAX);
    this.vel = new Float32Array(MAX * 3);
    this.life = new Float32Array(MAX);
    this.maxLife = new Float32Array(MAX);
    this.drag = new Float32Array(MAX);
    this.grav = new Float32Array(MAX);
    this.head = 0;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    g.setAttribute('aSize', new THREE.BufferAttribute(this.siz, 1));
    g.setAttribute('aAlpha', new THREE.BufferAttribute(this.alp, 1));
    this.uniforms = { uScale: { value: 300 } };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute float aSize; attribute float aAlpha;
        varying vec3 vColor; varying float vAlpha;
        uniform float uScale;
        void main(){
          vColor = color; vAlpha = aAlpha;
          vec4 mv = modelViewMatrix * vec4(position,1.0);
          gl_PointSize = aSize * uScale / max(0.5, -mv.z);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec3 vColor; varying float vAlpha;
        void main(){
          vec2 d = gl_PointCoord - 0.5;
          float a = smoothstep(0.5, 0.05, length(d));
          gl_FragColor = vec4(vColor, a*vAlpha);
        }`,
      vertexColors: true,
    });
    this.mesh = new THREE.Points(g, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 6;
    scene.add(this.mesh);
    this.geo = g;
    // кольцо ударной волны
    this.rings = [];
    for (let i = 0; i < 6; i++) {
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.85, 1, 24),
        new THREE.MeshBasicMaterial({ color: 0xffcf7a, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false })
      );
      ring.visible = false;
      scene.add(ring);
      this.rings.push({ mesh: ring, life: 0, maxLife: 1, scale: 1 });
    }
  }

  spawn(x, y, z, vx, vy, vz, r, g, b, size, life, drag = 1.6, grav = 0) {
    const i = this.head;
    this.head = (this.head + 1) % MAX;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.col[i * 3] = r; this.col[i * 3 + 1] = g; this.col[i * 3 + 2] = b;
    this.siz[i] = size; this.alp[i] = 1;
    this.life[i] = life; this.maxLife[i] = life;
    this.drag[i] = drag; this.grav[i] = grav;
  }

  eat(pos, size, colorHex = 0xffd27a) {
    const c = new THREE.Color(colorHex);
    const n = Math.min(34, 10 + Math.floor(size * 8));
    for (let i = 0; i < n; i++) {
      const a = Math.random() * 6.28, e = Math.random() * 3.14;
      const sp = (0.6 + Math.random() * 2) * Math.max(0.3, size * 0.6);
      this.spawn(pos.x, pos.y, pos.z, Math.cos(a) * Math.sin(e) * sp, Math.cos(e) * sp, Math.sin(a) * Math.sin(e) * sp,
        c.r, c.g, c.b, Math.max(0.06, size * 0.16), 0.7 + Math.random() * 0.6, 2.2);
    }
    for (let i = 0; i < 6; i++) {
      this.spawn(pos.x, pos.y, pos.z, (Math.random() - 0.5) * 2, 1 + Math.random() * 2, (Math.random() - 0.5) * 2,
        0.85, 0.97, 1, Math.max(0.05, size * 0.12), 0.9, 1.0, -1.2);
    }
  }

  hit(pos, size) {
    const n = 18;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * 6.28, e = Math.random() * 3.14;
      const sp = (1 + Math.random() * 3) * Math.max(0.4, size * 0.4);
      this.spawn(pos.x, pos.y, pos.z, Math.cos(a) * Math.sin(e) * sp, Math.cos(e) * sp, Math.sin(a) * Math.sin(e) * sp,
        1, 0.3 + Math.random() * 0.2, 0.25, Math.max(0.06, size * 0.12), 0.45 + Math.random() * 0.3, 3);
    }
  }

  explosion(pos, radius) {
    const n = 60;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * 6.28, e = Math.random() * 3.14;
      const sp = (2 + Math.random() * 6) * Math.max(1, radius * 0.3);
      this.spawn(pos.x, pos.y, pos.z, Math.cos(a) * Math.sin(e) * sp, Math.cos(e) * sp, Math.sin(a) * Math.sin(e) * sp,
        1, 0.62 + Math.random() * 0.3, 0.28, Math.max(0.15, radius * 0.09), 0.8 + Math.random() * 0.7, 2.4);
    }
    for (let i = 0; i < 24; i++) {
      this.spawn(pos.x, pos.y, pos.z, (Math.random() - 0.5) * 2, 2 + Math.random() * 5, (Math.random() - 0.5) * 2,
        0.8, 0.92, 1, Math.max(0.08, radius * 0.06), 1.2 + Math.random(), 0.7, -1.5);
    }
    this.ring(pos, radius * 1.6, new THREE.Color(0xffb662));
  }

  chest(pos) {
    for (let i = 0; i < 42; i++) {
      const a = Math.random() * 6.28, e = Math.random() * 3.14;
      const sp = 1 + Math.random() * 3;
      this.spawn(pos.x, pos.y + 0.5, pos.z, Math.cos(a) * Math.sin(e) * sp, Math.cos(e) * sp + 1.5, Math.sin(a) * Math.sin(e) * sp,
        1, 0.82 + Math.random() * 0.15, 0.3 + Math.random() * 0.3, 0.09 + Math.random() * 0.08, 1.1 + Math.random(), 1.4, -0.8);
    }
    this.ring(pos, 4, new THREE.Color(0xffd76a));
  }

  levelUp(pos, size) {
    for (let i = 0; i < 40; i++) {
      const a = Math.random() * 6.28;
      const r = Math.max(0.4, size * 0.7);
      this.spawn(pos.x + Math.cos(a) * r, pos.y + (Math.random() - 0.5) * r, pos.z + Math.sin(a) * r,
        -Math.cos(a) * 2, 1.5 + Math.random(), -Math.sin(a) * 2, 0.6, 0.95, 1, 0.12, 1.2, 1.2);
    }
    this.ring(pos, Math.max(3, size * 3), new THREE.Color(0x9fe8ff));
  }

  splash(pos, size) {
    for (let i = 0; i < 22; i++) {
      const a = Math.random() * 6.28;
      const sp = (1 + Math.random() * 3) * Math.max(0.5, size * 0.2);
      this.spawn(pos.x, 0, pos.z, Math.cos(a) * sp, 3 + Math.random() * 5, Math.sin(a) * sp,
        0.93, 0.98, 1, 0.1 + Math.random() * 0.1, 0.8, 0.9, 9);
    }
  }

  ring(pos, radius, color) {
    const r = this.rings.find(r => r.life <= 0);
    if (!r) return;
    r.mesh.position.copy(pos);
    r.mesh.material.color.copy(color);
    r.mesh.scale.setScalar(radius * 0.2);
    r.mesh.visible = true;
    r.life = 0.6; r.maxLife = 0.6; r.scale = radius;
  }

  update(dt) {
    for (let i = 0; i < MAX; i++) {
      if (this.life[i] <= 0) { this.alp[i] = 0; continue; }
      this.life[i] -= dt;
      const d = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i * 3] *= d; this.vel[i * 3 + 2] *= d;
      this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * d - this.grav[i] * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      const t = Math.max(0, this.life[i] / this.maxLife[i]);
      this.alp[i] = Math.min(1, t * 1.6);
    }
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = true;
    this.geo.attributes.aSize.needsUpdate = true;
    this.geo.attributes.aAlpha.needsUpdate = true;
    for (const r of this.rings) {
      if (r.life <= 0) { r.mesh.visible = false; continue; }
      r.life -= dt;
      const t = 1 - Math.max(0, r.life / r.maxLife);
      r.mesh.scale.setScalar(r.scale * (0.2 + t * 0.9));
      r.mesh.material.opacity = (1 - t) * 0.55;
      r.mesh.quaternion.copy(this.cameraQuat || new THREE.Quaternion());
      if (r.life <= 0) r.mesh.visible = false;
    }
  }
}
