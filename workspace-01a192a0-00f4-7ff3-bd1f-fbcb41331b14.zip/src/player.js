// Игрок: движение, размеры, здоровье, выносливость, камера.
import * as THREE from 'three';
import { speedFor, growthShare, levelCost, healFor, MAX_UPG, START } from './config.js';
import { terrainDepth, camDist } from './world.js';
import { clamp } from './noise.js';

const _fwd = new THREE.Vector3();
const _v = new THREE.Vector3();

export class Player {
  constructor(game) {
    this.game = game;
    this.pos = new THREE.Vector3(0, -START.depth, 0);
    this.vel = new THREE.Vector3();
    this.yaw = 0;
    this.pitch = 0;
    this.bank = 0;
    this.reset();
  }

  reset() {
    this.baseLen = START.size;
    this.upg = { speed: 0, hp: 0, size: 0 };
    this.level = 1;
    this.xp = 0;
    this.points = 0;
    this.maxHp = 100;
    this.hp = 100;
    this.stamina = 100;
    this.eaten = 0;
    this.tempSpeed = 0;
    this.tempSize = 0;
    this.boostLock = false;
    this.pos.set(0, -START.depth, 0);
    this.vel.set(0, 0, 0);
    this.yaw = 0; this.pitch = 0;
    this.invuln = 0;
    this.dead = false;
    this.runTime = 0;
    this.hurtFlash = 0;
    this.boostHeld = false;
    this.boosting = false;
    this.eatFlash = 0;
    this.lastDamage = null;
  }

  get permSize() { return this.baseLen * (1 + 0.10 * this.upg.size); }
  get curSize() { return this.permSize * (this.tempSize > 0 ? 1.6 : 1); }
  get speed() { return speedFor(this.permSize, this.upg.speed) * (this.tempSpeed > 0 ? 1.7 : 1); }
  get depth() { return -this.pos.y; }
  get forward() { return new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ')); }
  get xpNeeded() { return levelCost(this.level); }

  addGrowth(m) {
    this.baseLen += m * (1 + 0.10 * this.upg.size);
  }

  addXp(n) {
    this.xp += n;
    let ups = 0;
    while (this.xp >= this.xpNeeded) {
      this.xp -= this.xpNeeded;
      this.level++;
      this.points++;
      ups++;
    }
    return ups;
  }

  heal(n) { this.hp = Math.min(this.maxHp, this.hp + n); }

  damage(n, source) {
    if (this.invuln > 0 || this.dead || this.game.menuMode) return false;
    this.hp -= n;
    this.invuln = 1.25;
    this.hurtFlash = 0.5;
    this.lastDamage = { amount: Math.round(n), source };
    if (this.hp <= 0) { this.hp = 0; this.dead = true; }
    return true;
  }

  buy(kind) {
    if (this.points <= 0) return false;
    if (this.upg[kind] >= MAX_UPG[kind]) return false;
    this.points--;
    this.upg[kind]++;
    if (kind === 'hp') { this.maxHp = 100 + 45 * this.upg.hp; this.hp = this.maxHp; }
    return true;
  }

  update(dt, input, game) {
    if (this.dead) return;
    this.runTime += dt;
    if (this.tempSpeed > 0) this.tempSpeed = Math.max(0, this.tempSpeed - dt);
    if (this.tempSize > 0) this.tempSize = Math.max(0, this.tempSize - dt);
    if (this.invuln > 0) this.invuln -= dt;
    if (this.hurtFlash > 0) this.hurtFlash -= dt;
    if (this.eatFlash > 0) this.eatFlash -= dt;

    const turnRate = 1.75;
    this.yaw -= input.yaw * turnRate * dt;
    this.pitch += input.pitch * turnRate * 0.85 * dt;

    // мышь / тач: прямое управление курсом
    this.yaw -= input.mouseDX * 0.0024;
    this.pitch -= input.mouseDY * 0.0024;
    this.pitch = clamp(this.pitch, -1.35, 1.35);

    // мягкая помощь прицеливания
    const assist = game.targetAssist(this);
    if (assist) {
      const wantYaw = Math.atan2(-assist.dir.x, -assist.dir.z);
      const wantPitch = Math.asin(clamp(assist.dir.y, -1, 1));
      let dy = ((wantYaw - this.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      let dp = wantPitch - this.pitch;
      const k = assist.strength * dt * 1.6;
      this.yaw += dy * k;
      this.pitch += dp * k;
      this.pitch = clamp(this.pitch, -1.35, 1.35);
    }

    // рывок и выносливость
    let boosting = false;
    if (input.boost && this.stamina > 0.5 && !this.boostLock) {
      boosting = true;
      this.stamina -= 27 * dt;
      if (this.stamina <= 0) { this.stamina = 0; this.boostLock = true; }
    } else {
      this.stamina = Math.min(100, this.stamina + 18 * dt);
      if (this.stamina > 12) this.boostLock = false;
    }
    this.boosting = boosting;

    const base = this.speed;
    let thrust = 0.46;
    if (input.thrust > 0.5) thrust = 1;
    else if (input.thrust < -0.5) thrust = 0.06;
    if (boosting) thrust = Math.max(thrust, 1) * 1.95;
    if (input.thrust < -0.5 && boosting) thrust = 0.06;

    _fwd.set(0, 0, -1).applyEuler(new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ'));
    _v.copy(_fwd).multiplyScalar(base * thrust);
    const smooth = 1 - Math.exp(-6 * dt);
    this.vel.lerp(_v, smooth);
    this.pos.addScaledVector(this.vel, dt);

    // границы мира
    const r = Math.hypot(this.pos.x, this.pos.z);
    const R = 2650;
    if (r > R) {
      const n = new THREE.Vector3(this.pos.x / r, 0, this.pos.z / r);
      this.pos.x = n.x * R; this.pos.z = n.z * R;
      this.vel.multiplyScalar(0.3);
      game.showMessage('Сильное течение', 'Развернись обратно в лагуну');
      this.yaw += (Math.atan2(-n.x, -n.z) - this.yaw) * 0.06;
    }

    // дно и поверхность
    const L = this.curSize;
    const bottom = -terrainDepth(this.pos.x, this.pos.z, game.world.L);
    const margin = Math.max(0.35 * L, 0.5);
    if (this.pos.y < bottom + margin) {
      this.pos.y = bottom + margin;
      this.vel.y *= 0.2;
      this.pitch = Math.max(this.pitch, -0.25);
    }
    const topLimit = -0.25 * Math.max(0.6, L * 0.5);
    if (this.pos.y > topLimit) {
      this.pos.y = topLimit;
      this.vel.y = Math.min(0, this.vel.y);
      this.pitch = Math.min(this.pitch, 0.2);
    }

    // крен на повороте
    this.bank += ((-input.yaw * 0.35) - this.bank) * Math.min(1, dt * 5);
  }

  quaternion() {
    const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(this.pitch * 0.85, this.yaw, this.bank, 'YXZ'));
    return q;
  }
}

// Камера с собственным сглаживанием и защитой от рельефа
export class CameraRig {
  constructor(camera) {
    this.camera = camera;
    this.smoothPos = new THREE.Vector3(0, -16, 5);
    this.smoothLook = new THREE.Vector3(0, -16, -5);
    this.fov = IS_PORTRAIT() ? 66 : 58;
  }
  reset(player) {
    const f = player.forward;
    const D = camDist(player.curSize) * (window.innerWidth < window.innerHeight ? 0.8 : 1);
    this.smoothPos.copy(player.pos).addScaledVector(f, -D).y += 0.3 * D;
    this.smoothLook.copy(player.pos).addScaledVector(f, 0.7 * D);
  }
  update(dt, player, game, aspect) {
    const L = player.curSize;
    const D = camDist(L) * (aspect < 1 ? 0.8 : 1);
    const f = player.forward;
    const wantPos = new THREE.Vector3().copy(player.pos).addScaledVector(f, -D);
    wantPos.y += 0.3 * D + Math.min(D * 0.08, 0.6);
    const wantLook = new THREE.Vector3().copy(player.pos).addScaledVector(f, 0.7 * D);
    wantLook.y -= 0.06 * D;

    const kp = 1 - Math.exp(-7 * dt);
    const kl = 1 - Math.exp(-10 * dt);
    this.smoothPos.lerp(wantPos, kp);
    this.smoothLook.lerp(wantLook, kl);

    // не под рельефом
    const bottom = -terrainDepth(this.smoothPos.x, this.smoothPos.z, game.world.L);
    const minY = bottom + Math.max(0.3 * L, 0.4);
    if (this.smoothPos.y < minY) this.smoothPos.y = minY;

    this.camera.position.copy(this.smoothPos);
    this.camera.lookAt(this.smoothLook);

    // FOV
    let fov = 58;
    if (aspect < 1) {
      const hfov = 80 * Math.PI / 180;
      const v = 2 * Math.atan(Math.tan(hfov / 2) / aspect) * 180 / Math.PI;
      fov = clamp(v, 60, 72);
    }
    if (player.boosting) fov += 6;
    this.camera.fov += (fov - this.camera.fov) * Math.min(1, dt * 4);
    this.camera.updateProjectionMatrix();
  }
}

function IS_PORTRAIT() { return typeof window !== 'undefined' && window.innerHeight > window.innerWidth; }
