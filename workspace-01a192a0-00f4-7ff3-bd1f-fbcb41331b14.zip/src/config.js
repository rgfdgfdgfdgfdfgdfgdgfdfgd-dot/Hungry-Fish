// Баланс и таблицы из GAME_DESCRIPTION.md (разделы 4–8, 13)

export const SPECIES = {
  sardine:    { id: 'sardine',    name: 'Сардина',          size: 0.32, temper: 'calm',   xpMul: 0.85, predator: false },
  clown:      { id: 'clown',      name: 'Рыба-клоун',       size: 0.48, temper: 'calm',   xpMul: 0.85, predator: false },
  butterfly:  { id: 'butterfly',  name: 'Рыба-бабочка',     size: 0.62, temper: 'wary',   xpMul: 1.15, predator: false },
  tang:       { id: 'tang',       name: 'Голубой хирург',   size: 0.85, temper: 'nimble', xpMul: 1.5,  predator: false },
  mackerel:   { id: 'mackerel',   name: 'Скумбрия',         size: 1.25, temper: 'wary',   xpMul: 1.15, predator: false },
  tuna:       { id: 'tuna',       name: 'Тунец',            size: 2.5,  temper: 'nimble', xpMul: 1.5,  predator: false },
  barracuda:  { id: 'barracuda',  name: 'Барракуда',        size: 3.4,  temper: 'nimble', xpMul: 1.5,  predator: true },
  hammerhead: { id: 'hammerhead', name: 'Акула-молот',      size: 5.2,  temper: 'wary',   xpMul: 1.15, predator: true },
  greatwhite: { id: 'greatwhite', name: 'Белая акула',      size: 7.5,  temper: 'nimble', xpMul: 1.5,  predator: true },
  whaleshark: { id: 'whaleshark', name: 'Китовая акула',    size: 15,   temper: 'calm',   xpMul: 0.85, predator: false },
};

export const SPECIES_LIST = Object.values(SPECIES);
export const PREY_ORDER = ['sardine', 'clown', 'butterfly', 'tang', 'mackerel', 'tuna', 'barracuda', 'hammerhead', 'greatwhite', 'whaleshark'];

export const TEMPER_TEXT = { calm: 'спокойная', wary: 'осторожная', nimble: 'проворная' };
export const TEMPER_XP = { calm: 0.85, wary: 1.15, nimble: 1.5 };

export const SURFACE_TARGETS = {
  swimmer: { id: 'swimmer', name: 'Пловец', size: 1.8, xp: 30, growth: 0.072, speed: 0.3, count: 4, minDist: 55 },
  boat:    { id: 'boat',    name: 'Рыбацкая лодка', size: 6, xp: 150, growth: 0.24, speed: 0.65, count: 4, minDist: 100 },
  yacht:   { id: 'yacht',   name: 'Яхта', size: 22, xp: 750, growth: 0.88, speed: 0.65, count: 3, minDist: 190 },
  cargo:   { id: 'cargo',   name: 'Грузовой корабль', size: 65, xp: 3000, growth: 2.6, speed: 0.65, count: 2, minDist: 330 },
  cruiser: { id: 'cruiser', name: 'Военный крейсер', size: 140, xp: 10000, growth: 5.6, speed: 1.2, count: 2, minDist: 500 },
  diver:   { id: 'diver',   name: 'Водолаз в клетке', size: 36, xp: 500, growth: 1.44, speed: 1.2, count: 2, minDist: 500 },
};

export const STAGES = [
  { max: 1.8,    name: 'Житель рифа',       goal: 'Охота у поверхности',        goalSize: 1.8,  tip: 'пловцы' },
  { max: 6,      name: 'Хищник лагуны',     goal: 'Первый большой улов',        goalSize: 6,    tip: 'лодки' },
  { max: 22,     name: 'Гроза побережья',   goal: 'Роскошный обед',             goalSize: 22,   tip: 'яхты' },
  { max: 65,     name: 'Хозяин глубин',     goal: 'Большая охота',              goalSize: 65,   tip: 'грузовые корабли' },
  { max: 140,    name: 'Морской гигант',    goal: 'Последний в пищевой цепи',   goalSize: 140,  tip: 'военные крейсеры' },
  { max: 1e9,    name: 'Легенда океана',    goal: 'Океан в твоём меню',         goalSize: 140,  tip: 'всё' },
];

export function stageFor(size) {
  for (const s of STAGES) if (size < s.max) return s;
  return STAGES[STAGES.length - 1];
}

// --- Формулы баланса (раздел 17) ---
export function levelCost(n) {
  const over = Math.max(0, n - 8);
  return Math.round(16 * Math.pow(n, 1.55) * (1 + 0.07 * over));
}

export function speedFor(permSize, speedUpg) {
  return (3 + 2.1 * Math.pow(permSize, 0.72)) * (1 + 0.12 * speedUpg);
}

export function growthShare(permSize) {
  const early = Math.min(1, Math.max(0, (4 - permSize) / 3.22));
  return 0.03 + 0.09 * early;
}

export function noviceBonus(permSize) {
  const f = Math.min(1, Math.max(0, (3 - permSize) / 2.22));
  return 1 + 0.8 * f;
}

export function fishXp(size, permSize, temper) {
  const base = Math.max(4, 12 * Math.pow(size, 1.15));
  return Math.max(3, Math.round(base * noviceBonus(permSize) * TEMPER_XP[temper]));
}

export function healFor(size) { return 5 + 1.8 * size; }

export function biteDamage(attackerSize, playerSize) {
  const v = 28 + 24 * Math.log2(Math.max(1.0001, attackerSize / playerSize));
  return Math.round(Math.min(65, Math.max(28, v)));
}

export const MAX_UPG = { speed: 15, hp: 15, size: 20 };

export const START = { size: 0.78, hp: 100, stamina: 100, depth: 16 };
