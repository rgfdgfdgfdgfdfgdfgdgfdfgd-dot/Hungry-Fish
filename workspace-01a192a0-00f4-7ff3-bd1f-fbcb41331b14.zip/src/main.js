import { Game } from './game.js';

const canvas = document.getElementById('game');

function boot() {
  let game;
  try {
    game = new Game(canvas);
  } catch (err) {
    console.error(err);
    document.body.insertAdjacentHTML('beforeend',
      `<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:#04182a;color:#ffd9d9;font:14px system-ui;padding:24px;text-align:center;z-index:99">
        Не удалось запустить игру: ${String(err.message || err)}<br>Обнови страницу.</div>`);
    return;
  }
  window.__HF_GAME = game;
  window.__HF = {
    start(skin) {
      if (skin === 'clown' || skin === 'shark') game.setSkin(skin);
      game.startRun();
      return true;
    },
    info: () => game.info(),
    setSize: (m) => { game.setSize(m); return game.info(); },
    tp: (x, y, z) => { game.tp(x, y, z); return game.info(); },
    simulate: (seconds, dt) => { game.simulate(seconds, dt); return game.info(); },
    camCheck: (sec) => game.camClearanceCheck(sec),
    snapshot: () => game.snapshot(),
    relief: (cx, cz, r, n) => game.terrainRelief(cx, cz, r, n),
    god: (on) => { game.god = !!on; return game.god; },
    pause: () => game.pause(),
    resume: () => game.resume(),
  };
}

boot();
