// Интерфейс: HUD, метки в мире, указатели угроз, сонар, сообщения, экраны.
import * as THREE from 'three';
import { SPECIES, TEMPER_TEXT, stageFor, SURFACE_TARGETS } from './config.js';

const $ = (s) => document.querySelector(s);

export class UI {
  constructor(game) {
    this.game = game;
    this.el = {
      hud: $('#hud'), menu: $('#menu'), intro: $('#intro'), upgrades: $('#upgrades'), pause: $('#pause'),
      guide: $('#guide'), dead: $('#dead'), victory: $('#victory'),
      lvl: $('#lvl'), stage: $('#stage'), xpfill: $('#xpfill'), xplabel: $('#xplabel'),
      hpfill: $('#hpfill'), hplabel: $('#hplabel'), hpbar: $('#hpbar'),
      stfill: $('#stfill'), stlabel: $('#stlabel'),
      depth: $('#depth'), size: $('#size'), eaten: $('#eaten'), buffline: $('#buffline'),
      goalname: $('#goalname'), goalsize: $('#goalsize'), goalfill: $('#goalfill'),
      sonar: $('#sonar'), markers: $('#markers'), msgs: $('#msgs'), hint: $('#hint'), dmgflash: $('#dmgflash'),
      upgbadge: $('#upgbadge'), ptsline: $('#ptsline'),
      upgspeed: $('#upg-speed'), upghp: $('#upg-hp'), upgsize: $('#upg-size'),
      touch: $('#touch'), joystick: $('#joystick'), knob: $('#stickknob'),
      pauseStats: $('#pausestats'), record: $('#recordline'),
    };
    this.markerPool = [];
    this.sonarCtx = this.el.sonar.getContext('2d');
    this.touchState = { active: false, x: 0, y: 0, id: null };
    this.messageTimer = 0;
    this.lastHint = '';
    this.fillFishList();
    this.bindTouch();
    this.screen = 'menu';
  }

  fillFishList() {
    const list = Object.values(SPECIES).map(s => `${s.name} — ${s.size.toFixed(2)} м, ${TEMPER_TEXT[s.temper]}`).join(' · ');
    const el = $('#fishlist');
    if (el) el.textContent = list;
  }

  showScreen(name) {
    this.screen = name;
    for (const k of ['menu', 'intro', 'upgrades', 'pause', 'guide', 'dead', 'victory']) {
      this.el[k].classList.toggle('hidden', k !== name);
    }
    this.el.hud.classList.toggle('hidden', !(name === null || name === 'upgrades' || name === 'pause' || name === 'guide'));
  }

  setTouchVisible(v) { this.el.touch.classList.toggle('hidden', !v); }

  message(title, sub = '', cls = '') {
    const div = document.createElement('div');
    div.className = 'msg ' + cls;
    div.innerHTML = `<b>${title}</b>${sub ? `<span>${sub}</span>` : ''}`;
    this.el.msgs.appendChild(div);
    while (this.el.msgs.children.length > 2) this.el.msgs.removeChild(this.el.msgs.firstChild);
    setTimeout(() => { div.style.opacity = '0'; div.style.transition = 'opacity .6s'; }, 2400);
    setTimeout(() => div.remove(), 3100);
  }

  hint(text) {
    if (text === this.lastHint) return;
    this.lastHint = text;
    this.el.hint.textContent = text;
    this.el.hint.style.opacity = text ? '1' : '0';
  }

  flashDamage() {
    this.el.dmgflash.style.opacity = '1';
    setTimeout(() => { this.el.dmgflash.style.opacity = '0'; }, 120);
  }

  // ------------- HUD -------------
  updateHUD() {
    const p = this.game.player;
    const st = stageFor(p.permSize);
    this.el.lvl.textContent = 'УР. ' + p.level;
    this.el.stage.textContent = st.name;
    const xpPct = Math.min(100, (p.xp / p.xpNeeded) * 100);
    this.el.xpfill.style.width = xpPct + '%';
    this.el.xplabel.textContent = `${Math.floor(p.xp)} / ${p.xpNeeded}`;
    const hpPct = Math.max(0, (p.hp / p.maxHp) * 100);
    this.el.hpfill.style.width = hpPct + '%';
    this.el.hplabel.textContent = `${Math.ceil(p.hp)} / ${p.maxHp}`;
    this.el.hpbar.classList.toggle('low', hpPct < 30);
    this.el.stfill.style.width = Math.max(0, p.stamina) + '%';
    this.el.stlabel.textContent = p.boosting ? 'РЫВОК' : 'Выносливость';
    this.el.depth.textContent = Math.max(0, Math.round(-p.pos.y));
    this.el.size.textContent = p.curSize.toFixed(2).replace('.', ',');
    this.el.eaten.textContent = p.eaten;
    let buffs = '';
    if (p.tempSpeed > 0) buffs += `Течение ${p.tempSpeed.toFixed(0)} с `;
    if (p.tempSize > 0) buffs += `Левиафан ${p.tempSize.toFixed(0)} с`;
    this.el.buffline.textContent = buffs;
    // цель
    const goal = st.goalSize;
    this.el.goalname.textContent = st.goal;
    this.el.goalsize.textContent = goal.toFixed(goal < 10 ? 1 : 0).replace('.', ',') + ' м';
    this.el.goalfill.style.width = Math.min(100, (p.permSize / goal) * 100) + '%';
    this.el.upgbadge.classList.toggle('hidden', p.points <= 0);
    this.el.upgbadge.textContent = p.points;
  }

  // ------------- метки -------------
  project(pos) {
    const cam = this.game.camera;
    const v = new THREE.Vector3().copy(pos);
    v.applyMatrix4(cam.matrixWorldInverse);
    const behind = v.z > 0;
    const ndc = v.clone().applyMatrix4(cam.projectionMatrix);
    return { x: (ndc.x * 0.5 + 0.5) * window.innerWidth, y: (-ndc.y * 0.5 + 0.5) * window.innerHeight, behind, ndc };
  }

  getMarker(i) {
    while (this.markerPool.length <= i) {
      const d = document.createElement('div');
      d.className = 'marker';
      this.el.markers.appendChild(d);
      this.markerPool.push({ el: d, used: false });
    }
    return this.markerPool[i];
  }

  updateMarkers(dt) {
    const g = this.game, p = g.player;
    this.game.camera.updateMatrixWorld();
    let idx = 0;
    const put = (pos, cls, html, edge = false) => {
      const pr = this.project(pos);
      const m = this.getMarker(idx);
      const w = window.innerWidth, h = window.innerHeight;
      const margin = 46;
      let x = pr.x, y = pr.y;
      const off = pr.behind || x < 0 || x > w || y < 0 || y > h;
      if (edge && off) {
        // стрелка у края
        let dx = pr.behind ? -pr.ndc.x : pr.ndc.x;
        let dy = pr.behind ? -pr.ndc.y : pr.ndc.y;
        if (pr.behind) { dx = -dx; dy = -dy; }
        const len = Math.hypot(dx, dy) || 1;
        dx /= len; dy /= len;
        x = w / 2 + dx * (w / 2 - 40);
        y = h / 2 - dy * (h / 2 - 40);
        x = Math.max(margin, Math.min(w - margin, x));
        y = Math.max(margin, Math.min(h - margin, y));
        const ang = Math.atan2(-dy, dx) * 180 / Math.PI + 90;
        m.el.className = 'marker arrow ' + (cls === 'bad' ? 'threat' : 'weapon');
        m.el.style.transform = `translate(-50%,-50%) rotate(${ang}deg)`;
        m.el.style.left = x + 'px';
        m.el.style.top = y + 'px';
        m.el.innerHTML = `<span class="alabel ${cls === 'bad' ? '' : 'weapon'}" style="transform:rotate(${-ang}deg)">${html}</span>`;
        m.el.style.padding = '0';
        m.el.style.background = 'none';
        m.el.style.borderLeft = '9px solid transparent';
        m.el.style.borderRight = '9px solid transparent';
        m.el.style.borderTop = 'none';
        m.el.style.borderBottom = `16px solid ${cls === 'bad' ? 'rgba(255,120,110,.9)' : 'rgba(255,190,90,.9)'}`;
        m.used = true; idx++;
        return;
      }
      m.el.className = 'marker ' + cls;
      m.el.style.padding = '';
      m.el.style.background = '';
      m.el.style.border = '';
      m.el.style.left = Math.max(60, Math.min(w - 60, x)) + 'px';
      m.el.style.top = Math.max(146, Math.min(h - 120, y - 26)) + 'px';
      m.el.style.transform = 'translate(-50%,-50%)';
      m.el.innerHTML = html;
      m.used = true; idx++;
    };

    // 1) цель игрока
    const target = g.fish.bestTarget(p, Math.max(14, p.curSize * 10));
    if (target) {
      const edible = target.size <= p.curSize;
      const sp = SPECIES[target.species];
      const dist = target.pos.distanceTo(p.pos);
      const cls = edible ? 'good' : 'bad';
      const title = edible ? 'МОЖНО СЪЕСТЬ' : 'ОПАСНО: КРУПНЕЕ ТЕБЯ';
      const nm = sp.name + (target.giant ? '-гигант' : '');
      put(target.pos, cls, `<span class="ttl">${title}</span><span class="sub">${nm} · ${target.size.toFixed(2).replace('.', ',')} м · ${dist.toFixed(0)} м · ${TEMPER_TEXT[sp.temper]} ×${sp.xpMul}</span>`);
    }
    // 2) сундуки
    for (const c of g.entities.chests) {
      if (c.opened) continue;
      const d = Math.hypot(c.x - p.pos.x, c.z - p.pos.z);
      if (d < Math.min(140, 30 + p.curSize * 8)) {
        put(new THREE.Vector3(c.x, c.y + 3, c.z), 'gold', `<span class="ttl">СОКРОВИЩЕ</span><span class="sub">${d.toFixed(0)} м</span>`);
      }
      if (idx > 22) break;
    }
    // 3) атакующие рыбы
    let threats = 0;
    for (const f of g.fish.fish) {
      if (threats >= 4) break;
      if (!f.alive) continue;
      const st = f.state;
      if (!['alert', 'chase', 'windup', 'lunge', 'recover'].includes(st)) continue;
      if (f.pos.distanceTo(p.pos) > 260 + p.curSize * 12) continue;
      const label = st === 'alert' ? 'ЗАМЕТИЛА ТЕБЯ' : st === 'chase' ? 'ПРЕСЛЕДУЕТ' : st === 'windup' ? `ГОТОВИТ УКУС · ${f.stateT.toFixed(1)}` : st === 'lunge' ? 'АТАКУЕТ!' : 'ПОСЛЕ БРОСКА';
      const nm = SPECIES[f.species].name;
      const dist = f.pos.distanceTo(p.pos).toFixed(0);
      put(f.pos, 'bad', `<span class="ttl">${label}</span><span class="sub">${nm} · ${dist} м</span>`, true);
      threats++;
    }
    // 4) угрозы оружия
    let weapons = 0;
    for (const b of g.entities.bombs) {
      if (weapons >= 4) break;
      put(b.target, 'bad', `<span class="ttl">ГЛУБИННАЯ БОМБА · ${Math.max(0, b.timer).toFixed(1)} с</span><span class="sub">${b.target.distanceTo(p.pos).toFixed(0)} м</span>`, true);
      weapons++;
    }
    for (const s of g.entities.shells) {
      if (weapons >= 4) break;
      const t = s.state === 'prep' ? (s.prep - s.t) : (s.dist - s.t);
      put(s.state === 'prep' ? s.to : s.mesh.position, 'bad', `<span class="ttl">СНАРЯД · ${Math.max(0, t).toFixed(1)} с</span>`, true);
      weapons++;
    }
    for (const h of g.entities.harpoons) {
      if (weapons >= 4) break;
      put(h.pos, 'bad', `<span class="ttl">ГАРПУН</span>`, true);
      weapons++;
    }
    // остальные — гасим
    for (let i = idx; i < this.markerPool.length; i++) {
      this.markerPool[i].el.style.display = 'none';
    }
    for (let i = 0; i < idx; i++) this.markerPool[i].el.style.display = '';
  }

  // ------------- сонар -------------
  drawSonar() {
    const g = this.game, p = g.player;
    const c = this.sonarCtx;
    const W = this.el.sonar.width, H = this.el.sonar.height;
    const cx = W / 2, cy = H / 2, R = W / 2 - 6;
    c.clearRect(0, 0, W, H);
    // сетка
    c.strokeStyle = 'rgba(130,220,255,.22)';
    c.lineWidth = 1.5;
    for (let i = 1; i <= 3; i++) { c.beginPath(); c.arc(cx, cy, (R * i) / 3, 0, Math.PI * 2); c.stroke(); }
    c.beginPath(); c.moveTo(cx, cy - R); c.lineTo(cx, cy + R); c.moveTo(cx - R, cy); c.lineTo(cx + R, cy); c.stroke();
    // сектор вперёд
    c.fillStyle = 'rgba(120,230,255,.10)';
    c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, R, -Math.PI * 0.75, -Math.PI * 0.25); c.closePath(); c.fill();
    // игрок
    c.fillStyle = '#9ff0ff';
    c.beginPath(); c.moveTo(cx, cy - 7); c.lineTo(cx - 5, cy + 6); c.lineTo(cx + 5, cy + 6); c.closePath(); c.fill();

    const range = Math.max(60, 8 * p.permSize);
    const yaw = p.yaw;
    const toSonar = (x, z) => {
      const dx = x - p.pos.x, dz = z - p.pos.z;
      const cos = Math.cos(-yaw), sin = Math.sin(-yaw);
      const rx = dx * cos - dz * sin;
      const rz = dx * sin + dz * cos;
      return { x: cx + (rx / range) * R, y: cy + (rz / range) * R };
    };
    const blip = (x, z, y, kind, size) => {
      const d = Math.hypot(x - p.pos.x, z - p.pos.z);
      if (d > range) return;
      const pt = toSonar(x, z);
      const faded = Math.abs(y - p.pos.y) > Math.max(8, p.curSize * 3);
      const alpha = faded ? 0.4 : 0.95;
      if (kind === 'chest') {
        c.fillStyle = `rgba(255,214,110,${alpha})`;
        c.save(); c.translate(pt.x, pt.y); c.rotate(Math.PI / 4); c.fillRect(-4, -4, 8, 8); c.restore();
        return;
      }
      const color = size <= p.curSize ? `rgba(110,245,160,${alpha})` : `rgba(255,110,100,${alpha})`;
      c.fillStyle = color;
      const r = Math.max(2.2, Math.min(5, 2 + size * 0.08));
      c.beginPath(); c.arc(pt.x, pt.y, r, 0, Math.PI * 2); c.fill();
    };
    for (const f of g.fish.fish) if (f.alive) blip(f.pos.x, f.pos.z, f.pos.y, 'fish', f.size);
    for (const t of g.entities.targets) blip(t.x, t.z, 0, 'ship', t.size);
    for (const cg of g.entities.cages) if (cg.active) blip(cg.group.position.x, cg.group.position.z, cg.group.position.y, 'fish', cg.size);
    for (const ch of g.entities.chests) if (!ch.opened) blip(ch.x, ch.z, ch.y, 'chest', 2);
  }

  // ------------- панели -------------
  updateUpgrades() {
    const p = this.game.player;
    this.el.ptsline.textContent = 'Очки: ' + p.points;
    this.el.upgspeed.textContent = `${p.upg.speed} / 15`;
    this.el.upghp.textContent = `${p.upg.hp} / 15`;
    this.el.upgsize.textContent = `${p.upg.size} / 20`;
    document.querySelectorAll('.upgbtn').forEach(b => {
      const k = b.dataset.upg;
      const max = k === 'size' ? 20 : 15;
      b.disabled = p.points <= 0 || p.upg[k] >= max;
    });
  }

  statsHTML() {
    const p = this.game.player;
    return `<div>Постоянный размер: <b>${p.permSize.toFixed(2).replace('.', ',')} м</b></div>
      <div>Съедено добычи: <b>${p.eaten}</b></div>
      <div>Уровень: <b>${p.level}</b></div>
      <div>Время в океане: <b>${formatTime(p.runTime)}</b></div>`;
  }

  updateRecord(rec) {
    this.el.record.textContent = rec
      ? `Рекорд: ${rec.size.toFixed(2).replace('.', ',')} м · добыча ${rec.eaten} · уровень ${rec.level}`
      : 'Рекорд: пока пусто';
  }

  // ------------- сенсор -------------
  bindTouch() {
    const el = this.el.joystick, knob = this.el.knob;
    const setKnob = (dx, dy) => {
      const max = 46;
      const len = Math.hypot(dx, dy);
      const k = len > max ? max / len : 1;
      knob.style.transform = `translate(${dx * k}px,${dy * k}px)`;
    };
    const onStart = (e) => {
      const t = e.changedTouches ? e.changedTouches[0] : e;
      this.touchState.active = true;
      this.touchState.id = t.identifier;
      const r = el.getBoundingClientRect();
      this.touchState.ox = r.left + r.width / 2;
      this.touchState.oy = r.top + r.height / 2;
      onMove(e);
    };
    const onMove = (e) => {
      if (!this.touchState.active) return;
      let t = e;
      if (e.changedTouches) {
        t = Array.from(e.changedTouches).find(tt => tt.identifier === this.touchState.id);
        if (!t) return;
      }
      const dx = t.clientX - this.touchState.ox;
      const dy = t.clientY - this.touchState.oy;
      setKnob(dx, dy);
      const max = 46;
      this.touchState.x = Math.max(-1, Math.min(1, dx / max));
      this.touchState.y = Math.max(-1, Math.min(1, dy / max));
      e.preventDefault?.();
    };
    const onEnd = (e) => {
      this.touchState.active = false;
      this.touchState.x = 0; this.touchState.y = 0;
      knob.style.transform = 'translate(0,0)';
      this.game.touch.boost = false;
    };
    el.addEventListener('touchstart', onStart, { passive: false });
    window.addEventListener('touchmove', onMove, { passive: false });
    window.addEventListener('touchend', onEnd);
    window.addEventListener('touchcancel', onEnd);
    // кнопки
    const boost = $('#btn-boost'), up = $('#btn-up'), down = $('#btn-down');
    const bindHold = (node, on, off) => {
      node.addEventListener('touchstart', (e) => { e.preventDefault(); on(); }, { passive: false });
      node.addEventListener('touchend', (e) => { e.preventDefault(); off(); }, { passive: false });
      node.addEventListener('mousedown', on);
      node.addEventListener('mouseup', off);
      node.addEventListener('mouseleave', off);
    };
    bindHold(boost, () => this.game.touch.boost = true, () => this.game.touch.boost = false);
    bindHold(up, () => this.game.touch.up = true, () => this.game.touch.up = false);
    bindHold(down, () => this.game.touch.down = true, () => this.game.touch.down = false);
  }
}

export function formatTime(t) {
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}
