// Процедурный звук: 20+ событий и два эмбиента (под водой / над водой).
export class GameAudio {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.master = null;
    this.underGain = null;
    this.airGain = null;
    this.underwater = true;
    this.noiseBuf = null;
    this.ready = false;
  }

  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.75;
    this.master.connect(this.ctx.destination);
    // буфер шума
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
    this.buildAmbience();
    this.ready = true;
  }

  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }

  setEnabled(v) {
    this.enabled = v;
    if (this.master) this.master.gain.setTargetAtTime(v ? 0.75 : 0, this.ctx.currentTime, 0.1);
  }

  buildAmbience() {
    const ctx = this.ctx;
    this.underGain = ctx.createGain(); this.underGain.gain.value = 0.5; this.underGain.connect(this.master);
    this.airGain = ctx.createGain(); this.airGain.gain.value = 0.0; this.airGain.connect(this.master);

    // подводный гул
    const hum = ctx.createOscillator(); hum.type = 'sine'; hum.frequency.value = 54;
    const hum2 = ctx.createOscillator(); hum2.type = 'sine'; hum2.frequency.value = 81.5;
    const hg = ctx.createGain(); hg.gain.value = 0.09;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 260;
    hum.connect(hg); hum2.connect(hg); hg.connect(lp); lp.connect(this.underGain);
    hum.start(); hum2.start();

    // шум воды под водой
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf; n.loop = true;
    const nf = ctx.createBiquadFilter(); nf.type = 'lowpass'; nf.frequency.value = 420; nf.Q.value = 0.6;
    const ng = ctx.createGain(); ng.gain.value = 0.16;
    n.connect(nf); nf.connect(ng); ng.connect(this.underGain);
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.09;
    const lfoG = ctx.createGain(); lfoG.gain.value = 120;
    lfo.connect(lfoG); lfoG.connect(nf.frequency); lfo.start();
    n.start();

    // над водой: волны, ветер
    const w = ctx.createBufferSource(); w.buffer = this.noiseBuf; w.loop = true;
    const wf = ctx.createBiquadFilter(); wf.type = 'bandpass'; wf.frequency.value = 700; wf.Q.value = 0.5;
    const wg = ctx.createGain(); wg.gain.value = 0.2;
    w.connect(wf); wf.connect(wg); wg.connect(this.airGain);
    const wl = ctx.createOscillator(); wl.frequency.value = 0.14;
    const wlg = ctx.createGain(); wlg.gain.value = 260;
    wl.connect(wlg); wlg.connect(wf.frequency); wl.start();
    w.start();
    this.airNoise = w; this.airWindFilter = wf;
  }

  setUnderwater(u) {
    if (!this.ready) return;
    this.underwater = u;
    const t = this.ctx.currentTime;
    this.underGain.gain.setTargetAtTime(u ? 0.5 : 0.12, t, 0.25);
    this.airGain.gain.setTargetAtTime(u ? 0.0 : 0.55, t, 0.25);
  }

  // ---- примитивы ----
  tone({ freq = 440, freqEnd = null, dur = 0.2, type = 'sine', gain = 0.2, delay = 0, filter = null, q = 1 }) {
    if (!this.ready || !this.enabled) return;
    const ctx = this.ctx, t0 = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (freqEnd) osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, gain), t0 + Math.min(0.02, dur * 0.2));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    let node = osc;
    if (filter) {
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = filter; f.Q.value = q;
      node.connect(f); f.connect(g);
    } else node.connect(g);
    g.connect(this.master);
    osc.start(t0); osc.stop(t0 + dur + 0.05);
  }

  noise({ dur = 0.2, gain = 0.2, filter = 1200, type = 'lowpass', q = 1, delay = 0, sweepTo = null }) {
    if (!this.ready || !this.enabled) return;
    const ctx = this.ctx, t0 = ctx.currentTime + delay;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = type; f.frequency.setValueAtTime(filter, t0); f.Q.value = q;
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(Math.max(60, sweepTo), t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, gain), t0 + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t0); src.stop(t0 + dur + 0.05);
  }

  play(name) {
    if (!this.ready || !this.enabled) return;
    switch (name) {
      case 'eatSmall':
        this.tone({ freq: 700, freqEnd: 1150, dur: 0.1, type: 'triangle', gain: 0.14 });
        this.noise({ dur: 0.09, gain: 0.08, filter: 2200, type: 'bandpass' });
        break;
      case 'eatBig':
        this.tone({ freq: 190, freqEnd: 70, dur: 0.45, type: 'sawtooth', gain: 0.16, filter: 500 });
        this.noise({ dur: 0.35, gain: 0.14, filter: 900, sweepTo: 180 });
        this.tone({ freq: 520, freqEnd: 300, dur: 0.2, type: 'triangle', gain: 0.1, delay: 0.05 });
        break;
      case 'bitePlayer':
        this.tone({ freq: 150, freqEnd: 60, dur: 0.3, type: 'square', gain: 0.18, filter: 700 });
        this.noise({ dur: 0.22, gain: 0.18, filter: 700, sweepTo: 200 });
        break;
      case 'boost':
        this.noise({ dur: 0.35, gain: 0.12, filter: 500, type: 'bandpass', sweepTo: 1800 });
        break;
      case 'jump':
        this.noise({ dur: 0.3, gain: 0.16, filter: 1600, sweepTo: 300 });
        this.tone({ freq: 300, freqEnd: 700, dur: 0.15, type: 'sine', gain: 0.08 });
        break;
      case 'splash':
        this.noise({ dur: 0.4, gain: 0.2, filter: 2400, sweepTo: 500 });
        break;
      case 'bombDrop':
        this.tone({ freq: 260, freqEnd: 120, dur: 0.35, type: 'sine', gain: 0.12 });
        break;
      case 'bombExplode':
        this.noise({ dur: 1.0, gain: 0.34, filter: 900, sweepTo: 90 });
        this.tone({ freq: 90, freqEnd: 32, dur: 0.9, type: 'sine', gain: 0.3 });
        break;
      case 'cannonShot':
        this.noise({ dur: 0.5, gain: 0.26, filter: 1600, sweepTo: 200 });
        this.tone({ freq: 160, freqEnd: 50, dur: 0.4, type: 'square', gain: 0.14, filter: 400 });
        break;
      case 'shellSplash':
        this.noise({ dur: 0.45, gain: 0.2, filter: 3000, sweepTo: 600 });
        break;
      case 'harpoonShot':
        this.tone({ freq: 1400, freqEnd: 420, dur: 0.22, type: 'sawtooth', gain: 0.1, filter: 3000 });
        this.noise({ dur: 0.18, gain: 0.1, filter: 4000, type: 'highpass' });
        break;
      case 'harpoonHit':
        this.tone({ freq: 320, freqEnd: 120, dur: 0.2, type: 'square', gain: 0.14, filter: 900 });
        break;
      case 'chest':
        [523, 659, 784, 1046].forEach((f, i) => this.tone({ freq: f, dur: 0.3, type: 'triangle', gain: 0.13, delay: i * 0.07 }));
        this.noise({ dur: 0.5, gain: 0.08, filter: 3200, type: 'highpass' });
        break;
      case 'buffSpeed':
        this.tone({ freq: 400, freqEnd: 900, dur: 0.5, type: 'sine', gain: 0.12 });
        this.noise({ dur: 0.6, gain: 0.1, filter: 900, sweepTo: 2600, type: 'bandpass' });
        break;
      case 'buffSize':
        this.tone({ freq: 120, freqEnd: 240, dur: 0.7, type: 'sine', gain: 0.16 });
        this.tone({ freq: 180, freqEnd: 360, dur: 0.7, type: 'triangle', gain: 0.08, delay: 0.05 });
        break;
      case 'buffHeal':
        [440, 554, 660].forEach((f, i) => this.tone({ freq: f, dur: 0.5, type: 'sine', gain: 0.1, delay: i * 0.08 }));
        break;
      case 'buffXp':
        [660, 880].forEach((f, i) => this.tone({ freq: f, dur: 0.4, type: 'triangle', gain: 0.1, delay: i * 0.1 }));
        break;
      case 'levelUp':
        [523, 659, 784, 1046, 1318].forEach((f, i) => this.tone({ freq: f, dur: 0.35, type: 'triangle', gain: 0.12, delay: i * 0.08 }));
        break;
      case 'upgradeBuy':
        this.tone({ freq: 880, freqEnd: 1320, dur: 0.18, type: 'square', gain: 0.1, filter: 2400 });
        this.tone({ freq: 660, dur: 0.14, type: 'sine', gain: 0.1, delay: 0.06 });
        break;
      case 'stageUp':
        [392, 523, 659, 784].forEach((f, i) => this.tone({ freq: f, dur: 0.7, type: 'sine', gain: 0.11, delay: i * 0.12 }));
        break;
      case 'danger':
        this.tone({ freq: 880, dur: 0.12, type: 'square', gain: 0.07, filter: 2000 });
        this.tone({ freq: 660, dur: 0.12, type: 'square', gain: 0.07, filter: 2000, delay: 0.16 });
        break;
      case 'uiClick':
        this.tone({ freq: 720, freqEnd: 900, dur: 0.06, type: 'triangle', gain: 0.07 });
        break;
      case 'death':
        [330, 262, 196, 130].forEach((f, i) => this.tone({ freq: f, dur: 0.8, type: 'sine', gain: 0.14, delay: i * 0.18 }));
        break;
      case 'victory':
        [523, 659, 784, 1046, 1318, 1568].forEach((f, i) => this.tone({ freq: f, dur: 0.9, type: 'triangle', gain: 0.12, delay: i * 0.13 }));
        break;
      case 'predator':
        this.tone({ freq: 72, freqEnd: 48, dur: 1.2, type: 'sine', gain: 0.16 });
        this.noise({ dur: 1.0, gain: 0.08, filter: 300 });
        break;
      case 'dive':
        this.noise({ dur: 0.7, gain: 0.18, filter: 1800, sweepTo: 260 });
        break;
      case 'surface':
        this.noise({ dur: 0.7, gain: 0.2, filter: 300, sweepTo: 2200 });
        break;
      default: break;
    }
  }
}
