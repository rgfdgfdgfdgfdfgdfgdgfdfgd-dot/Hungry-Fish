// Игра: состояние, цикл, события, отладочный интерфейс.
import * as THREE from 'three';
import { Player, CameraRig } from './player.js';
import { World, visibility, camDist, terrainDepth, biomeWeights, QUALITY, IS_MOBILE, waveHeight } from './world.js';
const IS_TOUCH = IS_MOBILE || (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
import { FishManager } from './fish.js';
import { Entities } from './entities.js';
import { FX } from './fx.js';
import { GameAudio } from './audio.js';
import { UI, formatTime } from './ui.js';
import { buildFishGeometry } from './models.js';
import { stageFor, SURFACE_TARGETS, SPECIES, growthShare, healFor, fishXp } from './config.js';

export class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !IS_MOBILE, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, IS_MOBILE ? 1.5 : 1.75));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.shadowMap.enabled = false;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(58, 1, 0.05, 500);
    this.state = 'menu';
    this.time = 0;
    this.frame = 0;
    this.fps = 60;
    this.fpsAcc = 0; this.fpsFrames = 0;
    this.paused = false;
    this.skin = localStorage.getItem('hf_skin') || 'clown';
    this.god = false;
    this.touch = { boost: false, up: false, down: false };
    this.keys = {};
    this.mouse = { dx: 0, dy: 0, locked: false, dragging: false, lastX: 0, lastY: 0 };
    this.hintTimer = 0;
    this.messageCd = {};

    this.world = new World(this.scene, this.renderer);
    this.player = new Player(this);
    this.rig = new CameraRig(this.camera);
    this.fish = new FishManager(this.scene, this);
    this.entities = new Entities(this.scene, this);
    this.fx = new FX(this.scene);
    this.audio = new GameAudio();
    this.ui = new UI(this);
    this.buildPlayerMesh();
    this.bindInput();
    this.loadRecord();
    this.resize();
    window.addEventListener('resize', () => this.resize());
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === 'playing') this.pause();
    });

    // прогрев шейдеров
    this.player.pos.set(0, -16, 0);
    this.fish.reset();
    this.entities.reset();
    this.world.update(0.016, this.camera, this.player.pos, this.player.curSize, { force: true });
    this.rig.reset(this.player);
    this.renderer.compile(this.scene, this.camera);
    this.ui.showScreen('menu');
    this.ui.updateRecord(this.record);
    this.ui.updateHUD();
    this.clock = new THREE.Clock();
    this.loop = this.loop.bind(this);
    requestAnimationFrame(this.loop);
    window.__HF_READY = true;
  }

  // ---------- игрок-модель ----------
  buildPlayerMesh() {
    this.playerUniforms = { uTime: { value: 0 }, uAmp: { value: 0.07 } };
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.4, metalness: 0.15, side: THREE.DoubleSide });
    mat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.playerUniforms.uTime;
      sh.uniforms.uAmp = this.playerUniforms.uAmp;
      sh.vertexShader = 'uniform float uTime;\nuniform float uAmp;\nattribute float aSpine;\n' + sh.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        float sp = clamp(aSpine, 0.0, 1.0);
        float w = sin(sp * 5.0 - uTime * 6.0);
        transformed.x += w * uAmp * pow(sp, 1.6);
        transformed.y += cos(sp * 4.2 - uTime * 6.0) * uAmp * 0.2 * pow(sp, 2.0);
        `);
    };
    this.playerMat = mat;
    this.setSkin(this.skin, true);
  }

  setSkin(skin, initial = false) {
    this.skin = skin;
    localStorage.setItem('hf_skin', skin);
    if (this.playerMesh) this.scene.remove(this.playerMesh);
    const geo = buildFishGeometry(skin === 'shark' ? 'greatwhite' : 'clown', 'player');
    this.playerMesh = new THREE.Mesh(geo, this.playerMat);
    this.playerMesh.frustumCulled = false;
    this.scene.add(this.playerMesh);
    if (!initial) this.updateCharCards();
  }

  updateCharCards() {
    document.querySelectorAll('.charcard').forEach(c => c.classList.toggle('selected', c.dataset.char === this.skin));
  }

  // ---------- ввод ----------
  bindInput() {
    const onKey = (e, down) => {
      const k = e.key;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' ', 'Tab'].includes(k)) e.preventDefault();
      this.keys[k] = down;
      if (down) {
        if (k === 'Escape' || k === 'p' || k === 'P') this.togglePause();
        if (k === 'Tab') this.toggleUpgrades();
        this.audio.resume();
      }
    };
    window.addEventListener('keydown', (e) => onKey(e, true));
    window.addEventListener('keyup', (e) => onKey(e, false));
    this.canvas.addEventListener('click', () => {
      if (IS_MOBILE) return;
      this.audio.init(); this.audio.resume();
      if (this.state === 'playing' && document.pointerLockElement !== this.canvas) {
        this.canvas.requestPointerLock?.();
      }
    });
    document.addEventListener('pointerlockchange', () => {
      this.mouse.locked = document.pointerLockElement === this.canvas;
    });
    document.addEventListener('mousemove', (e) => {
      if (this.mouse.locked) { this.mouse.dx += e.movementX; this.mouse.dy += e.movementY; }
      else if (this.mouse.dragging) { this.mouse.dx += e.clientX - this.mouse.lastX; this.mouse.dy += e.clientY - this.mouse.lastY; this.mouse.lastX = e.clientX; this.mouse.lastY = e.clientY; }
    });
    this.canvas.addEventListener('mousedown', (e) => {
      if (IS_MOBILE) return;
      this.mouse.dragging = true; this.mouse.lastX = e.clientX; this.mouse.lastY = e.clientY;
      this.audio.init(); this.audio.resume();
    });
    window.addEventListener('mouseup', () => { this.mouse.dragging = false; });
    window.addEventListener('touchstart', () => { this.audio.init(); this.audio.resume(); }, { once: true });

    // кнопки интерфейса
    const click = (sel, fn) => { const el = document.querySelector(sel); if (el) el.addEventListener('click', () => { this.audio.init(); this.audio.play('uiClick'); fn(); }); };
    click('#btn-play', () => this.openIntro());
    click('#btn-start', () => this.startRun());
    click('#btn-back', () => this.ui.showScreen('menu'));
    click('#btn-howto', () => this.openGuide());
    click('#btn-pause-guide', () => this.openGuide());
    click('#btn-close-guide', () => this.closeGuide());
    click('#btn-pause', () => this.pause());
    click('#btn-resume', () => this.resume());
    click('#btn-upgrades', () => this.toggleUpgrades());
    click('#btn-pause-upg', () => this.toggleUpgrades());
    click('#btn-close-upg', () => this.resume());
    click('#btn-guide', () => this.ui.showScreen('guide'));
    click('#btn-restart', () => this.startRun());
    click('#btn-menu', () => this.toMenu());
    click('#btn-again', () => this.startRun());
    click('#btn-dead-menu', () => this.toMenu());
    click('#btn-continue', () => { this.state = 'playing'; this.ui.showScreen(null); });
    click('#btn-victory-menu', () => this.toMenu());
    click('#btn-sound', () => this.toggleSound());
    click('#btn-sound2', () => this.toggleSound());
    document.querySelectorAll('.charcard').forEach(c => c.addEventListener('click', () => {
      this.setSkin(c.dataset.char);
      this.audio.init(); this.audio.play('uiClick');
    }));
    document.querySelectorAll('.upgbtn').forEach(b => b.addEventListener('click', () => {
      if (this.player.buy(b.dataset.upg)) {
        this.audio.play('upgradeBuy');
        this.ui.updateUpgrades();
        this.ui.updateHUD();
      }
    }));
    this.updateCharCards();
  }

  toggleSound() {
    this.audio.init();
    this.audio.setEnabled(!this.audio.enabled);
    const label = 'Звук: ' + (this.audio.enabled ? 'вкл' : 'выкл');
    const b = document.querySelector('#btn-sound2');
    if (b) b.textContent = label;
    this.ui.el.soundBtn && (this.ui.el.soundBtn.textContent = this.audio.enabled ? '♪' : '✕');
  }

  getInput() {
    const k = this.keys, t = this.touch, ts = this.ui.touchState;
    let yaw = (k['a'] || k['A'] || k['ArrowLeft'] ? 1 : 0) - (k['d'] || k['D'] || k['ArrowRight'] ? 1 : 0);
    let pitch = (k[' '] || k['e'] || k['E'] || t.up ? 1 : 0) - (k['q'] || k['Q'] || k['Control'] || k['ControlLeft'] || t.down ? 1 : 0);
    yaw += ts.active ? ts.x : 0;
    pitch += ts.active ? -ts.y * 0.85 : 0;
    const fwd = k['w'] || k['W'] || k['ArrowUp'];
    const back = k['s'] || k['S'] || k['ArrowDown'];
    let thrust = fwd ? 1 : back ? -1 : 0;
    if (ts.active && ts.y < -0.35) thrust = 1;
    const boost = !!(k['Shift'] || k['shift'] || t.boost);
    const inp = {
      yaw: Math.max(-1, Math.min(1, yaw)),
      pitch: Math.max(-1, Math.min(1, pitch)),
      thrust,
      boost,
      mouseDX: this.mouse.dx,
      mouseDY: this.mouse.dy,
    };
    this.mouse.dx = 0; this.mouse.dy = 0;
    return inp;
  }

  // ---------- управление состоянием ----------
  openIntro() {
    this.state = 'intro';
    this.ui.showScreen('intro');
    this.ui.setTouchVisible(false);
  }

  startRun() {
    this.audio.init();
    this.loadRecord();
    this.player.reset();
    this.player.pos.set(0, -16, 0);
    this.player.yaw = 0; this.player.pitch = 0;
    this.runTime = 0;
    this.victoryShown = false;
    this.world.time = 0;
    this.fish.reset();
    this.entities.reset();
    this.world.update(0.016, this.camera, this.player.pos, this.player.curSize, { force: true });
    this.rig.reset(this.player);
    this.state = 'playing';
    this.ui.showScreen(null);
    this.ui.setTouchVisible(IS_TOUCH);
    this.ui.hint(IS_MOBILE ? 'Джойстик — курс, кнопки справа — глубина и рывок' : 'W — вперёд · Shift — рывок · Space/Q — глубина · Tab — улучшения');
    this.hintTimer = 30;
    this.ui.updateHUD();
    this.audio.play('dive');
    this.audio.setUnderwater(true);
  }

  toMenu() {
    this.saveRecord();
    this.state = 'menu';
    this.player.reset();
    this.player.pos.set(0, -16, 0);
    this.fish.reset();
    this.entities.reset();
    this.world.update(0.016, this.camera, this.player.pos, this.player.curSize, { force: true });
    this.ui.showScreen('menu');
    this.ui.setTouchVisible(false);
    this.ui.updateRecord(this.record);
    if (document.pointerLockElement) document.exitPointerLock();
  }

  pause() {
    if (this.state !== 'playing') return;
    this.state = 'paused';
    this.saveRecord();
    this.ui.el.pauseStats.innerHTML = this.ui.statsHTML();
    this.ui.showScreen('pause');
    this.ui.setTouchVisible(false);
  }

  resume() {
    if (this.state === 'playing') return;
    this.state = 'playing';
    this.ui.showScreen(null);
    this.ui.setTouchVisible(true);
  }

  togglePause() {
    if (this.state === 'playing') this.pause();
    else if (this.state === 'paused') this.resume();
    else if (this.state === 'guide' || this.state === 'upgrades') this.resume();
  }

  toggleUpgrades() {
    if (this.state === 'playing' || this.state === 'paused') {
      this.state = 'upgrades';
      this.ui.updateUpgrades();
      this.ui.showScreen('upgrades');
      this.ui.setTouchVisible(false);
    } else if (this.state === 'upgrades') this.resume();
  }

  openGuide() {
    if (this.state === 'guide') return;
    this.prevState = this.state;
    this.state = 'guide';
    this.ui.showScreen('guide');
    this.ui.setTouchVisible(false);
  }

  closeGuide() {
    const prev = this.prevState || 'menu';
    if (prev === 'playing') { this.state = 'playing'; this.ui.showScreen(null); this.ui.setTouchVisible(IS_TOUCH); }
    else if (prev === 'paused') { this.state = 'paused'; this.ui.showScreen('pause'); }
    else if (prev === 'intro') { this.state = 'intro'; this.ui.showScreen('intro'); }
    else { this.state = 'menu'; this.ui.showScreen('menu'); }
  }

  closeOverlay() {
    this.closeGuide();
  }

  // ---------- события ----------
  showMessage(title, sub = '', cls = '') { this.ui.message(title, sub, cls); }

  onEat({ name, xp, size, big }) {
    if (this.menuMode) return;
    this.ui.message(`+${xp} опыта`, name, '');
    if (big) this.audio.play('eatBig'); else this.audio.play('eatSmall');
    if (this.player.eaten === 2) this.ui.hint('Открой улучшения на Tab и потрать очко');
  }

  onLevelUp(n) {
    if (this.menuMode) return;
    this.audio.play('levelUp');
    this.fx.levelUp(this.player.pos, this.player.curSize);
    this.ui.message('НОВЫЙ УРОВЕНЬ', `Очков улучшений: ${this.player.points}`, 'level');
    this.ui.updateHUD();
  }

  onPlayerHurt(dmg) {
    if (this.menuMode) return;
    this.ui.flashDamage();
    const src = this.player.lastDamage?.source || 'Удар';
    const now = this.time;
    if (this._lastHurt && now - this._lastHurt < 1.1) {
      this._hurtSum = (this._hurtSum || 0) + dmg;
      return;
    }
    this._lastHurt = now;
    this._hurtSum = dmg;
    this.ui.message(`−${Math.round(dmg)} здоровья`, src, 'hurt');
    this.ui.updateHUD();
  }

  onThreatNotice(f) {
    if (this.state !== 'playing') return;
    const now = this.time;
    if (this.messageCd.threat && now - this.messageCd.threat < 4) return;
    this.messageCd.threat = now;
    this.audio.play('danger');
  }

  onVictory() {
    if (this.menuMode || this.victoryShown) return;
    this.victoryShown = true;
    this.audio.play('victory');
    this.saveRecord();
    setTimeout(() => {
      if (this.player.dead) return;
      this.state = 'victory';
      document.querySelector('#victorystats').innerHTML = this.ui.statsHTML();
      this.ui.showScreen('victory');
      this.ui.setTouchVisible(false);
      if (document.pointerLockElement) document.exitPointerLock();
    }, 400);
  }

  onDeath() {
    this.audio.play('death');
    this.saveRecord();
    document.querySelector('#cause').textContent = 'Причина: ' + (this.player.lastDamage?.source || 'океан');
    document.querySelector('#deadstats').innerHTML = this.ui.statsHTML();
    setTimeout(() => {
      this.state = 'dead';
      this.ui.showScreen('dead');
      this.ui.setTouchVisible(false);
      if (document.pointerLockElement) document.exitPointerLock();
    }, 1200);
  }

  checkEating() {
    const p = this.player;
    const L = p.curSize;
    const growMul = 1 + 0.10 * p.upg.size;
    for (const f of this.fish.fish) {
      if (!f.alive || f.size > L) continue;
      const dx = f.pos.x - p.pos.x, dy = f.pos.y - p.pos.y, dz = f.pos.z - p.pos.z;
      const hd = Math.hypot(dx, dz);
      const boostBonus = p.boosting ? 1.06 : 1;
      const contactH = (L * 0.55 + f.size * 0.6) * boostBonus;
      const contactV = L * 0.42 + f.size * 0.35;
      if (hd < contactH && Math.abs(dy) < contactV) {
        this.eatFish(f);
      }
    }
  }

  eatFish(f) {
    const p = this.player;
    const perm = p.permSize;
    const grow = f.size * growthShare(perm) * (1 + 0.10 * p.upg.size);
    p.baseLen += grow;
    p.heal(healFor(f.size));
    const xp = fishXp(f.size, perm, SPECIES[f.species].temper);
    const ups = p.addXp(xp);
    p.eaten++;
    p.eatFlash = 0.25;
    f.alive = false;
    this.fx.eat(f.pos.clone(), f.size, (f.size > 1.5 ? 0xffe08a : 0xa8f0d0));
    this.audio.play(f.size > 2 ? 'eatBig' : 'eatSmall');
    this.onEat({ name: SPECIES[f.species].name + (f.giant ? '-гигант' : ''), xp, size: f.size, big: f.size > 2 });
    if (ups > 0) this.onLevelUp(ups);
  }

  allowHunt() {
    return !this.menuMode && this.player.runTime > 5;
  }

  targetAssist(player) {
    if (this.state !== 'playing') return null;
    const t = this._assistTarget && this._assistTarget.alive ? this._assistTarget : null;
    const target = t || this.fish.bestTarget(player, Math.max(6, player.curSize * 6));
    if (!target) return null;
    if (target.size > player.curSize || (target.pos.distanceTo(player.pos) > Math.max(6, player.curSize * 6))) {
      this._assistTarget = null;
      return null;
    }
    this._assistTarget = target;
    const dir = target.pos.clone().sub(player.pos).normalize();
    return { dir, strength: 0.32 };
  }

  // ---------- рекорд ----------
  loadRecord() {
    try { this.record = JSON.parse(localStorage.getItem('hf_record') || 'null'); } catch { this.record = null; }
  }
  saveRecord() {
    if (!this.player || this.player.permSize <= 0.79) return;
    if (!this.record || this.player.permSize > this.record.size) {
      this.record = { size: this.player.permSize, eaten: this.player.eaten, level: this.player.level };
      localStorage.setItem('hf_record', JSON.stringify(this.record));
      this.ui.updateRecord(this.record);
    }
  }

  // ---------- отрисовка и цикл ----------
  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  updateCameraParams() {
    const L = this.player.curSize;
    const V = visibility(L);
    const above = this.camera.position.y > -0.15;
    this.camera.near = Math.max(0.04 * L, 0.03);
    this.camera.far = above ? 9000 : Math.max(1.6 * V, 120);
    this.camera.updateProjectionMatrix();
  }

  update(dt) {
    this.time += dt;
    const p = this.player;
    const playing = this.state === 'playing';
    if (playing && !this.god) {
      // всё идёт своим ходом
    }
    this.world.L = p.curSize;
    if (playing) {
      const inp = this.getInput();
      p.update(dt, inp, this);
      this.fish.update(dt, p, this);
      this.checkEating();
      this.fish.replaceDead();
      this.entities.update(dt, p, this);
      if (p.dead) this.onDeath();
    } else if (this.state === 'menu' || this.state === 'intro') {
      // живое меню: рыба плавает по кругу
      p.yaw += dt * 0.16;
      p.pos.x += Math.sin(p.yaw) * dt * 0.5;
      p.pos.z += Math.cos(p.yaw) * dt * 0.5;
      this.menuMode = true;
      this.fish.update(dt, p, this);
      this.fish.replaceDead();
      this.entities.update(dt, p, this);
      this.menuMode = false;
    }
    // модель рыбы
    this.playerMesh.position.copy(p.pos);
    this.playerMesh.quaternion.copy(p.quaternion());
    this.playerMesh.scale.setScalar(p.curSize);
    this.playerMesh.visible = !(p.dead && this.state === 'dead');
    this.playerUniforms.uAmp.value += ((p.boosting ? 0.14 : 0.07) - this.playerUniforms.uAmp.value) * Math.min(1, dt * 6);
    this.playerUniforms.uTime.value += dt * (p.boosting ? 1.5 : 1);

    // камера
    if (this.state === 'menu' || this.state === 'intro') {
      const D = camDist(p.curSize) * 1.45;
      const wide = window.innerWidth > 820;
      this.camera.position.set(p.pos.x + Math.sin(p.yaw + Math.PI) * D, p.pos.y + D * 0.26, p.pos.z + Math.cos(p.yaw + Math.PI) * D);
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
      const look = p.pos.clone();
      if (wide) look.addScaledVector(new THREE.Vector3(-Math.cos(p.yaw), 0, Math.sin(p.yaw)).normalize(), D * 0.55);
      this.camera.lookAt(look.x, look.y - 0.05, look.z);
      this.rig.smoothPos.copy(this.camera.position);
    } else {
      this.rig.update(dt, p, this, this.camera.aspect);
    }
    this.updateCameraParams();

    if (this.state !== 'paused' && this.state !== 'upgrades' && this.state !== 'guide' && this.state !== 'dead' && this.state !== 'victory') {
      this.world.update(dt, this.camera, p.pos, p.curSize);
      this.fx.update(dt);
      this.fx.cameraQuat = this.camera.quaternion;
      const under = this.camera.position.y < 0;
      this.audio.setUnderwater(under);
      if (p.boosting && Math.random() < dt * 8) {
        this.fx.spawn(p.pos.x, p.pos.y, p.pos.z, (Math.random() - 0.5), (Math.random() - 0.5), (Math.random() - 0.5),
          0.7, 0.9, 1, 0.06 * p.curSize, 0.5, 2);
      }
      if (this.state === 'playing') {
        if (this.hintTimer > 0) {
          this.hintTimer -= dt;
          if (this.hintTimer <= 0) this.ui.hint('');
        }
      }
    }
    if (this.state === 'playing') {
      this.ui.updateHUD();
      this.ui.updateMarkers(dt);
      this.ui.drawSonar();
    }
  }

  loop() {
    requestAnimationFrame(this.loop);
    const dtRaw = Math.min(0.05, this.clock.getDelta());
    this.fpsAcc += dtRaw; this.fpsFrames++;
    if (this.fpsAcc > 0.5) { this.fps = this.fpsFrames / this.fpsAcc; this.fpsAcc = 0; this.fpsFrames = 0; this.adaptQuality(); }
    this.update(dtRaw);
    this.renderer.render(this.scene, this.camera);
    this.frame++;
    this.ui && this.ui.updateMarkers && this.state !== 'playing' && this.hideMarkers();
  }

  hideMarkers() {
    for (const m of this.ui.markerPool) m.el.style.display = 'none';
  }

  adaptQuality() {
    if (!IS_MOBILE) return;
    if (this.fps < 42) {
      this.lowPerf = (this.lowPerf || 0) + 1;
      if (this.lowPerf > 3 && this.renderer.getPixelRatio() > 0.62) {
        this.renderer.setPixelRatio(Math.max(0.62, this.renderer.getPixelRatio() - 0.15));
        this.renderer.setSize(window.innerWidth, window.innerHeight, false);
        this.lowPerf = 0;
      }
    } else this.lowPerf = 0;
  }

  // ---------- отладка ----------
  info() {
    const p = this.player;
    const camDistActual = this.camera.position.distanceTo(p.pos);
    const r = this.renderer.info.render;
    const decor = this.world.decor;
    let fishWithin30 = 0;
    for (const f of this.fish.fish) if (f.alive && f.pos.distanceTo(p.pos) < 30) fishWithin30++;
    return {
      state: this.state,
      time: this.time,
      size: p.curSize,
      permSize: p.permSize,
      pos: [p.pos.x, p.pos.y, p.pos.z],
      depth: -p.pos.y,
      fogNear: this.scene.fog ? this.scene.fog.near : 0,
      fogFar: this.scene.fog ? this.scene.fog.far : 0,
      visibility: visibility(p.curSize),
      fov: this.camera.fov,
      camDist: camDistActual,
      camUp: this.camera.position.y - p.pos.y,
      drawCalls: r.calls,
      triangles: r.triangles,
      fps: this.fps,
      decorWithin: {
        5: decor.countWithin(5), 10: decor.countWithin(10), 20: decor.countWithin(20), 40: decor.countWithin(40),
      },
      fishWithin30,
      terrainDepth: terrainDepth(p.pos.x, p.pos.z, p.curSize),
      biome: biomeWeights(p.pos.x, p.pos.z),
      stage: stageFor(p.permSize).name,
      hp: p.hp, level: p.level, xp: p.xp, points: p.points, eaten: p.eaten,
      bombs: this.entities.bombs.length, shells: this.entities.shells.length, harpoons: this.entities.harpoons.length,
      chests: this.entities.chests.length, fishCount: this.fish.fish.length,
    };
  }

  setSize(m) {
    const p = this.player;
    p.baseLen = m / (1 + 0.10 * p.upg.size);
    p.maxHp = 100 + 45 * p.upg.hp;
    p.hp = p.maxHp;
    p.dead = false;
    this.world.update(0.016, this.camera, p.pos, p.curSize, { force: true });
    this.fish.reset();
    this.entities.reset();
    this.rig.reset(p);
  }

  tp(x, y, z) {
    this.player.pos.set(x, y, z);
    this.player.vel.set(0, 0, 0);
    this.world.update(0.016, this.camera, this.player.pos, this.player.curSize, { force: true });
    this.rig.reset(this.player);
  }

  snapshot() {
    this.renderer.render(this.scene, this.camera);
    return this.canvas.toDataURL('image/png');
  }

  camClearanceCheck(seconds = 60) {
    let bad = 0, minMargin = 1e9;
    const steps = Math.floor(seconds * 60);
    for (let i = 0; i < steps; i++) {
      this.update(1 / 60);
      const cam = this.camera.position;
      const bottom = -terrainDepth(cam.x, cam.z, this.world.L);
      const margin = cam.y - bottom;
      if (margin < 0) bad++;
      if (margin < minMargin) minMargin = margin;
    }
    return { bad, minMargin };
  }

  terrainRelief(cx = 0, cz = 0, r = 60, n = 180) {
    let min = 1e9, max = -1e9;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      const rr = r * (0.25 + 0.75 * ((i * 37) % 100) / 100);
      const d = terrainDepth(cx + Math.cos(a) * rr, cz + Math.sin(a) * rr, this.player.curSize);
      min = Math.min(min, d); max = Math.max(max, d);
    }
    const center = terrainDepth(cx, cz, this.player.curSize);
    min = Math.min(min, center); max = Math.max(max, center);
    return { min, max, range: max - min };
  }

  simulate(seconds, dt = 1 / 60) {
    const steps = Math.floor(seconds / dt);
    const saved = this.getInput = () => ({ yaw: 0, pitch: 0, thrust: 0, boost: false, mouseDX: 0, mouseDY: 0 });
    for (let i = 0; i < steps; i++) {
      this.update(dt);
      this.world.update(dt, this.camera, this.player.pos, this.player.curSize);
    }
    this.getInput = saved;
  }
}
