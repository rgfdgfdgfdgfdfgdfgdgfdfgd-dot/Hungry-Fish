// Поверхностные цели, водолазы в клетках, оружие крейсера, сундуки.
import * as THREE from 'three';
import { SURFACE_TARGETS, levelCost } from './config.js';
import { buildShipGeometry, buildCageGeometry, buildDiverGeometry, buildChestGeometry } from './models.js';
import { terrainDepth, waveHeight, depthScale, clamp, visibility } from './world.js';
import { mulberry32 } from './noise.js';

const tmpV = new THREE.Vector3();

export class Entities {
  constructor(scene, game) {
    this.scene = scene;
    this.game = game;
    this.rnd = mulberry32(4242);
    this.geos = {};
    for (const k of ['swimmer', 'boat', 'yacht', 'cargo', 'cruiser']) this.geos[k] = buildShipGeometry(k);
    this.mats = {
      swimmer: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8 }),
      ship: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.55, metalness: 0.05 }),
    };
    this.targets = [];
    this.cages = [];
    this.bombs = [];
    this.shells = [];
    this.harpoons = [];
    this.chests = [];
    this.cageGeo = buildCageGeometry();
    this.diverGeo = buildDiverGeometry();
    this.chestGeo = buildChestGeometry();
    this.bombGeo = new THREE.SphereGeometry(1, 10, 8);
    this.bombMat = new THREE.MeshStandardMaterial({ color: '#4a5560', emissive: new THREE.Color('#ff5a3c'), emissiveIntensity: 0.9, roughness: 0.5 });
    this.warnGeo = new THREE.SphereGeometry(1, 12, 8);
    this.warnMat = new THREE.MeshBasicMaterial({ color: '#ff4d4d', transparent: true, opacity: 0.16, depthWrite: false, side: THREE.DoubleSide });
    this.shellGeo = new THREE.SphereGeometry(0.5, 8, 6);
    this.shellMat = new THREE.MeshStandardMaterial({ color: '#3a4048', emissive: new THREE.Color('#ff9a3c'), emissiveIntensity: 0.8 });
    this.harpoonGeo = new THREE.CylinderGeometry(0.08, 0.08, 1, 5);
    this.harpoonMat = new THREE.MeshStandardMaterial({ color: '#79d9ff', emissive: new THREE.Color('#4fc9ff'), emissiveIntensity: 1.1 });
    this.chestMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6, metalness: 0.15, emissive: new THREE.Color('#3a2a08'), emissiveIntensity: 0.6 });
    this.warnGroup = new THREE.Group();
    scene.add(this.warnGroup);
    this.warningZones = [];
    this.chestGlows = [];
    this.buildWarnings();
  }

  buildWarnings() {
    // пул предупреждающих зон
    for (let i = 0; i < 10; i++) {
      const m = new THREE.Mesh(this.warnGeo, this.warnMat.clone());
      m.visible = false;
      m.renderOrder = 2;
      this.scene.add(m);
      this.warningZones.push(m);
    }
  }

  reset() {
    for (const t of this.targets) this.scene.remove(t.mesh);
    for (const c of this.cages) { this.scene.remove(c.group); }
    for (const c of this.chests) this.scene.remove(c.group);
    for (const b of this.bombs) this.scene.remove(b.mesh), this.scene.remove(b.warn);
    for (const s of this.shells) this.scene.remove(s.mesh);
    for (const h of this.harpoons) this.scene.remove(h.mesh);
    for (const w of this.warningZones) w.visible = false;
    this.targets.length = 0;
    this.cages.length = 0;
    this.chests.length = 0;
    this.bombs.length = 0;
    this.shells.length = 0;
    this.harpoons.length = 0;
    this.chestTimer = 0;
    for (const k of ['swimmer', 'boat', 'yacht', 'cargo', 'cruiser']) {
      for (let i = 0; i < SURFACE_TARGETS[k].count; i++) this.spawnSurface(k, true);
    }
    for (const c of this.cages) c.active = true;
    // 3 сундука
    for (let i = 0; i < 3; i++) this.spawnChest(true);
  }

  spawnSurface(kind, initial = false) {
    const cfg = SURFACE_TARGETS[kind];
    const p = this.game.player;
    const L = p.curSize;
    const base = initial ? cfg.minDist : Math.max(cfg.minDist, 20 * L);
    const ang = this.rnd() * Math.PI * 2;
    const dist = base + this.rnd() * base * 0.8;
    const x = p.pos.x + Math.cos(ang) * dist;
    const z = p.pos.z + Math.sin(ang) * dist;
    const geo = this.geos[kind];
    const mesh = new THREE.Mesh(geo, kind === 'swimmer' ? this.mats.swimmer : this.mats.ship);
    const scale = configScale(kind, cfg.size);
    mesh.scale.set(scale.x, scale.y, scale.z);
    mesh.frustumCulled = true;
    this.scene.add(mesh);
    const t = {
      kind, size: cfg.size, x, z, heading: this.rnd() * Math.PI * 2, mesh,
      speed: cfg.speed, bob: this.rnd() * 10, grace: initial ? 0 : 3, hp: 0, ship: null, eaten: false,
    };
    mesh.userData.target = t;
    this.targets.push(t);
    if (kind === 'cruiser') {
      const cage = this.makeCage(t);
      this.cages.push(cage);
    }
    return t;
  }

  makeCage(cruiser) {
    const group = new THREE.Group();
    const cageMesh = new THREE.Mesh(this.cageGeo, this.mats.ship);
    cageMesh.scale.setScalar(1.6);
    group.add(cageMesh);
    const diver = new THREE.Mesh(this.diverGeo, this.mats.swimmer);
    diver.scale.setScalar(2.2);
    diver.position.y = -0.1;
    group.add(diver);
    this.scene.add(group);
    return { group, diver, cruiser, active: true, yaw: 0, size: SURFACE_TARGETS.diver.size, grace: 3, prep: 0, cooldown: 2 + this.rnd() * 3, target: new THREE.Vector3(), state: 'idle' };
  }

  spawnChest(initial = false) {
    const p = this.game.player;
    const L = p.curSize;
    const minR = Math.max(160, L * 8);
    let x = 0, z = 0, d = 0;
    for (let i = 0; i < 40; i++) {
      const a = this.rnd() * Math.PI * 2;
      const r = minR + this.rnd() * (initial ? 260 : 400);
      x = p.pos.x + Math.cos(a) * r;
      z = p.pos.z + Math.sin(a) * r;
      if (Math.hypot(x, z) > 2600) continue;
      d = terrainDepth(x, z, this.game.world.L);
      let ok = true;
      for (const c of this.chests) if (Math.hypot(c.x - x, c.z - z) < 100) ok = false;
      if (ok) break;
    }
    const group = new THREE.Group();
    const mesh = new THREE.Mesh(this.chestGeo, this.chestMat);
    const s = Math.max(1, L * 0.5);
    mesh.scale.setScalar(s);
    group.add(mesh);
    const glow = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 8),
      new THREE.MeshBasicMaterial({ color: '#ffd76a', transparent: true, opacity: 0.3, depthWrite: false }));
    glow.scale.setScalar(1.6 * s);
    group.add(glow);
    group.position.set(x, -d + 0.5 * s, z);
    this.scene.add(group);
    const chest = { x, z, y: -d + 0.5 * s, group, mesh, glow, size: 3 * s, opened: false, timer: 0, spawnTime: this.game.time };
    this.chests.push(chest);
    return chest;
  }

  // ---------------- обновление ----------------
  update(dt, player, game) {
    const L = player.curSize;
    const menu = !!game.menuMode;
    this.updateTargets(dt, player, game, L, menu);
    this.updateCages(dt, player, game, L, menu);
    this.updateBombs(dt, player, game, L, menu);
    this.updateShells(dt, player, game, L, menu);
    this.updateHarpoons(dt, player, game, L, menu);
    this.updateChests(dt, player, game, L, menu);
    this.cleanupWarnings();
  }

  updateTargets(dt, player, game, L, menu) {
    const t0 = game.time;
    for (let i = this.targets.length - 1; i >= 0; i--) {
      const t = this.targets[i];
      if (t.eaten) {
        this.scene.remove(t.mesh);
        this.targets.splice(i, 1);
        this.spawnSurface(t.kind);
        continue;
      }
      if (t.grace > 0) t.grace -= dt;
      t.heading += Math.sin(t0 * 0.08 + t.bob) * dt * 0.06;
      t.x += -Math.sin(t.heading) * t.speed * dt;
      t.z += -Math.cos(t.heading) * t.speed * dt;
      const y = waveHeight(t.x, t.z, t0) * 0.9;
      t.mesh.position.set(t.x, y, t.z);
      t.mesh.rotation.set(
        Math.sin(t0 * 0.9 + t.bob) * 0.03,
        t.heading,
        Math.sin(t0 * 0.7 + t.bob * 0.7) * 0.045
      );
      // слишком далеко — заменить
      const dist = Math.hypot(t.x - player.pos.x, t.z - player.pos.z);
      if (dist > Math.max(2200, 40 * L)) { t.eaten = true; }

      // поедание
      const contactH = t.size * 0.5 + L * 0.6;
      const near = Math.hypot(t.x - player.pos.x, t.z - player.pos.z) < contactH;
      const depthOk = Math.abs(player.pos.y - y) < t.size * 0.35 + L * 0.7;
      if (near && depthOk && t.grace <= 0 && !menu) {
        if (t.size <= L) {
          this.eatSurface(t, player, game);
        } else if (t.kind !== 'swimmer') {
          // столкновение с корпусом
          if (!t.hitCd || t0 > t.hitCd) {
            t.hitCd = t0 + 1.6;
            if (player.damage(18, 'Столкновение с корпусом')) {
              game.fx.hit(player.pos, L);
              game.audio.play('bitePlayer');
              game.onPlayerHurt(18);
              player.pos.y -= L * 0.4;
            }
          }
        }
      }
      // оружие крейсера
      if (t.kind === 'cruiser' && t.grace <= 0 && !menu) this.cruiserWeapons(dt, t, player, game, L);
    }
  }

  eatSurface(t, player, game) {
    t.eaten = true;
    const cfg = SURFACE_TARGETS[t.kind];
    const perm = player.permSize;
    player.addGrowth(cfg.growth * (1 + 0.10 * player.upg.size));
    player.heal(5 + 1.8 * t.size);
    const ups = player.addXp(cfg.xp);
    player.eaten++;
    game.fx.eat(new THREE.Vector3(t.x, 0.5, t.z), t.size, 0xffe08a);
    game.audio.play(t.size > 10 ? 'eatBig' : 'eatSmall');
    game.onEat({ name: cfg.name, xp: cfg.xp, size: t.size, big: t.size > 5 });
    if (ups > 0) game.onLevelUp(ups);
    if (t.kind === 'cruiser') {
      game.onVictory();
      for (const c of this.cages) if (c.cruiser === t) c.active = false, this.scene.remove(c.group);
      this.cages = this.cages.filter(c => c.cruiser !== t);
      this.bombs = this.bombs.filter(b => b.owner !== t);
    }
    if (t.kind === 'swimmer') game.audio.play('splash');
  }

  cruiserWeapons(dt, t, player, game, L) {
    t.bombCd = (t.bombCd ?? 2) - dt;
    t.cannonCd = (t.cannonCd ?? 3) - dt;
    const dx = player.pos.x - t.x, dz = player.pos.z - t.z;
    const hdist = Math.hypot(dx, dz);
    // глубинные бомбы
    if (hdist < 260 + 0.9 * L && t.bombCd <= 0 && this.bombs.length < 8) {
      t.bombCd = 3.5 + this.rnd() * 2.5;
      this.dropBomb(t, player, game, L);
    }
    // пушка — когда рыба у поверхности
    if (hdist < 420 + 1.2 * L && player.pos.y > -6 - L * 0.4 && t.cannonCd <= 0 && (this.shells.length + this.harpoons.length) < 14) {
      t.cannonCd = 4 + this.rnd() * 2;
      this.fireCannon(t, player, game, L);
    }
  }

  dropBomb(cruiser, player, game, L) {
    const lead = 3.0;
    const px = player.pos.x + player.vel.x * lead * 0.35;
    const pz = player.pos.z + player.vel.z * lead * 0.35;
    const py = player.pos.y;
    const radius = clamp(0.45 * L, 6, 25);
    const mesh = new THREE.Mesh(this.bombGeo, this.bombMat);
    mesh.scale.setScalar(Math.max(0.5, Math.min(3, 0.02 * L)));
    this.scene.add(mesh);
    const warn = new THREE.Mesh(this.warnGeo, this.warnMat.clone());
    warn.scale.setScalar(radius);
    warn.position.set(px, py, pz);
    warn.renderOrder = 2;
    this.scene.add(warn);
    this.bombs.push({
      mesh, warn, owner: cruiser,
      start: new THREE.Vector3(cruiser.x, 0, cruiser.z), target: new THREE.Vector3(px, py, pz),
      pos: new THREE.Vector3(cruiser.x, 0, cruiser.z),
      flight: 0, fall: 0.8, descend: 1.6, timer: 3.5, radius, exploded: false, total: 3.5,
    });
    game.audio.play('bombDrop');
    game.audio.play('danger');
  }

  fireCannon(cruiser, player, game, L) {
    this.cannonShots = (this.cannonShots || 0) + 1;
    const lead = new THREE.Vector3(player.pos.x + player.vel.x * 1.0, 0, player.pos.z + player.vel.z * 1.0);
    const mesh = new THREE.Mesh(this.warnGeo, this.warnMat.clone());
    const radius = clamp(0.1 * L, 5, 14);
    mesh.scale.set(radius, 0.4, radius);
    mesh.position.set(lead.x, -0.5, lead.z);
    mesh.visible = true;
    this.scene.add(mesh);
    const shell = {
      mesh: new THREE.Mesh(this.shellGeo, this.shellMat),
      state: 'prep', t: 0, prep: 1.7, dist: 1.25, radius,
      from: new THREE.Vector3(cruiser.x, 4, cruiser.z),
      to: lead, warn: mesh, player,
      startPos: new THREE.Vector3(cruiser.x, 0, cruiser.z),
    };
    shell.mesh.visible = false;
    this.scene.add(shell.mesh);
    this.shells.push(shell);
    game.audio.play('cannonShot');
  }

  updateBombs(dt, player, game, L, menu) {
    for (let i = this.bombs.length - 1; i >= 0; i--) {
      const b = this.bombs[i];
      b.timer -= dt;
      if (b.flight < b.fall) {
        b.flight += dt;
        const f = b.flight / b.fall;
        b.pos.lerpVectors(b.start, new THREE.Vector3(b.target.x, 0, b.target.z), f);
        b.pos.y = Math.sin(f * Math.PI) * 6 + waveHeight(b.pos.x, b.pos.z, game.time);
      } else if (b.timer > 0) {
        const descend = clamp(1 - b.timer / 2.0, 0, 1);
        b.pos.y = 0 + (b.target.y - 0) * descend;
      }
      b.mesh.position.copy(b.pos);
      b.mesh.scale.setScalar(Math.max(0.5, Math.min(3, 0.02 * L)) * (1 + Math.sin(game.time * 20) * 0.08));
      if (b.warn) {
        b.warn.material.opacity = 0.12 + 0.16 * Math.abs(Math.sin(game.time * 6));
        b.warn.scale.setScalar(b.radius * (1 + Math.sin(game.time * 4) * 0.03));
      }
      if (b.timer <= 0 && !b.exploded) {
        b.exploded = true;
        game.fx.explosion(b.target, b.radius);
        game.audio.play('bombExplode');
        const dist = player.pos.distanceTo(b.target);
        const hitR = b.radius + 0.22 * L;
        if (dist < hitR) {
          const f = clamp(dist / hitR, 0, 1);
          const dmg = Math.round(85 * (1 - 0.55 * f));
          if (player.damage(dmg, 'Глубинная бомба')) {
            game.onPlayerHurt(dmg);
            game.fx.hit(player.pos, L);
          }
        }
        this.scene.remove(b.mesh);
        if (b.warn) this.scene.remove(b.warn);
        this.bombs.splice(i, 1);
      }
    }
  }

  updateShells(dt, player, game, L, menu) {
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i];
      s.t += dt;
      if (s.state === 'prep') {
        s.warn.material.opacity = 0.14 + 0.14 * Math.abs(Math.sin(game.time * 8));
        if (s.t >= s.prep) {
          s.state = 'fly'; s.t = 0;
          s.mesh.visible = true;
          s.from.set(s.startPos.x, 4, s.startPos.z);
        }
      } else if (s.state === 'fly') {
        const f = Math.min(1, s.t / s.dist);
        s.mesh.position.lerpVectors(s.from, s.to, f);
        s.mesh.position.y += Math.sin(f * Math.PI) * 40;
        if (f >= 1) {
          // попадание
          s.state = 'done';
          game.fx.splash(s.to, s.radius);
          game.audio.play('shellSplash');
          const d = Math.hypot(player.pos.x - s.to.x, player.pos.z - s.to.z);
          const hitR = s.radius + 0.15 * L;
          if (d < hitR && player.pos.y > -s.radius * 1.6) {
            if (player.damage(60, 'Снаряд пушки')) { game.onPlayerHurt(60); game.fx.hit(player.pos, L); }
          }
          this.scene.remove(s.mesh);
          this.scene.remove(s.warn);
          this.shells.splice(i, 1);
        }
      }
    }
  }

  updateHarpoons(dt, player, game, L, menu) {
    // подготовка гарпунов у водолазов
    for (const c of this.cages) {
      if (!c.active) continue;
      const d = c.group.position.distanceTo(player.pos);
      c.cooldown -= dt;
      if (c.state === 'prep') {
        c.prep -= dt;
        if (c.prep <= 0) {
          c.state = 'idle';
          const dir = c.target.clone().sub(c.group.position).normalize();
          const dist = c.target.distanceTo(c.group.position);
          const mesh = new THREE.Mesh(this.harpoonGeo, this.harpoonMat);
          mesh.position.copy(c.group.position);
          mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
          mesh.scale.set(1, Math.max(1, L * 0.4), 1);
          this.scene.add(mesh);
          this.harpoons.push({
            mesh, pos: c.group.position.clone(), dir,
            speed: dist / clamp(0.65 + dist / 200, 0.65, 2), t: 0, life: 2.2,
          });
          game.audio.play('harpoonShot');
        }
      } else if (d < 230 + 0.7 * L && player.pos.y < -0.2 * L && c.cooldown <= 0 && (this.harpoons.length + this.shells.length) < 14) {
        c.cooldown = 3.5 + this.rnd() * 2;
        c.state = 'prep'; c.prep = 1.2;
        c.target.copy(player.pos).addScaledVector(player.vel, 0.45);
        game.audio.play('danger');
      }
      if (c.state === 'prep') {
        // луч предупреждения
        const seg = this.warningZones[this.warningZones.length - 1];
        seg.visible = true;
        const mid = c.group.position.clone().lerp(c.target, 0.5);
        seg.position.copy(mid);
        seg.scale.set(0.25, c.group.position.distanceTo(c.target) * 0.5, 0.25);
        seg.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), c.target.clone().sub(c.group.position).normalize());
        seg.material.color.set('#4fc9ff');
        seg.userData.keep = game.time;
      }
    }
    for (let i = this.harpoons.length - 1; i >= 0; i--) {
      const h = this.harpoons[i];
      h.t += dt;
      h.pos.addScaledVector(h.dir, h.speed * dt);
      h.mesh.position.copy(h.pos);
      const hit = h.pos.distanceTo(player.pos) < L * 0.55 + 0.6;
      if (hit) {
        if (player.damage(35, 'Лазерный гарпун')) { game.onPlayerHurt(35); game.fx.hit(player.pos, L); }
        game.audio.play('harpoonHit');
        this.scene.remove(h.mesh);
        this.harpoons.splice(i, 1);
        continue;
      }
      if (h.t > h.life) { this.scene.remove(h.mesh); this.harpoons.splice(i, 1); }
    }
  }

  updateCages(dt, player, game, L, menu) {
    for (const c of this.cages) {
      if (!c.active) continue;
      const cruiser = c.cruiser;
      const bottom = terrainDepth(cruiser.x, cruiser.z, game.world.L);
      const hang = 48 * depthScale(game.world.L);
      const y = Math.max(-bottom + 2, Math.min(-hang, -6));
      c.group.position.set(cruiser.x, y, cruiser.z);
      const dir = player.pos.clone().sub(c.group.position);
      c.yaw = Math.atan2(dir.x, dir.z);
      c.diver.rotation.y = c.yaw;
      c.group.rotation.z = Math.sin(game.time * 0.6) * 0.05;
      if (c.grace > 0) c.grace -= dt;
      // поедание водолаза
      if (c.size <= L && c.group.position.distanceTo(player.pos) < c.size * 0.4 + L * 0.6 && c.grace <= 0 && !menu) {
        c.active = false;
        this.scene.remove(c.group);
        player.addGrowth(SURFACE_TARGETS.diver.growth * (1 + 0.10 * player.upg.size));
        player.heal(5 + 1.8 * c.size);
        const ups = player.addXp(SURFACE_TARGETS.diver.xp);
        player.eaten++;
        game.fx.eat(c.group.position, c.size, 0x9fe8ff);
        game.audio.play('eatBig');
        game.onEat({ name: 'Водолаз в клетке', xp: SURFACE_TARGETS.diver.xp, size: c.size, big: true });
        if (ups > 0) game.onLevelUp(ups);
        this.cages = this.cages.filter(x => x !== c);
      }
    }
  }

  updateChests(dt, player, game, L, menu) {
    this.chestTimer += dt;
    for (const c of this.chests) {
      c.group.rotation.y += dt * 0.35;
      const pulse = 0.9 + Math.sin(game.time * 2.2) * 0.18;
      c.glow.scale.setScalar(1.6 * Math.max(1, L * 0.5) * pulse);
      c.glow.material.opacity = 0.22 + 0.12 * Math.sin(game.time * 2.2);
      const d = Math.hypot(c.x - player.pos.x, c.z - player.pos.z);
      if (!c.opened && !menu && d < Math.max(3, L * 0.9) && Math.abs(c.y - player.pos.y) < Math.max(6, L * 2)) {
        this.openChest(c, player, game);
      }
      // замена далёких сундуков
      if (!c.opened && d > Math.max(900, 18 * L) && game.time - c.spawnTime > 45) {
        c.opened = true;
        this.scene.remove(c.group);
      }
    }
    this.chests = this.chests.filter(c => !c.opened || c.timer > 0);
    for (const c of this.chests) {
      if (c.opened) {
        c.timer -= dt;
        if (c.timer <= 0) { this.scene.remove(c.group); c.dead = true; }
      }
    }
    this.chests = this.chests.filter(c => !c.dead);
    while (this.chests.length < 3) this.spawnChest();
  }

  openChest(c, player, game) {
    c.opened = true;
    c.timer = 0.01;
    const roll = this.rnd();
    let name = '', desc = '';
    if (roll < 0.40) {
      const xp = Math.round(levelCost(player.level) * 0.5);
      const ups = player.addXp(xp);
      name = 'Затонувшие знания';
      desc = `+${xp} опыта`;
      game.audio.play('buffXp');
      if (ups > 0) game.onLevelUp(ups);
    } else if (roll < 0.70) {
      player.heal(9999);
      name = 'Жемчужина жизни';
      desc = 'Здоровье восстановлено';
      game.audio.play('buffHeal');
    } else if (roll < 0.88) {
      player.tempSpeed = Math.min(50, player.tempSpeed + 25);
      name = 'Попутное течение';
      desc = 'Скорость ×1,7 на 25 с';
      game.audio.play('buffSpeed');
    } else {
      player.tempSize = Math.min(40, player.tempSize + 20);
      name = 'Левиафан';
      desc = 'Размер ×1,6 на 20 с';
      game.audio.play('buffSize');
    }
    game.fx.chest(c.group.position);
    game.audio.play('chest');
    game.showMessage(name, desc, 'chest');
  }

  cleanupWarnings() {
    for (const w of this.warningZones) {
      if (w.userData.keep === undefined) continue;
      if (this.game.time - w.userData.keep > 0.15) { w.visible = false; w.userData.keep = undefined; }
    }
  }

  // ближайшие сущности для сонара/меток
  allForSonar() {
    const out = [];
    for (const t of this.targets) out.push({ x: t.x, z: t.z, y: 0, size: t.size, kind: t.kind, name: SURFACE_TARGETS[t.kind].name });
    for (const c of this.cages) if (c.active) out.push({ x: c.group.position.x, z: c.group.position.z, y: c.group.position.y, size: c.size, kind: 'diver', name: 'Водолаз в клетке' });
    for (const c of this.chests) if (!c.opened) out.push({ x: c.x, z: c.z, y: c.y, size: 2, kind: 'chest', name: 'СОКРОВИЩЕ' });
    return out;
  }
}

function configScale(kind, size) {
  switch (kind) {
    case 'swimmer': return { x: size, y: size, z: size };
    case 'boat': return { x: size * 0.38, y: size * 0.95, z: size };
    case 'yacht': return { x: size * 0.3, y: size * 0.95, z: size };
    case 'cargo': return { x: size * 0.26, y: size * 0.8, z: size };
    case 'cruiser': return { x: size * 0.2, y: size * 0.8, z: size };
    default: return { x: size, y: size, z: size };
  }
}
