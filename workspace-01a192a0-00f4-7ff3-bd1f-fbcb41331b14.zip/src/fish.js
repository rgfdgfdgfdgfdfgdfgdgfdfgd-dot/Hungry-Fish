// Рыбы: население, стаи, поведение, охота, поедание.
import * as THREE from 'three';
import { SPECIES, SPECIES_LIST, fishXp, growthShare, healFor, biteDamage, TEMPER_TEXT } from './config.js';
import { buildFishGeometry } from './models.js';
import { terrainDepth, clamp, visibility } from './world.js';
import { mulberry32 } from './noise.js';

const CAP = 90;

export class FishManager {
  constructor(scene, game) {
    this.scene = scene;
    this.game = game;
    this.geos = {};
    this.meshes = {};
    this.uniforms = { uTime: { value: 0 } };
    this.mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.42, metalness: 0.18, side: THREE.DoubleSide });
    this.mat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.uniforms.uTime;
      sh.vertexShader = 'uniform float uTime;\nattribute float aPhase;\nattribute float aAmp;\nattribute float aSpine;\n' + sh.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        float sp = clamp(aSpine, 0.0, 1.0);
        float wave = sin(sp * 5.2 - uTime * 5.4 + aPhase);
        transformed.x += wave * aAmp * pow(sp, 1.6);
        transformed.y += cos(sp * 4.0 - uTime * 5.4 + aPhase) * aAmp * 0.18 * pow(sp, 2.0);
        `);
    };
    for (const sp of SPECIES_LIST) {
      const geo = buildFishGeometry(sp.id, 'fish');
      const phases = new Float32Array(CAP), amps = new Float32Array(CAP);
      geo.setAttribute('aPhase', new THREE.InstancedBufferAttribute(phases, 1));
      geo.setAttribute('aAmp', new THREE.InstancedBufferAttribute(amps, 1));
      const mesh = new THREE.InstancedMesh(geo, this.mat, CAP);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.count = 0;
      mesh.frustumCulled = false;
      mesh.userData.species = sp.id;
      scene.add(mesh);
      this.geos[sp.id] = geo;
      this.meshes[sp.id] = mesh;
    }
    this.fish = [];
    this.schools = [];
    this.pending = [];
    this.rnd = mulberry32(20260924);
  }

  get temperLabel() { return TEMPER_TEXT; }

  reset() {
    for (const f of this.fish) this.hide(f);
    this.fish.length = 0;
    this.schools.length = 0;
    this.pending.length = 0;
    this.rnd = mulberry32(20260924);
    // стартовые рыбы
    const p = this.game.player;
    const f1 = this.makeFish('clown', 0.48, p.pos.x, p.pos.y, p.pos.z - 8, 0);
    const f2 = this.makeFish('clown', 0.48, p.pos.x, p.pos.y + 0.2, p.pos.z - 12, 0);
    f1.tutorial = f2.tutorial = true;
    f1.dir.set(0, 0, -1); f2.dir.set(0, 0, -1);
    // стаи
    let created = 2;
    for (let s = 0; s < 7; s++) {
      const school = this.makeSchool(6);
      created += 6;
    }
    let guard = 0;
    while (created < 114 && guard++ < 400) {
      const before = this.fish.length;
      this.spawnRandom(true);
      created += this.fish.length - before;
    }
    while (this.fish.length > 114) { const f = this.fish.pop(); if (f.school) f.school.members = f.school.members.filter(m => m !== f); f.alive = false; }
  }

  makeSchool(n) {
    const L = this.game.player.curSize;
    const rnd = this.rnd;
    const speciesIds = ['sardine', 'clown', 'butterfly', 'tang', 'mackerel'];
    const sid = speciesIds[Math.floor(rnd() * speciesIds.length)];
    const sp = SPECIES[sid];
    const ang = rnd() * Math.PI * 2;
    const dist = (16 + rnd() * 26) * Math.max(1, L / 1.6);
    const cx = this.game.player.pos.x + Math.cos(ang) * dist;
    const cz = this.game.player.pos.z + Math.sin(ang) * dist;
    const depth = this.freeDepth(cx, cz, 3, 10 + rnd() * 20 * Math.max(1, L / 2));
    const school = {
      species: sid, center: new THREE.Vector3(cx, -depth, cz), yaw: rnd() * Math.PI * 2,
      depth: -depth, speed: 0.35 + rnd() * 0.3, timer: 3 + rnd() * 5, members: [],
    };
    this.schools.push(school);
    for (let i = 0; i < n; i++) {
      const f = this.makeFish(sid, sp.size * (0.9 + rnd() * 0.22), school.center.x + (rnd() - 0.5) * 8, school.center.y + (rnd() - 0.5) * 3, school.center.z + (rnd() - 0.5) * 8, 0);
      f.school = school;
      school.members.push(f);
    }
    return school;
  }

  freeDepth(x, z, minAbove, maxBelow) {
    const bottom = terrainDepth(x, z, this.game.world.L);
    const lo = Math.min(minAbove + 1, bottom - 1);
    const d = lo + this.rnd() * Math.max(0.5, Math.min(maxBelow, bottom - 2) - lo);
    return clamp(d, 1.5, Math.max(2, bottom - 1.2));
  }

  makeFish(speciesId, size, x, y, z, extra = 0) {
    const sp = SPECIES[speciesId];
    const f = {
      species: speciesId, size, pos: new THREE.Vector3(x, y, z),
      dir: new THREE.Vector3(0, 0, -1), speed: 1 + this.rnd() * 1.2,
      yaw: this.rnd() * Math.PI * 2, pitch: 0,
      phase: this.rnd() * 10, amp: 0.07, state: 'swim', stateT: 0,
      school: null, alive: true, giant: extra > 0, target: new THREE.Vector3(),
      bob: this.rnd() * 6.28, cooldown: 0, huntT: 0, biteDone: false, tag: null, spawnGrace: 0,
    };
    f.dir.set(0, 0, -1).applyEuler(new THREE.Euler(0, f.yaw, 0));
    this.fish.push(f);
    return f;
  }

  hide(f) {
    f.alive = false;
  }

  spawnRandom(initial = false) {
    const p = this.game.player;
    const L = p.curSize;
    const threats = this.fish.filter(f => f.alive && f.size > L * 1.05).length;
    const wantThreats = L < 1.8 ? 7 : L < 6 ? 9 : 11;
    const makeThreat = threats < wantThreats && this.rnd() < (initial ? 0.35 : 0.42);
    let sid, size;
    if (makeThreat) {
      const preds = ['barracuda', 'hammerhead', 'greatwhite', 'mackerel', 'tuna'];
      sid = preds[Math.floor(this.rnd() * preds.length)];
      const base = SPECIES[sid].size;
      size = Math.max(base * (0.95 + this.rnd() * 0.25), L * (1.25 + this.rnd() * 0.6));
    } else {
      const preyCandidates = SPECIES_LIST.filter(s => s.size * 1.12 <= L * 1.0);
      if (preyCandidates.length) {
        const sorted = preyCandidates.slice().sort((a, b) => b.size - a.size);
        const pick = sorted[Math.floor(Math.pow(this.rnd(), 1.6) * sorted.length)];
        sid = pick.id;
        size = Math.min(pick.size * (0.88 + this.rnd() * 0.24), Math.max(0.2, L));
      } else {
        sid = 'sardine';
        size = Math.min(0.32 * (0.88 + this.rnd() * 0.24), Math.max(0.2, L));
      }
    }
    const minDist = Math.max(makeThreat ? 60 : 24, size * 6, L * 4);
    let x = 0, z = 0, d = 0, ok = false;
    for (let i = 0; i < 24; i++) {
      const ang = this.rnd() * Math.PI * 2;
      const dist = minDist + this.rnd() * 80;
      x = p.pos.x + Math.cos(ang) * dist;
      z = p.pos.z + Math.sin(ang) * dist;
      if (Math.hypot(x, z) > 2600) continue;
      d = this.freeDepth(x, z, 3, 12 + this.rnd() * 25);
      if (Math.abs(-d - p.pos.y) > 2 * Math.max(1, size) || i > 10) { ok = true; break; }
    }
    if (!ok) { d = this.freeDepth(x, z, 3, 20); }
    const f = this.makeFish(sid, size, x, -d, z, makeThreat ? 1 : 0);
    f.spawnGrace = 2.5;
    if (this.rnd() < 0.35 && !makeThreat) {
      // маленькая стайка на замену
      for (let k = 0; k < 2 + Math.floor(this.rnd() * 4); k++) {
        const g = this.makeFish(sid, size * (0.9 + this.rnd() * 0.2), x + (this.rnd() - 0.5) * 6, -d + (this.rnd() - 0.5) * 2, z + (this.rnd() - 0.5) * 6, 0);
        g.spawnGrace = 2.5;
      }
    }
    return f;
  }

  replaceDead() {
    const L = this.game.player.curSize;
    const p = this.game.player.pos;
    let alive = 0;
    for (let i = this.fish.length - 1; i >= 0; i--) {
      const f = this.fish[i];
      const far = Math.hypot(f.pos.x - p.x, f.pos.z - p.z) > Math.max(220, 20 * L) || Math.abs(f.pos.y - p.y) > Math.max(160, 14 * L);
      if (!f.alive || far) {
        if (f.school) f.school.members = f.school.members.filter(m => m !== f);
        this.fish.splice(i, 1);
      } else alive++;
    }
    for (const s of this.schools) {
      if (!s.members.length) this.schools.splice(this.schools.indexOf(s), 1);
    }
    let guard = 0;
    while (alive < 114 && guard++ < 300) {
      const before = this.fish.length;
      if (this.schools.length < 7 && this.rnd() < 0.2 && alive + 6 <= 114) { this.makeSchool(6); alive += 6; }
      else { this.spawnRandom(); alive += this.fish.length - before; }
    }
    while (this.fish.length > 114) {
      const f = this.fish.pop();
      if (f.school) f.school.members = f.school.members.filter(m => m !== f);
      f.alive = false;
    }
  }

  // ---------------- поведение ----------------
  update(dt, player, game) {
    this.uniforms.uTime.value += dt;
    const L = player.curSize;
    const playerSpeed = player.speed;
    let hunters = 0;
    for (const f of this.fish) if (f.alive && (f.state === 'chase' || f.state === 'windup' || f.state === 'lunge')) hunters++;
    const maxHunters = L < 3 ? 2 : 3;
    for (const s of this.schools) {
      s.timer -= dt;
      if (s.timer <= 0) {
        s.timer = 5 + this.rnd() * 5;
        s.yaw += (this.rnd() - 0.5) * 1.4;
        s.depth = -this.freeDepth(s.center.x, s.center.z, 4, 18);
      }
      s.center.x += Math.sin(s.yaw) * -s.speed * dt * 4;
      s.center.z += Math.cos(s.yaw) * -s.speed * dt * 4;
      s.center.y += (s.depth - s.center.y) * Math.min(1, dt * 0.4);
    }

    for (const f of this.fish) {
      if (!f.alive) continue;
      if (f.spawnGrace > 0) f.spawnGrace -= dt;
      const toPlayer = new THREE.Vector3().subVectors(player.pos, f.pos);
      const distP = toPlayer.length() || 0.001;
      const canHunt = f.size > L * 1.05;
      const isPredator = SPECIES[f.species].predator;

      if (f.cooldown > 0) f.cooldown -= dt;

      // --- хищники ---
      if (canHunt && !(f.spawnGrace > 0) && f.cooldown <= 0 && game.allowHunt && hunters < maxHunters) {
        if (f.state === 'swim') {
          const detect = isPredator
            ? Math.max(28, 0.65 * (L + f.size) + 12)
            : Math.max(20, 0.60 * (L + f.size) + 10);
          if (distP < detect && Math.random() < dt * 0.9) {
            f.state = 'alert'; f.stateT = 0.85; hunters++;
            game.onThreatNotice?.(f);
          }
        }
      }
      if (f.state === 'alert') {
        f.stateT -= dt;
        this.faceTowards(f, toPlayer, dt, 1.2);
        if (f.stateT <= 0) { f.state = 'chase'; f.huntT = 0; }
      } else if (f.state === 'chase') {
        f.huntT += dt;
        const limit = isPredator ? 8 : 6;
        const huntSpeed = playerSpeed * (isPredator ? 1.3 : 1.15);
        this.faceTowards(f, toPlayer, dt, 2.4);
        this.moveAlong(f, huntSpeed, dt);
        const detect = isPredator ? Math.max(28, 0.65 * (L + f.size) + 12) : Math.max(20, 0.60 * (L + f.size) + 10);
        if (distP > detect + 12 || f.huntT > limit || f.size <= L * 1.02) {
          f.state = 'retreat'; f.stateT = 8;
        } else if (distP < f.size * 2.2 + L * 1.2) {
          f.state = 'windup'; f.stateT = 0.75;
        }
      } else if (f.state === 'windup') {
        f.stateT -= dt;
        this.faceTowards(f, toPlayer, dt, 3.5);
        if (f.stateT <= 0) {
          f.state = 'lunge'; f.stateT = 0.48; f.biteDone = false;
          f.lungeDir = toPlayer.clone().normalize();
          f.dir.copy(f.lungeDir);
        }
      } else if (f.state === 'lunge') {
        f.stateT -= dt;
        const lungeSpeed = playerSpeed * 3.0;
        f.pos.addScaledVector(f.lungeDir, lungeSpeed * dt);
        if (!f.biteDone && distP < (L * 0.6 + f.size * 0.5) && Math.abs(player.pos.y - f.pos.y) < L * 0.5 + f.size * 0.4) {
          f.biteDone = true;
          const dmg = biteDamage(f.size, L);
          if (player.damage(dmg, `${SPECIES[f.species].name}${f.giant ? '-гигант' : ''}`)) {
            game.fx.hit(player.pos, f.size);
            game.audio.play('bitePlayer');
            game.onPlayerHurt(dmg);
          }
        }
        if (f.stateT <= 0) { f.state = 'recover'; f.stateT = 1.65; }
      } else if (f.state === 'recover') {
        f.stateT -= dt;
        this.moveAlong(f, playerSpeed * 0.4, dt);
        if (f.stateT <= 0) { f.state = 'retreat'; f.stateT = 8; }
      } else if (f.state === 'retreat') {
        f.stateT -= dt;
        this.awayFrom(f, toPlayer, dt);
        this.moveAlong(f, f.size * 0.6 + 1, dt);
        if (f.stateT <= 0) { f.state = 'swim'; f.cooldown = 2 + this.rnd() * 2; }
      } else {
        // --- мирное плавание / стая / уклонение ---
        const danger = player.curSize > f.size * 0.92;
        const fleeR = Math.max(2.5, f.size * 3 + player.curSize * 2.5);
        const nimble = SPECIES[f.species].temper;
        if (danger && distP < fleeR * (player.boosting ? 0.6 : 1) && f.state !== 'flee') {
          if (nimble !== 'calm' || Math.random() < 0.35) {
            f.state = 'flee'; f.stateT = 1.2; f.fleeDir = new THREE.Vector3(-toPlayer.x, -toPlayer.y * 0.15, -toPlayer.z).normalize();
          }
        }
        if (f.state === 'flee') {
          f.stateT -= dt;
          f.pos.addScaledVector(f.fleeDir, playerSpeed * 0.75 * dt);
          f.dir.lerp(f.fleeDir, Math.min(1, dt * 6)).normalize();
          if (f.stateT <= 0 && distP > fleeR) f.state = 'swim';
          if (f.stateT < -0.6) f.state = 'swim';
        } else {
          if (f.school) {
            const c = f.school.center;
            const target = new THREE.Vector3(c.x - f.pos.x, c.y - f.pos.y, c.z - f.pos.z);
            if (target.lengthSq() > 1) {
              const desired = target.normalize();
              // расступаются перед игроком
              if (distP < 6 * Math.max(1, f.size) && player.curSize > f.size) {
                desired.add(new THREE.Vector3(-toPlayer.x, 0, -toPlayer.z).normalize().multiplyScalar(1.5)).normalize();
              }
              f.dir.lerp(desired, Math.min(1, dt * 1.4)).normalize();
            }
            f.speed = f.school.speed;
          } else {
            f.bob += dt;
            const wander = new THREE.Vector3(Math.sin(f.bob * 0.4 + f.phase), Math.sin(f.bob * 0.23 + f.phase * 2) * 0.15, Math.cos(f.bob * 0.33 + f.phase)).normalize();
            // крупные рыбы патрулируют рядом с игроком, чтобы встречи случались
            if (f.size > L * 1.05 && distP > 26) {
              const toward = new THREE.Vector3(toPlayer.x, toPlayer.y * 0.4, toPlayer.z).normalize();
              wander.lerp(toward, 0.75).normalize();
            }
            f.dir.lerp(wander, Math.min(1, dt * 0.7)).normalize();
            f.speed = 0.8 + f.phase % 1;
          }
          if (f.tutorial) { f.dir.multiplyScalar(0.9); f.speed = 0.35; }
          this.moveAlong(f, f.speed * (1 + f.size * 0.15), dt);
        }
      }
      // границы глубины
      const bottom = terrainDepth(f.pos.x, f.pos.z, this.game.world.L);
      const minY = -bottom + Math.max(0.8, f.size * 0.8);
      const maxY = -Math.max(0.8, f.size * 0.5);
      if (f.pos.y < minY) { f.pos.y = minY; f.dir.y = Math.abs(f.dir.y) * 0.5; }
      if (f.pos.y > maxY) { f.pos.y = maxY; f.dir.y = -Math.abs(f.dir.y) * 0.5; }
      if (!Number.isFinite(f.pos.x)) { f.pos.set(0, -10, 0); }

      f.amp = f.state === 'lunge' ? 0.13 : (f.state === 'flee' ? 0.11 : 0.07);
    }

    this.syncInstances();
  }

  syncInstances() {
    const bySpecies = {};
    for (const sp of SPECIES_LIST) bySpecies[sp.id] = [];
    const p = this.game.player.pos;
    const cullR = 1.25 * visibility(this.game.player.curSize);
    for (const f of this.fish) {
      if (!f.alive) continue;
      if (f.pos.distanceTo(p) > cullR + f.size) continue; // за туманом не рисуем
      bySpecies[f.species].push(f);
    }
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), e = new THREE.Euler();
    for (const sp of SPECIES_LIST) {
      const mesh = this.meshes[sp.id];
      const list = bySpecies[sp.id];
      const n = Math.min(list.length, CAP);
      mesh.count = n;
      const phaseAttr = mesh.geometry.getAttribute('aPhase');
      const ampAttr = mesh.geometry.getAttribute('aAmp');
      for (let i = 0; i < n; i++) {
        const f = list[i];
        const yaw = Math.atan2(-f.dir.x, -f.dir.z);
        const pitch = Math.asin(clamp(f.dir.y, -1, 1));
        e.set(pitch * 0.9, yaw, 0, 'YXZ');
        q.setFromEuler(e);
        s.setScalar(f.size);
        m.compose(f.pos, q, s);
        mesh.setMatrixAt(i, m);
        phaseAttr.array[i] = f.phase;
        ampAttr.array[i] = f.amp;
      }
      mesh.instanceMatrix.needsUpdate = true;
      phaseAttr.needsUpdate = true;
      ampAttr.needsUpdate = true;
    }
  }

  edibleBy(player) { return this.fish.filter(f => f.alive && f.size <= player.curSize); }

  // цель для метки/помощи прицеливания
  bestTarget(player, maxDist = 40) {
    const fwd = player.forward;
    let best = null, bestScore = -1e9;
    for (const f of this.fish) {
      if (!f.alive) continue;
      const d = f.pos.clone().sub(player.pos);
      const dist = d.length();
      if (dist > maxDist + f.size * 4) continue;
      const dot = d.normalize().dot(fwd);
      if (dot < 0.55) continue;
      const edible = f.size <= player.curSize;
      const score = dot * 10 - dist * 0.1 + (edible ? 4 : 0) + f.size * 0.5;
      if (score > bestScore) { bestScore = score; best = f; }
    }
    return best;
  }
}

// вспомогательные методы экземпляра (в прототип)
FishManager.prototype.faceTowards = function (f, vec, dt, rate) {
  const desired = new THREE.Vector3(vec.x, vec.y * 0.6, vec.z);
  if (desired.lengthSq() < 1e-6) return;
  desired.normalize();
  f.dir.lerp(desired, Math.min(1, dt * rate)).normalize();
};
FishManager.prototype.awayFrom = function (f, vec, dt) {
  const desired = new THREE.Vector3(-vec.x, -vec.y * 0.2, -vec.z).normalize();
  f.dir.lerp(desired, Math.min(1, dt * 1.6)).normalize();
};
FishManager.prototype.moveAlong = function (f, speed, dt) {
  f.pos.addScaledVector(f.dir, speed * dt);
};
