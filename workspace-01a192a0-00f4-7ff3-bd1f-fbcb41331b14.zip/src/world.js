// Мир: биомы, процедурный рельеф, вода, свет, декор, взвесь, медузы.
import * as THREE from 'three';
import { fbm2, ridge2, smoothstep, clamp, lerp, noise2, mulberry32, hash2i } from './noise.js';
export { clamp, lerp };
import { DECOR_TYPES, buildDecorPrototype } from './models.js';

export const IS_MOBILE = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
export const QUALITY = IS_MOBILE ? 0.62 : 1;

export function visibility(L) { return Math.min(4000, 55 + 22 * L); }
export function camDist(L) { return 2.4 * L + 1.4; }
export function depthScale(L) { return Math.max(1, (2.4 * L + 14) / 27); }
export function placeRadius(L, r0) { return Math.max(r0, 30 * L); }

// ---------- биомы ----------
export const BIOME_COLORS = {
  reef:   { shallow: '#3cb7c4', deep: '#12566f', sand: '#d9c49a' },
  fields: { shallow: '#47bcb8', deep: '#145a70', sand: '#e4d3a6' },
  slope:  { shallow: '#2b97bb', deep: '#12475f', sand: '#b8b09a' },
  ocean:  { shallow: '#2379b2', deep: '#123f63', sand: '#a8a494' },
};

export function biomeWeights(x, z) {
  const r = Math.hypot(x, z);
  const warp = (fbm2(x * 0.0018 + 11.3, z * 0.0018 - 7.1, 2, 21) - 0.5) * 190;
  const rw = r + warp;
  const wR = 1 - smoothstep(300, 465, rw);
  const wF = smoothstep(300, 465, rw) * (1 - smoothstep(1050, 1240, rw));
  const wS = smoothstep(1050, 1240, rw) * (1 - smoothstep(1790, 2030, rw));
  const wO = smoothstep(1790, 2030, rw);
  const s = wR + wF + wS + wO || 1;
  return { reef: wR / s, fields: wF / s, slope: wS / s, ocean: wO / s, r };
}

function reefDepth(x, z, damp = 1) {
  const hills = (fbm2(x / 95, z / 95, 3, 3) - 0.5) * 2 * 7.2;
  const ridge = (ridge2(x / 47, z / 47, 5) - 0.5) * 2 * 4.2;
  const mid = (fbm2(x / 62, z / 62, 2, 17) - 0.5) * 2 * 5.8;
  const plateau = (fbm2(x / 230, z / 230, 2, 9) - 0.5) * 2 * 1.8;
  const detail = (fbm2(x / 19, z / 19, 2, 13) - 0.5) * 2 * 1.2;
  return 22 + (hills + ridge + mid + plateau + detail) * damp;
}
function fieldsDepth(x, z) {
  const dune = (fbm2(x / 40, z / 40, 2, 31) - 0.5) * 2 * 2.2;
  const ripple = (fbm2(x / 9, z / 9, 2, 33) - 0.5) * 2 * 1.4;
  const crest = (ridge2(x / 180, z / 180, 35) - 0.5) * 2 * 9;
  return 44 + dune + ripple + crest;
}
function slopeDepth(x, z, r) {
  const fall = smoothstep(1150, 1900, r) * 120;
  const ridges = (fbm2(x / 400, z / 400, 3, 41) - 0.5) * 2 * 16;
  const bumps = (fbm2(x / 120, z / 120, 2, 43) - 0.5) * 2 * 9;
  return 60 + fall + ridges + bumps;
}
function oceanDepth(x, z) {
  const mounts = (fbm2(x / 400, z / 400, 3, 51) - 0.5) * 2 * 26;
  const hills = (fbm2(x / 140, z / 140, 2, 53) - 0.5) * 2 * 10;
  return 210 + mounts + hills;
}

export function terrainDepth(x, z, L = 0.78) {
  const w = biomeWeights(x, z);
  const r0 = Math.hypot(x, z);
  const damp = 0.3 + 0.7 * smoothstep(5, 26, r0);
  const d = w.reef * reefDepth(x, z, damp) + w.fields * fieldsDepth(x, z) +
            w.slope * slopeDepth(x, z, w.r) + w.ocean * oceanDepth(x, z);
  const fine = 1 / (1 + Math.max(0, L - 2) * 0.12);
  const base = d * depthScale(L);
  const rough = (fbm2(x / 6, z / 6, 2, 61) - 0.5) * 1.2 * fine;
  return Math.max(2.2, base + rough);
}

export function terrainNormal(x, z, L, out = new THREE.Vector3()) {
  const e = 0.6 + L * 0.05;
  const d0 = terrainDepth(x, z, L);
  const dx = terrainDepth(x + e, z, L) - d0;
  const dz = terrainDepth(x, z + e, L) - d0;
  return out.set(dx / e, 1, dz / e).normalize();
}

export function biomeAt(x, z) {
  const w = biomeWeights(x, z);
  let best = 'reef', v = -1;
  for (const k of ['reef', 'fields', 'slope', 'ocean']) if (w[k] > v) { v = w[k]; best = k; }
  return best;
}

// цвет воды в точке (для тумана/фона)
const _c1 = new THREE.Color(), _c2 = new THREE.Color(), _out = new THREE.Color();
const _scatter = new THREE.Color('#35809f');
export function waterColorAt(x, z, depth, target = new THREE.Color()) {
  const w = biomeWeights(x, z);
  const t = clamp(depth / 78, 0, 1);
  target.setRGB(0, 0, 0);
  for (const k of ['reef', 'fields', 'slope', 'ocean']) {
    if (w[k] <= 0.0001) continue;
    _c1.set(BIOME_COLORS[k].shallow);
    _c2.set(BIOME_COLORS[k].deep);
    _out.copy(_c1).lerp(_c2, t);
    target.r += _out.r * w[k]; target.g += _out.g * w[k]; target.b += _out.b * w[k];
  }
  // рассеяние света в толще воды держит кадр читаемым на большой глубине
  const sc = Math.min(0.68, Math.max(0, (depth - 20) / 190));
  target.lerp(_scatter, sc);
  return target;
}

// волны (та же формула, что в шейдере поверхности)
export function waveHeight(x, z, t) {
  return 0.30 * Math.sin(x * 0.72 + t * 1.1) * Math.cos(z * 0.61 - t * 0.9)
       + 0.18 * Math.sin(x * 1.31 - t * 1.7 + z * 0.83)
       + 0.10 * Math.sin(z * 2.1 + t * 2.3)
       + 0.06 * Math.sin((x + z) * 0.9 - t * 1.5);
}

const GLSL_NOISE = `
float hf(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453123); }
float vn(vec2 p){
  vec2 i = floor(p), f = fract(p);
  vec2 u = f*f*(3.0-2.0*f);
  return mix(mix(hf(i), hf(i+vec2(1.0,0.0)), u.x), mix(hf(i+vec2(0.0,1.0)), hf(i+vec2(1.0,1.0)), u.x), u.y);
}
float fbm(vec2 p){
  float s = 0.0, a = 0.5;
  for(int i=0;i<4;i++){ s += a*vn(p); p *= 2.03; a *= 0.5; }
  return s;
}
`;

// ---------- рельеф ----------
class Terrain {
  constructor(scene) {
    this.res = IS_MOBILE ? 92 : 100;
    const n = this.res * this.res;
    const g = new THREE.BufferGeometry();
    this.pos = new Float32Array(n * 3);
    this.colArr = new Float32Array(n * 3);
    this.nrm = new Float32Array(n * 3);
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.colArr, 3));
    g.setAttribute('normal', new THREE.BufferAttribute(this.nrm, 3));
    const idx = new Uint32Array((this.res - 1) * (this.res - 1) * 6);
    let o = 0;
    for (let j = 0; j < this.res - 1; j++) {
      for (let i = 0; i < this.res - 1; i++) {
        const a = j * this.res + i, b = a + 1, c = a + this.res, d = c + 1;
        idx[o++] = a; idx[o++] = c; idx[o++] = b;
        idx[o++] = b; idx[o++] = c; idx[o++] = d;
      }
    }
    g.setIndex(new THREE.BufferAttribute(idx, 1));
    this.geo = g;
    const uniforms = { uTime: { value: 0 }, uDetail: { value: 2.0 } };
    this.uniforms = uniforms;
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.96, metalness: 0.0 });
    mat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = uniforms.uTime;
      sh.uniforms.uDetail = uniforms.uDetail;
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWPos = (modelMatrix * vec4(transformed,1.0)).xyz;');
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', `#include <common>
          varying vec3 vWPos; uniform float uTime; uniform float uDetail;
          ${GLSL_NOISE}`)
        .replace('#include <color_fragment>', `#include <color_fragment>
          float d1 = vn(vWPos.xz * uDetail);
          float d2 = vn(vWPos.xz * uDetail * 0.22 + 13.7);
          float d3 = vn(vWPos.xz * 0.014 + 3.1);
          float rip = vn(vec2(vWPos.x*0.35, vWPos.z*1.4) * uDetail * 0.5 + uTime*0.02);
          float ca = pow(0.5 + 0.5*sin(vWPos.x*0.5 + uTime*0.55 + 3.0*vn(vWPos.xz*0.11 + uTime*0.04)), 2.0);
          diffuseColor.rgb *= vec3(
            0.86 + 0.20*d1 + 0.06*rip + 0.05*ca,
            0.88 + 0.18*d2 + 0.06*rip + 0.05*ca,
            0.90 + 0.14*d1 + 0.05*ca
          ) * (0.94 + 0.11*d3);
        `);
    };
    this.mesh = new THREE.Mesh(g, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 0;
    scene.add(this.mesh);
    this.center = new THREE.Vector3(1e9, 0, 1e9);
    this.step = 1;
    this.L = -1;
  }
  update(px, pz, L, force = false) {
    const extent = 1.35 * visibility(L);
    const step = (extent * 2) / (this.res - 1);
    const snap = step;
    const cx = Math.round(px / snap) * snap;
    const cz = Math.round(pz / snap) * snap;
    const moved = Math.hypot(cx - this.center.x, cz - this.center.z);
    if (!force && moved < step * 6 && Math.abs(L - this.L) < this.L * 0.25 && this.L > 0) {
      this.center.x = cx; this.center.z = cz;
      return;
    }
    this.center.set(cx, 0, cz);
    this.step = step;
    this.L = L;
    this.extent = extent;
    const res = this.res;
    const pos = this.pos, colA = this.colArr, nrm = this.nrm;
    const sandR = new THREE.Color(), sandG = new THREE.Color(), rock = new THREE.Color('#7e776c');
    const biomeSand = {
      reef: new THREE.Color(BIOME_COLORS.reef.sand),
      fields: new THREE.Color(BIOME_COLORS.fields.sand),
      slope: new THREE.Color(BIOME_COLORS.slope.sand),
      ocean: new THREE.Color(BIOME_COLORS.ocean.sand),
    };
    const n = new THREE.Vector3();
    const half = ((res - 1) / 2) * step;
    for (let j = 0; j < res; j++) {
      const z = cz - half + j * step;
      for (let i = 0; i < res; i++) {
        const x = cx - half + i * step;
        const d = terrainDepth(x, z, L);
        const k = (j * res + i) * 3;
        pos[k] = x - cx; pos[k + 1] = -d; pos[k + 2] = z - cz;
        // нормаль
        const e = step * 0.7;
        const dx = terrainDepth(x + e, z, L) - d;
        const dz = terrainDepth(x, z + e, L) - d;
        n.set(dx / e, 1, dz / e).normalize();
        nrm[k] = n.x; nrm[k + 1] = n.y; nrm[k + 2] = n.z;
        // цвет
        const w = biomeWeights(x, z);
        sandR.setRGB(0, 0, 0);
        for (const b of ['reef', 'fields', 'slope', 'ocean']) {
          if (w[b] > 0.001) { sandG.copy(biomeSand[b]); sandR.r += sandG.r * w[b]; sandR.g += sandG.g * w[b]; sandR.b += sandG.b * w[b]; }
        }
        const slope = Math.hypot(n.x, n.z) / Math.max(0.001, n.y);
        const rockT = smoothstep(0.62, 1.05, slope);
        const tint = 0.92 + 0.16 * noise2(x * 0.06, z * 0.06, 5);
        colA[k] = lerp(sandR.r, rock.r, rockT) * tint * 0.9;
        colA[k + 1] = lerp(sandR.g, rock.g, rockT) * tint * 0.9;
        colA[k + 2] = lerp(sandR.b, rock.b, rockT) * tint * 0.9;
      }
    }
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.normal.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = true;
    this.geo.computeBoundingSphere();
    this.mesh.position.set(cx, 0, cz);
    this.uniforms.uDetail.value = 2.0 / Math.max(1, Math.round(L / 12)) / (L > 6 ? 1.6 : 1);
  }
}

// ---------- поверхность воды ----------
class WaterSurface {
  constructor(scene, renderer) {
    const rings = IS_MOBILE ? 30 : 44, seg = IS_MOBILE ? 48 : 72;
    const verts = [], idx = [];
    const rMin = 1.5, rMax = 7000;
    verts.push(0, 0, 0);
    for (let i = 1; i <= rings; i++) {
      const r = rMin * Math.pow(rMax / rMin, i / rings);
      for (let j = 0; j < seg; j++) {
        const a = (j / seg) * Math.PI * 2;
        verts.push(Math.cos(a) * r, 0, Math.sin(a) * r);
      }
    }
    for (let j = 0; j < seg; j++) idx.push(0, 1 + j, 1 + (j + 1) % seg);
    for (let i = 0; i < rings - 1; i++) {
      const o0 = 1 + i * seg, o1 = 1 + (i + 1) * seg;
      for (let j = 0; j < seg; j++) {
        const j2 = (j + 1) % seg;
        idx.push(o0 + j, o1 + j, o0 + j2, o0 + j2, o1 + j, o1 + j2);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    g.setIndex(idx);
    g.computeVertexNormals();
    this.geo = g;
    this.uniforms = {
      uTime: { value: 0 },
      uFogColor: { value: new THREE.Color('#3cb7c4') },
      uFogNear: { value: 3 },
      uFogFar: { value: 80 },
      uUnder: { value: 1 },
      uSunDir: { value: new THREE.Vector3(0.4, 0.8, 0.3).normalize() },
      uDeep: { value: new THREE.Color('#0b4f75') },
      uShallow: { value: new THREE.Color('#1b95ad') },
      uSkyTop: { value: new THREE.Color('#3f8fd8') },
      uSkyHorizon: { value: new THREE.Color('#c6e7f4') },
      uCamDepth: { value: 0 },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      side: THREE.DoubleSide,
      vertexShader: `
        uniform float uTime;
        varying vec3 vWorld;
        varying vec3 vView;
        ${GLSL_NOISE}
        float waveH(vec2 p, float t){
          return 0.30*sin(p.x*0.72 + t*1.1)*cos(p.y*0.61 - t*0.9)
               + 0.18*sin(p.x*1.31 - t*1.7 + p.y*0.83)
               + 0.10*sin(p.y*2.1 + t*2.3)
               + 0.06*sin((p.x+p.y)*0.9 - t*1.5);
        }
        void main(){
          vec3 p = position;
          vec4 wp0 = modelMatrix * vec4(p, 1.0);
          float dist = length(wp0.xz - cameraPosition.xz);
          float amp = 1.0 / (1.0 + dist*0.012);
          wp0.y += waveH(wp0.xz, uTime) * amp;
          vWorld = wp0.xyz;
          vec4 mv = viewMatrix * wp0;
          vView = mv.xyz;
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        uniform float uTime; uniform vec3 uFogColor; uniform float uFogNear; uniform float uFogFar;
        uniform float uUnder; uniform vec3 uSunDir; uniform vec3 uDeep; uniform vec3 uShallow;
        uniform vec3 uSkyTop; uniform vec3 uSkyHorizon; uniform float uCamDepth;
        varying vec3 vWorld; varying vec3 vView;
        ${GLSL_NOISE}
        float waveH(vec2 p, float t){
          return 0.30*sin(p.x*0.72 + t*1.1)*cos(p.y*0.61 - t*0.9)
               + 0.18*sin(p.x*1.31 - t*1.7 + p.y*0.83)
               + 0.10*sin(p.y*2.1 + t*2.3)
               + 0.06*sin((p.x+p.y)*0.9 - t*1.5);
        }
        vec3 aces(vec3 x){
          return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0);
        }
        void main(){
          vec2 p = vWorld.xz;
          float e = 0.35;
          float h = waveH(p, uTime);
          float hx = waveH(p + vec2(e,0.0), uTime) - h;
          float hz = waveH(p + vec2(0.0,e), uTime) - h;
          vec3 nrm = normalize(vec3(-hx/e, 1.0, -hz/e));
          vec3 viewDir = normalize(cameraPosition - vWorld);
          float dist = length(vView);
          float fogF = clamp((dist - uFogNear) / max(0.001, uFogFar - uFogNear), 0.0, 1.0);
          vec3 base;
          if (uUnder > 0.5) {
            // вид снизу: мягкое светлое пятно над головой, без резких бликов
            vec3 toSurface = -viewDir;
            float upness = clamp(dot(toSurface, vec3(0.0,1.0,0.0)), 0.0, 1.0);
            float caus = fbm(p*0.22 + vec2(uTime*0.06, -uTime*0.05));
            float caus2 = fbm(p*0.55 - vec2(uTime*0.08, uTime*0.06));
            float near = clamp(1.0 - dist/260.0, 0.0, 1.0);
            float bright = pow(upness, 1.6);
            float dk = clamp(uCamDepth / 55.0, 0.0, 1.0);
            vec3 window = vec3(0.62, 0.88, 0.92);
            vec3 under = mix(uFogColor * 0.96, window, bright * (0.42 + 0.18*caus*caus2*near));
            under += vec3(0.06,0.09,0.09) * (bright * caus * near);
            under *= (1.0 - 0.62 * dk);
            base = mix(under, uFogColor, 0.18 + 0.6*fogF + 0.42*dk);
          } else {
            vec3 refl = mix(uSkyHorizon, uSkyTop, clamp(nrm.y*0.5+0.5, 0.0, 1.0));
            float fres = pow(1.0 - clamp(dot(nrm, viewDir), 0.0, 1.0), 3.0);
            vec3 water = mix(uDeep, uShallow, 0.45);
            vec3 col = mix(water, refl, clamp(0.18 + 0.7*fres, 0.0, 1.0));
            vec3 sun = normalize(uSunDir);
            vec3 reflDir = reflect(-viewDir, nrm);
            float spec = pow(max(dot(reflDir, sun), 0.0), 320.0);
            col += vec3(1.0, 0.95, 0.82) * spec * 1.1 * smoothstep(900.0, 80.0, dist);
            float fn = vn(p*3.5 + vec2(uTime*0.25, uTime*0.16));
            float fn2 = vn(p*11.0 - vec2(uTime*0.4, uTime*0.3));
            float foam = smoothstep(0.52, 0.74, h + (fn-0.5)*0.25 + (fn2-0.5)*0.12)
                       * smoothstep(320.0, 40.0, dist);
            col = mix(col, vec3(0.93,0.97,0.99), foam*0.55);
            base = col;
          }
          base = mix(base, uFogColor, fogF);
          gl_FragColor = vec4(pow(aces(base*1.05), vec3(1.0/2.2)), 1.0);
        }`,
    });
    this.mat = mat;
    this.mesh = new THREE.Mesh(g, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 1;
    scene.add(this.mesh);
  }
  update(camPos, camera) {
    this.mesh.position.set(camPos.x, 0, camPos.z);
    this.uniforms.uTime.value += 0.016;
  }
}

// ---------- небо ----------
class Sky {
  constructor(scene) {
    this.uniforms = {
      uUnder: { value: 1 },
      uFogColor: { value: new THREE.Color('#3cb7c4') },
      uSkyTop: { value: new THREE.Color('#3f8fd8') },
      uSkyHorizon: { value: new THREE.Color('#c6e7f4') },
      uTime: { value: 0 },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms, side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false,
      vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `
        uniform float uUnder; uniform vec3 uFogColor; uniform vec3 uSkyTop; uniform vec3 uSkyHorizon;
        uniform float uTime; varying vec3 vDir;
        ${GLSL_NOISE}
        vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0); }
        void main(){
          if (uUnder > 0.5) { gl_FragColor = vec4(pow(aces(uFogColor*1.05), vec3(1.0/2.2)), 1.0); return; }
          float y = clamp(vDir.y*0.5+0.5, 0.0, 1.0);
          vec3 col = mix(uSkyHorizon, uSkyTop, pow(clamp(vDir.y,0.0,1.0), 0.55));
          vec3 sun = normalize(vec3(0.4,0.62,0.3));
          float d = max(dot(normalize(vDir), sun), 0.0);
          col += vec3(1.0,0.93,0.75) * pow(d, 900.0) * 3.0;
          col += vec3(1.0,0.9,0.7) * pow(d, 12.0) * 0.18;
          // облака
          vec2 cp = vDir.xz / max(0.12, vDir.y) * 0.6;
          float cl = fbm(cp*0.9 + vec2(uTime*0.006, 0.0));
          float cover = smoothstep(0.52, 0.78, cl) * smoothstep(0.02, 0.22, vDir.y);
          col = mix(col, vec3(0.98,0.99,1.0), cover*0.85);
          gl_FragColor = vec4(pow(aces(col*1.05), vec3(1.0/2.2)), 1.0);
        }`,
    });
    this.mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = -10;
    scene.add(this.mesh);
    this.mat = mat;
  }
  update(camera, far) {
    this.mesh.position.copy(camera.position);
    this.mesh.scale.setScalar(far * 0.85);
  }
}

// ---------- лучи света ----------
class LightShafts {
  constructor(scene) {
    const count = IS_MOBILE ? 8 : 13;
    this.uniforms = {
      uTime: { value: 0 }, uOpacity: { value: 0.5 }, uColor: { value: new THREE.Color('#d7f8ff') },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms, transparent: true, depthWrite: false,
      blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false,
      vertexShader: `
        uniform float uTime;
        varying vec2 vUv;
        void main(){
          vUv = uv;
          vec3 p = position;
          float sway = sin(uTime*0.3 + instanceMatrix[3].x*0.11 + instanceMatrix[3].z*0.07 + (p.y+0.5)*1.4)*0.16;
          p.x += sway * (p.y + 0.5);
          vec4 wp = instanceMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * viewMatrix * modelMatrix * wp;
        }`,
      fragmentShader: `
        uniform float uOpacity; uniform vec3 uColor;
        varying vec2 vUv;
        void main(){
          float edge = smoothstep(0.0, 0.42, vUv.x) * smoothstep(1.0, 0.58, vUv.x);
          float vert = smoothstep(0.0, 0.18, vUv.y) * smoothstep(1.0, 0.5, vUv.y);
          float a = edge * vert * uOpacity;
          gl_FragColor = vec4(uColor * a * 0.55, a * 0.5);
        }`,
    });
    this.count = count;
    this.mesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1, 1, 1), mat, count * 2);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 5;
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    scene.add(this.mesh);
    this.seeds = [];
    for (let i = 0; i < count; i++) this.seeds.push({ x: (Math.random() - 0.5), z: (Math.random() - 0.5), s: 0.7 + Math.random() * 0.8, ph: Math.random() * 10 });
    this.dummy = new THREE.Object3D();
  }
  update(camPos, L, depth, time) {
    this.uniforms.uTime.value = time;
    const tile = Math.max(60, 60 * Math.max(1, L / 6));
    const h = Math.max(50, 50 * Math.max(1, L / 6));
    const w = Math.max(2, 2 * Math.max(1, L / 6));
    const fade = clamp(1 - depth / 60, 0, 1) * clamp(1 - L / 90, 0.25, 1);
    this.uniforms.uOpacity.value = 0.62 * fade;
    for (let i = 0; i < this.seeds.length; i++) {
      const s = this.seeds[i];
      const x = camPos.x + s.x * tile;
      const z = camPos.z + s.z * tile;
      const top = -0.6;
      for (let k = 0; k < 2; k++) {
        const a = k * Math.PI / 2 + s.ph;
        this.dummy.position.set(x, top - h * 0.5, z);
        this.dummy.rotation.set(0, a, 0);
        this.dummy.scale.set(w * s.s, h, 1);
        this.dummy.updateMatrix();
        this.mesh.setMatrixAt(i * 2 + k, this.dummy.matrix);
      }
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}

// ---------- взвесь ----------
class Particles {
  constructor(scene) {
    const count = IS_MOBILE ? 650 : 1500;
    const pos = new Float32Array(count * 3);
    const rnd = mulberry32(12345);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = rnd(); pos[i * 3 + 1] = rnd(); pos[i * 3 + 2] = rnd();
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.uniforms = {
      uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uBox: { value: 24 },
      uSize: { value: 0.05 }, uFogColor: { value: new THREE.Color('#3cb7c4') },
      uFogNear: { value: 3 }, uFogFar: { value: 80 }, uScale: { value: 1 },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms, transparent: true, depthWrite: false, fog: false,
      blending: THREE.NormalBlending,
      vertexShader: `
        uniform float uTime; uniform vec3 uCam; uniform float uBox; uniform float uSize; uniform float uScale;
        varying float vFade; varying float vDist;
        void main(){
          vec3 p = position * uBox;
          float t = uTime;
          p.x += sin(t*0.13 + position.y*6.28)*0.6;
          p.y += t*0.12 + sin(t*0.21 + position.z*6.28)*0.4;
          p.z += cos(t*0.11 + position.x*6.28)*0.6;
          vec3 rel = p - uCam;
          rel = mod(rel + uBox*0.5, uBox) - uBox*0.5;
          vec3 wp = uCam + rel;
          vec4 mv = viewMatrix * vec4(wp, 1.0);
          vDist = length(mv.xyz);
          vFade = smoothstep(uBox*0.5, uBox*0.15, length(rel));
          gl_PointSize = uSize * uScale / max(1.0, -mv.z) * 900.0;
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        uniform vec3 uFogColor; uniform float uFogNear; uniform float uFogFar;
        varying float vFade; varying float vDist;
        void main(){
          vec2 d = gl_PointCoord - 0.5;
          float a = smoothstep(0.5, 0.1, length(d));
          float fogF = clamp((vDist - uFogNear)/max(0.001, uFogFar-uFogNear), 0.0, 1.0);
          vec3 c = mix(vec3(0.86,0.97,1.0), uFogColor, fogF*0.9);
          gl_FragColor = vec4(c, a*0.55*vFade*(1.0-fogF));
        }`,
    });
    this.mesh = new THREE.Points(g, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 4;
    scene.add(this.mesh);
  }
  update(camPos, L, time, depth) {
    this.uniforms.uTime.value = time;
    this.uniforms.uCam.value.copy(camPos);
    this.uniforms.uBox.value = 24 * Math.max(1, L / 1.5);
    this.uniforms.uSize.value = 0.04 * Math.max(1, L / 1.5);
    this.uniforms.uScale.value = 1;
  }
}

// ---------- декор ----------
const TYPE_BY_ID = Object.fromEntries(DECOR_TYPES.map(t => [t.id, t]));
const SMALL_TYPES = ['shell', 'starfish', 'urchin', 'seagrass', 'anemone', 'coralFan', 'rock'];

class Decor {
  constructor(scene) {
    this.scene = scene;
    this.protos = new Map();
    const rnd = mulberry32(777);
    for (const t of DECOR_TYPES) {
      const variants = [];
      for (let v = 0; v < 2; v++) variants.push(buildDecorPrototype(t, rnd));
      this.protos.set(t.id, variants);
    }
    this.chunks = new Map();
    this.cells = new Map();
    this.itemsNear = [];
    this.colliders = [];
    this.material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85, metalness: 0.02, side: THREE.DoubleSide });
    this.material.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.uniforms.uTime;
      sh.vertexShader = 'uniform float uTime;\nattribute float aSway;\n' + sh.vertexShader
        .replace('#include <begin_vertex>', `#include <begin_vertex>
          float sw = aSway * sin(uTime*1.1 + (modelMatrix[3].x + modelMatrix[3].z)*0.7);
          transformed.x += sw * 0.06;
          transformed.z += sw * 0.05;
        `);
    };
    this.uniforms = { uTime: { value: 0 } };
  }

  biomeDensity(biome) {
    return biome === 'reef' ? 0.045 : biome === 'fields' ? 0.013 : biome === 'slope' ? 0.017 : 0.003;
  }

  pickTypes(biome, rnd) {
    const pool = [];
    for (const t of DECOR_TYPES) if (t.biomes.includes(biome)) pool.push(t);
    if (!pool.length) return TYPE_BY_ID.rock;
    const weights = pool.map(t => {
      if (t.id === 'bommie') return 0.4;
      if (t.id === 'pillar') return 0.05;
      if (t.id === 'arch') return 0.02;
      if (t.id === 'wreck') return 0.015;
      if (t.id === 'kelp' || t.id === 'coralBush' || t.id === 'coralBrain') return 1.0;
      return 1.6;
    });
    let total = weights.reduce((a, b) => a + b, 0);
    let v = rnd() * total;
    for (let i = 0; i < pool.length; i++) { v -= weights[i]; if (v <= 0) return pool[i]; }
    return pool[pool.length - 1];
  }

  buildChunk(key, cx, cz, size, L) {
    const k = depthScale(L);
    const rnd = mulberry32((hash2i(cx, cz, 991) * 4294967295) | 0);
    const centerX = cx * size + size / 2, centerZ = cz * size + size / 2;
    const w = biomeWeights(centerX, centerZ);
    const biome = biomeAt(centerX, centerZ);
    const density = this.biomeDensity(biome) / (k * k);
    const count = Math.min(420, Math.max(0, Math.round(size * size * density)));
    const items = [];
    const merged = { p: [], c: [], s: [], i: [] };
    const colliders = [];
    for (let n = 0; n < count; n++) {
      const type = this.pickTypes(biome, rnd);
      const x = centerX + (rnd() - 0.5) * size;
      const z = centerZ + (rnd() - 0.5) * size;
      const r = Math.hypot(x, z);
      if (type.id === 'bommie' && r < 10) continue;
      if (type.id === 'pillar' && r < 20) continue;
      if (type.id === 'arch' && r < 150) continue;
      if (type.id === 'wreck' && r < 150) continue;
      const d = terrainDepth(x, z, L);
      if (d < 4) continue;
      const baseSize = lerp(type.size[0], type.size[1], rnd() * rnd()) * k;
      const variants = this.protos.get(type.id);
      const geo = variants[Math.floor(rnd() * variants.length)];
      const bright = 0.86 + rnd() * 0.28;
      const m = new THREE.Matrix4();
      const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), rnd() * Math.PI * 2);
      m.compose(new THREE.Vector3(x, -d + baseSize * 0.05, z), q, new THREE.Vector3(baseSize, baseSize, baseSize));
      const posAttr = geo.attributes.position.array;
      const colAttr = geo.attributes.color.array;
      const swayAttr = geo.attributes.aSpine ? null : null;
      const off = merged.p.length / 3;
      const v = new THREE.Vector3();
      const nm = new THREE.Matrix3().getNormalMatrix(m);
      const nrmAttr = geo.attributes.normal.array;
      for (let i = 0; i < posAttr.length / 3; i++) {
        v.set(posAttr[i * 3], posAttr[i * 3 + 1], posAttr[i * 3 + 2]).applyMatrix4(m);
        merged.p.push(v.x, v.y, v.z);
        merged.c.push(colAttr[i * 3] * bright, colAttr[i * 3 + 1] * bright, colAttr[i * 3 + 2] * bright);
        const sp = geo.attributes.aSpine.array[i];
        merged.s.push(type.sway ? sp * type.sway : 0);
      }
      const idx = geo.index.array;
      for (let i = 0; i < idx.length; i++) merged.i.push(idx[i] + off);
      items.push({ x, z, size: baseSize, type: type.id });
      if (['bommie', 'pillar', 'arch', 'wreck', 'ledge'].includes(type.id)) {
        colliders.push({ x, y: -d + baseSize * 0.35, z, r: baseSize * 0.42 });
      }
      if (merged.p.length > 400000) break;
    }
    if (!items.length) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(merged.p, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(merged.c, 3));
    g.setAttribute('aSway', new THREE.Float32BufferAttribute(merged.s, 1));
    g.setIndex(merged.i);
    g.computeVertexNormals();
    g.computeBoundingSphere();
    const mesh = new THREE.Mesh(g, this.material);
    mesh.matrixAutoUpdate = false;
    this.scene.add(mesh);
    return { mesh, items, colliders, key };
  }

  update(px, pz, L, time, force = false) {
    this.uniforms.uTime.value = time;
    const k = depthScale(L);
    const size = Math.max(30, 44 * k);
    const radius = 1.1 * visibility(L) + size;
    const chunksNeeded = Math.ceil(radius / size);
    const ccx = Math.floor(px / size), ccz = Math.floor(pz / size);
    const keep = new Set();
    for (let dz = -chunksNeeded; dz <= chunksNeeded; dz++) {
      for (let dx = -chunksNeeded; dx <= chunksNeeded; dx++) {
        const cx = ccx + dx, cz = ccz + dz;
        const wx = cx * size + size / 2, wz = cz * size + size / 2;
        if (Math.hypot(wx - px, wz - pz) > radius) continue;
        const key = `${cx},${cz},${size.toFixed(1)}`;
        keep.add(key);
        if (!this.chunks.has(key)) {
          const ch = this.buildChunk(key, cx, cz, size, L);
          if (ch) this.chunks.set(key, ch);
          else this.chunks.set(key, { mesh: null, items: [], colliders: [], key });
        }
      }
    }
    for (const [key, ch] of this.chunks) {
      if (!keep.has(key)) {
        if (ch.mesh) { this.scene.remove(ch.mesh); ch.mesh.geometry.dispose(); }
        this.chunks.delete(key);
      }
    }
    // мелкая сыпь вокруг игрока
    this.updateScatter(px, pz, L, k);

    // сбор статистики
    this.itemsNear.length = 0;
    this.colliders.length = 0;
    for (const ch of this.chunks.values()) {
      if (!ch.mesh) continue;
      for (const it of ch.items) {
        const d = Math.hypot(it.x - px, it.z - pz);
        if (d < 200) this.itemsNear.push(d);
      }
      for (const c of ch.colliders) this.colliders.push(c);
    }
    for (const cell of this.cells.values()) {
      if (!cell.mesh) continue;
      for (const it of cell.items) {
        const d = Math.hypot(it.x - px, it.z - pz);
        if (d < 200) this.itemsNear.push(d);
      }
    }
  }

  updateScatter(px, pz, L, k) {
    const cellSize = 8 * k;
    const radius = 27 * k;
    const n = Math.ceil(radius / cellSize);
    const ccx = Math.floor(px / cellSize), ccz = Math.floor(pz / cellSize);
    const keep = new Set();
    for (let dz = -n; dz <= n; dz++) {
      for (let dx = -n; dx <= n; dx++) {
        const cx = ccx + dx, cz = ccz + dz;
        const wx = cx * cellSize + cellSize / 2, wz = cz * cellSize + cellSize / 2;
        if (Math.hypot(wx - px, wz - pz) > radius) continue;
        const key = `${cx},${cz},${cellSize.toFixed(1)}`;
        keep.add(key);
        if (!this.cells.has(key)) this.cells.set(key, this.buildScatter(key, cx, cz, cellSize, L, k));
      }
    }
    for (const [key, cell] of this.cells) {
      if (!keep.has(key)) {
        if (cell.mesh) { this.scene.remove(cell.mesh); cell.mesh.geometry.dispose(); }
        this.cells.delete(key);
      }
    }
  }

  buildScatter(key, cx, cz, size, L, k) {
    const rnd = mulberry32((hash2i(cx, cz, 1777) * 4294967295) | 0);
    const centerX = cx * size + size / 2, centerZ = cz * size + size / 2;
    const biome = biomeAt(centerX, centerZ);
    const density = (biome === 'reef' ? 0.17 : biome === 'fields' ? 0.055 : biome === 'slope' ? 0.045 : 0.01) / (k * k);
    const count = Math.max(0, Math.round(size * size * density));
    const merged = { p: [], c: [], s: [], i: [] };
    const items = [];
    const pool = DECOR_TYPES.filter(t => t.biomes.includes(biome) && SMALL_TYPES.includes(t.id));
    if (!pool.length) return { mesh: null, items: [], key };
    for (let n = 0; n < count; n++) {
      const type = pool[Math.floor(rnd() * pool.length)];
      const x = centerX + (rnd() - 0.5) * size;
      const z = centerZ + (rnd() - 0.5) * size;
      const d = terrainDepth(x, z, L);
      const baseSize = lerp(type.size[0], type.size[1], rnd()) * k * 0.8;
      const geo = this.protos.get(type.id)[Math.floor(rnd() * 2)];
      const bright = 0.85 + rnd() * 0.3;
      const m = new THREE.Matrix4();
      const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), rnd() * Math.PI * 2);
      m.compose(new THREE.Vector3(x, -d + baseSize * 0.04, z), q, new THREE.Vector3(baseSize, baseSize, baseSize));
      const posAttr = geo.attributes.position.array, colAttr = geo.attributes.color.array;
      const off = merged.p.length / 3;
      const v = new THREE.Vector3();
      for (let i = 0; i < posAttr.length / 3; i++) {
        v.set(posAttr[i * 3], posAttr[i * 3 + 1], posAttr[i * 3 + 2]).applyMatrix4(m);
        merged.p.push(v.x, v.y, v.z);
        merged.c.push(colAttr[i * 3] * bright, colAttr[i * 3 + 1] * bright, colAttr[i * 3 + 2] * bright);
        merged.s.push(type.sway ? geo.attributes.aSpine.array[i] * type.sway : 0);
      }
      const idx = geo.index.array;
      for (let i = 0; i < idx.length; i++) merged.i.push(idx[i] + off);
      items.push({ x, z, size: baseSize, type: type.id });
    }
    if (!items.length) return { mesh: null, items: [], key };
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(merged.p, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(merged.c, 3));
    g.setAttribute('aSway', new THREE.Float32BufferAttribute(merged.s, 1));
    g.setIndex(merged.i);
    g.computeVertexNormals();
    g.computeBoundingSphere();
    const mesh = new THREE.Mesh(g, this.material);
    mesh.matrixAutoUpdate = false;
    this.scene.add(mesh);
    return { mesh, items, key };
  }

  countWithin(r) {
    let c = 0;
    for (const d of this.itemsNear) if (d <= r) c++;
    return c;
  }
}

// ---------- медузы ----------
class Jellyfish {
  constructor(scene) {
    this.count = IS_MOBILE ? 7 : 13;
    const bell = new THREE.SphereGeometry(0.5, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.55);
    const mat = new THREE.MeshStandardMaterial({
      color: '#bfe9ff', transparent: true, opacity: 0.34, roughness: 0.2,
      emissive: new THREE.Color('#79d6ff'), emissiveIntensity: 0.6, side: THREE.DoubleSide, depthWrite: false,
    });
    this.mesh = new THREE.InstancedMesh(bell, mat, this.count);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 3;
    this.items = [];
    for (let i = 0; i < this.count; i++) {
      this.items.push({
        x: (Math.random() - 0.5) * 120, z: (Math.random() - 0.5) * 120, y: -8 - Math.random() * 18,
        ph: Math.random() * 10, s: 0.5 + Math.random() * 0.6,
      });
    }
    this.dummy = new THREE.Object3D();
    scene.add(this.mesh);
  }
  update(dt, px, pz, L, time, depthFn) {
    const scale = Math.max(1, L / 1.6);
    const range = 110 * scale;
    for (let i = 0; i < this.count; i++) {
      const it = this.items[i];
      it.x += Math.sin(time * 0.2 + it.ph) * dt * 0.35 * scale;
      it.z += Math.cos(time * 0.17 + it.ph * 1.3) * dt * 0.3 * scale;
      it.y += Math.sin(time * 0.5 + it.ph) * dt * 0.4 * scale;
      if (it.y > -3 * scale) it.y = -3 * scale;
      if (Math.hypot(it.x - px, it.z - pz) > range) {
        const a = Math.random() * Math.PI * 2;
        it.x = px + Math.cos(a) * range * (0.5 + Math.random() * 0.4);
        it.z = pz + Math.sin(a) * range * (0.5 + Math.random() * 0.4);
        const bd = depthFn(it.x, it.z);
        it.y = -clamp(bd * 0.6, 3 * scale, 30 * scale) - Math.random() * 6 * scale;
      }
      const pulse = 1 + 0.16 * Math.sin(time * 2.2 + it.ph);
      this.dummy.position.set(it.x, it.y, it.z);
      this.dummy.scale.set(it.s * scale * pulse, it.s * scale / pulse, it.s * scale * pulse);
      this.dummy.rotation.set(Math.sin(time * 0.4 + it.ph) * 0.15, time * 0.1 + it.ph, 0);
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}

// ---------- мир ----------
export class World {
  constructor(scene, renderer) {
    this.scene = scene;
    this.terrain = new Terrain(scene);
    this.water = new WaterSurface(scene, renderer);
    this.sky = new Sky(scene);
    this.shafts = new LightShafts(scene);
    this.particles = new Particles(scene);
    this.decor = new Decor(scene);
    this.jelly = new Jellyfish(scene);
    this.fogColor = new THREE.Color('#3cb7c4');
    this.time = 0;
    this.underwater = 1;
    this.L = 0.78;
    scene.fog = new THREE.Fog(this.fogColor, 3.6, 72);
    this.hemi = new THREE.HemisphereLight(0xcff6ff, 0x2a4a5a, 1.2);
    scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff2d8, 1.55);
    this.sun.position.set(60, 120, 45);
    scene.add(this.sun);
    this.ambient = new THREE.AmbientLight(0x9fdce8, 0.18);
    scene.add(this.ambient);
  }

  update(dt, camera, playerPos, L, opts = {}) {
    this.time += dt;
    this.L = L;
    const V = visibility(L);
    const depth = -playerPos.y;
    const isUnder = camera.position.y < 0.1;
    this.underwater = isUnder ? 1 : 0;
    const wc = waterColorAt(playerPos.x, playerPos.z, Math.max(0, depth), this.fogColor);
    const airColor = new THREE.Color('#c6e7f4');
    // туман
    if (isUnder) {
      this.scene.fog.color.copy(wc);
      this.scene.fog.near = 0.05 * V;
      this.scene.fog.far = V;
      this.scene.background = null;
    } else {
      this.scene.fog.color.copy(airColor);
      this.scene.fog.near = 900;
      this.scene.fog.far = 3500;
    }
    // свет гаснет с глубиной
    const df = clamp(depth / 100, 0, 1);
    this.hemi.intensity = lerp(1.2, 0.7, df);
    this.sun.intensity = lerp(1.55, 0.32, df);
    this.sun.position.set(playerPos.x + 60, 120, playerPos.z + 45);
    this.sun.target.position.copy(playerPos);
    this.ambient.intensity = lerp(0.18, 0.1, df);

    this.terrain.update(playerPos.x, playerPos.z, L, opts.force);
    this.water.uniforms.uFogColor.value.copy(wc);
    this.water.uniforms.uFogNear.value = isUnder ? 0.05 * V : 800;
    this.water.uniforms.uFogFar.value = isUnder ? V : 3500;
    this.water.uniforms.uUnder.value = isUnder ? 1 : 0;
    this.water.uniforms.uTime.value = this.time;
    this.water.uniforms.uCamDepth.value = Math.max(0, -camera.position.y);
    this.water.mesh.position.set(camera.position.x, 0, camera.position.z);
    this.sky.uniforms.uUnder.value = isUnder ? 1 : 0;
    this.sky.uniforms.uFogColor.value.copy(wc);
    this.sky.uniforms.uTime.value = this.time;
    this.sky.update(camera, camera.far);
    this.shafts.update(camera.position, L, depth, this.time);
    this.particles.uniforms.uFogColor.value.copy(wc);
    this.particles.uniforms.uFogNear.value = 0.05 * V;
    this.particles.uniforms.uFogFar.value = V;
    this.particles.update(camera.position, L, this.time, depth);
    this.decor.update(playerPos.x, playerPos.z, L, this.time, opts.force);
    this.jelly.update(dt, playerPos.x, playerPos.z, L, this.time, (x, z) => terrainDepth(x, z, L));
    this.shafts.mesh.visible = isUnder;
    this.jelly.mesh.visible = isUnder;
    this.particles.mesh.visible = isUnder;
  }

  decorCount(r) { return this.decor.countWithin(r); }
}
