// Процедурные модели: рыбы, декорации, суда, сундук, клетка с водолазом.
import * as THREE from 'three';
import { mulberry32, noise2, smoothstep } from './noise.js';

// ---------- утилиты построения геометрии ----------
class MB {
  constructor() { this.p = []; this.c = []; this.s = []; this.i = []; }
  v(x, y, z, col, sp = 0) {
    this.p.push(x, y, z);
    this.c.push(col[0], col[1], col[2]);
    this.s.push(sp);
    return this.p.length / 3 - 1;
  }
  tri(a, b, c) { this.i.push(a, b, c); }
  quad(a, b, c, d) { this.i.push(a, b, c, a, c, d); }
  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.p, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.c, 3));
    g.setAttribute('aSpine', new THREE.Float32BufferAttribute(this.s, 1));
    g.setIndex(this.i);
    g.computeVertexNormals();
    g.computeBoundingSphere();
    return g;
  }
}

const col = (hex) => { const c = new THREE.Color(hex); return [c.r, c.g, c.b]; };
const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const dark = (a, k) => [a[0] * k, a[1] * k, a[2] * k];

function smoothProfile(points) {
  // points: [[t, h, w], ...] по возрастанию t
  return (t) => {
    for (let i = 0; i < points.length - 1; i++) {
      const a = points[i], b = points[i + 1];
      if (t <= b[0] || i === points.length - 2) {
        const f = smoothstep(0, 1, (t - a[0]) / Math.max(1e-5, b[0] - a[0]));
        return [a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
      }
    }
    return [points[0][1], points[0][2]];
  };
}

// ---------- рыбы ----------
export const FISH_SPECS = {
  sardine: {
    profile: smoothProfile([[0, 0.004, 0.004], [0.08, 0.045, 0.026], [0.3, 0.065, 0.038], [0.6, 0.05, 0.03], [0.88, 0.02, 0.013], [1, 0.008, 0.006]]),
    colors: { back: '#7ea6bd', side: '#cfe6f2', belly: '#f2fbff', fin: '#bfdcea', tail: '#a9c9dc' },
    tail: 'fork', finScale: 0.9, eye: 0.055,
    color(t, cx, sy) {
      const b = col(this.colors.back), s = col(this.colors.side), bel = col(this.colors.belly);
      const v = sy * 1.0;
      if (v > 0.35) return mix(s, b, smoothstep(0.35, 0.95, v));
      return mix(s, bel, smoothstep(0.35, 0.95, -v));
    },
  },
  clown: {
    profile: smoothProfile([[0, 0.01, 0.008], [0.12, 0.13, 0.07], [0.35, 0.16, 0.085], [0.65, 0.13, 0.07], [0.9, 0.04, 0.022], [1, 0.014, 0.01]]),
    colors: { back: '#ff7a12', side: '#ff8f24', belly: '#ffb055', fin: '#ff9b3d', tail: '#ff8a20' },
    tail: 'round', finScale: 1.05, eye: 0.075,
    color(t, cx, sy) {
      const orange = mix(col('#ff7a12'), col('#ffb055'), smoothstep(0.2, -0.8, sy));
      const band = (c, w) => Math.abs(t - c) < w;
      if (band(0.17, 0.055) || band(0.5, 0.06) || band(0.8, 0.05)) {
        const edge = (Math.abs(t - 0.17) < 0.075) || (Math.abs(t - 0.5) < 0.08) || (Math.abs(t - 0.8) < 0.07);
        if (!band(0.17, 0.057) && !band(0.5, 0.062) && !band(0.8, 0.052) && edge) return col('#2a1b16');
        return col('#fff6e2');
      }
      return orange;
    },
  },
  butterfly: {
    profile: smoothProfile([[0, 0.01, 0.008], [0.12, 0.19, 0.055], [0.4, 0.27, 0.07], [0.7, 0.2, 0.055], [0.9, 0.06, 0.02], [1, 0.02, 0.01]]),
    colors: { back: '#ffc72e', side: '#ffd84f', belly: '#fff0b0', fin: '#ffcf3d', tail: '#ffd23f' },
    tail: 'fan', finScale: 1.1, eye: 0.07,
    color(t, cx, sy) {
      if (t < 0.16) return col('#3b3326');
      const y = mix(col('#ffc72e'), col('#fff6d8'), smoothstep(-0.2, -0.95, sy));
      return t > 0.82 ? mix(y, col('#e8a516'), 0.4) : y;
    },
  },
  tang: {
    profile: smoothProfile([[0, 0.008, 0.006], [0.1, 0.16, 0.045], [0.35, 0.26, 0.06], [0.68, 0.21, 0.05], [0.9, 0.07, 0.02], [1, 0.022, 0.01]]),
    colors: { back: '#2153c8', side: '#2f6fe0', belly: '#4f8cf0', fin: '#ffd94a', tail: '#ffd233' },
    tail: 'fan', finScale: 1.0, eye: 0.075,
    color(t, cx, sy) {
      const base = mix(col('#1d47b4'), col('#4f8cf0'), smoothstep(0.3, -0.7, sy));
      if (t > 0.62 && Math.abs(t - 0.78) < 0.13 && sy > -0.35) return col('#0e2452');
      if (t > 0.82) return col('#ffe066');
      if (Math.abs(t - 0.3) < 0.1 && sy > 0.2) return col('#14265e');
      return base;
    },
  },
  mackerel: {
    profile: smoothProfile([[0, 0.005, 0.005], [0.1, 0.055, 0.035], [0.35, 0.08, 0.05], [0.72, 0.06, 0.04], [0.92, 0.02, 0.014], [1, 0.01, 0.007]]),
    colors: { back: '#3f8f7a', side: '#79c1a6', belly: '#e8f6ee', fin: '#b9dcc4', tail: '#8fb9a4' },
    tail: 'fork', finScale: 0.95, eye: 0.06,
    color(t, cx, sy) {
      const back = col('#2f7a67'), side = col('#8ecfb4'), belly = col('#f0faf2');
      const c = sy > 0.1 ? mix(side, back, smoothstep(0.1, 0.95, sy)) : mix(side, belly, smoothstep(0.1, -0.95, sy));
      if (sy > 0.1 && Math.sin(t * 46) > 0.45) return dark(back, 0.62);
      return c;
    },
  },
  tuna: {
    profile: smoothProfile([[0, 0.008, 0.008], [0.09, 0.085, 0.07], [0.32, 0.115, 0.095], [0.62, 0.095, 0.075], [0.88, 0.03, 0.022], [1, 0.012, 0.008]]),
    colors: { back: '#3d5d7d', side: '#7d9cb5', belly: '#e9f2f8', fin: '#ffd23f', tail: '#e8c23a' },
    tail: 'crescent', finScale: 1.1, eye: 0.06,
    color(t, cx, sy) {
      const back = col('#31506f'), side = col('#8fadc4'), belly = col('#eef6fb');
      return sy > 0.05 ? mix(side, back, smoothstep(0.05, 0.95, sy)) : mix(side, belly, smoothstep(0.05, -0.9, sy));
    },
  },
  barracuda: {
    profile: smoothProfile([[0, 0.004, 0.004], [0.08, 0.032, 0.024], [0.3, 0.05, 0.038], [0.7, 0.04, 0.03], [0.92, 0.014, 0.01], [1, 0.008, 0.005]]),
    colors: { back: '#556a74', side: '#b9c6cc', belly: '#eef4f7', fin: '#9fb1b8', tail: '#8b9ea6' },
    tail: 'fork', finScale: 0.85, eye: 0.05, jaws: true,
    color(t, cx, sy) {
      const back = col('#4e6670'), side = col('#c3d0d6'), belly = col('#f2f8fa');
      const c = sy > 0 ? mix(side, back, smoothstep(0, 0.95, sy)) : mix(side, belly, smoothstep(0, -0.9, sy));
      if (sy > 0 && Math.sin(t * 30) > 0.75) return dark(back, 0.8);
      return c;
    },
  },
  hammerhead: {
    profile: smoothProfile([[0, 0.012, 0.03], [0.06, 0.05, 0.075], [0.16, 0.075, 0.07], [0.4, 0.095, 0.08], [0.7, 0.07, 0.06], [0.9, 0.028, 0.022], [1, 0.012, 0.01]]),
    colors: { back: '#7d8c96', side: '#9fb0ba', belly: '#f0f5f7', fin: '#8d9ca6', tail: '#7b8a94' },
    tail: 'crescent', finScale: 1.25, eye: 0.05, hammer: 2.6, shark: true,
    color(t, cx, sy) {
      const back = col('#6e7f8a'), side = col('#a5b4bd'), belly = col('#f4f8fa');
      return sy > -0.1 ? mix(side, back, smoothstep(-0.1, 0.9, sy)) : mix(side, belly, smoothstep(-0.1, -0.9, sy));
    },
  },
  greatwhite: {
    profile: smoothProfile([[0, 0.014, 0.016], [0.07, 0.07, 0.075], [0.26, 0.115, 0.105], [0.55, 0.1, 0.09], [0.8, 0.055, 0.045], [0.93, 0.022, 0.018], [1, 0.014, 0.01]]),
    colors: { back: '#5f7382', side: '#8fa4b1', belly: '#f4f9fb', fin: '#6f8491', tail: '#5d7180' },
    tail: 'crescent', finScale: 1.3, eye: 0.045, shark: true, jaws: true,
    color(t, cx, sy) {
      const back = col('#54697a'), side = col('#93a8b5'), belly = col('#f6fafc');
      return sy > -0.15 ? mix(side, back, smoothstep(-0.15, 0.8, sy)) : mix(side, belly, smoothstep(-0.15, -0.85, sy));
    },
  },
  whaleshark: {
    profile: smoothProfile([[0, 0.012, 0.018], [0.06, 0.075, 0.09], [0.24, 0.13, 0.13], [0.55, 0.115, 0.115], [0.82, 0.06, 0.05], [0.94, 0.025, 0.02], [1, 0.015, 0.012]]),
    colors: { back: '#1e4560', side: '#2c5d7e', belly: '#dcecf3', fin: '#2a5674', tail: '#224a66' },
    tail: 'crescent', finScale: 1.2, eye: 0.04, shark: true, spots: true,
    color(t, cx, sy) {
      const back = col('#21506e'), belly = col('#c8dde8');
      const c = sy > -0.25 ? mix(back, col('#2c6588'), smoothstep(-0.25, 0.6, sy)) : mix(col('#3a6b86'), belly, smoothstep(-0.25, -0.9, sy));
      const n = noise2(t * 22, (Math.atan2(sy, cx) + 3) * 2.4, 7);
      if (n > 0.63) return col('#dff0f6');
      if (n > 0.56) return col('#87aec4');
      return c;
    },
  },
};

function fishTail(b, spec, prof) {
  const [h, w] = prof(1);
  const zTail = 0.5;
  const kind = spec.tail;
  const finCol = col(spec.colors.tail);
  const s = spec.finScale || 1;
  const spread = kind === 'crescent' ? 0.24 : kind === 'fork' ? 0.17 : kind === 'fan' ? 0.2 : 0.14;
  const len = kind === 'crescent' ? 0.26 : kind === 'fork' ? 0.18 : kind === 'fan' ? 0.13 : 0.11;
  const nx = w * 0.9;
  const rootTop = b.v(nx * 0.2, h, zTail, finCol, 1), rootBot = b.v(nx * 0.2, -h, zTail, finCol, 1);
  const backMid = b.v(nx * 0.35, 0, zTail + len * 0.25, finCol, 1);
  const tipT = b.v(nx * 0.5, h + spread * s, zTail + len * s, finCol, 1);
  const tipB = b.v(nx * 0.5, -h - spread * s, zTail + len * s, finCol, 1);
  if (kind === 'fork' || kind === 'crescent') {
    b.tri(rootTop, backMid, tipT);
    b.tri(rootBot, tipB, backMid);
    b.tri(backMid, tipT, tipB);
  } else if (kind === 'round' || kind === 'fan') {
    b.tri(rootTop, backMid, tipT);
    b.tri(backMid, tipB, tipT);
    b.tri(rootBot, tipB, backMid);
  } else {
    b.tri(rootTop, backMid, tipT);
    b.tri(rootBot, tipB, backMid);
  }
}

function finSheet(b, pts2d, tValue, finCol, thicknessPlane = 'y') {
  // pts2d: [[t, y, zoff], ...] строим ленту в плоскости x=0
  let prev = null;
  for (const p of pts2d) {
    const v = b.v(0, p[1], p[2], finCol, tValue);
    if (prev !== null) { /* strip */ }
    prev = v;
  }
}

export function buildFishGeometry(speciesId, quality = 'fish') {
  const spec = FISH_SPECS[speciesId];
  if (!spec) throw new Error('unknown species ' + speciesId);
  const b = new MB();
  const M = quality === 'player' ? 20 : 12;
  const N = quality === 'player' ? 30 : 16;
  const prof = spec.profile;
  const rings = [];
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    let [h, w] = prof(t);
    const ring = [];
    for (let j = 0; j < M; j++) {
      const a = (j / M) * Math.PI * 2;
      const cx = Math.cos(a), sy = Math.sin(a);
      let x = cx * w, yv = sy * h;
      if (yv < 0) yv *= 0.86; // плоское брюхо
      if (spec.hammer && t < 0.1) {
        const k = 1 + (spec.hammer - 1) * smoothstep(0.1, 0.0, t);
        x = cx * w * k;
        yv = sy * h * (1 - 0.35 * smoothstep(0.1, 0.0, t));
      }
      const c = spec.color(t, cx, sy);
      ring.push(b.v(x, yv, -0.5 + t, c, t));
    }
    rings.push(ring);
  }
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < M; j++) {
      const j2 = (j + 1) % M;
      b.quad(rings[i][j], rings[i][j2], rings[i + 1][j2], rings[i + 1][j]);
    }
  }
  // носовой и хвостовой полюс
  const noseCol = spec.color(0, 0, 0);
  const nose = b.v(0, 0, -0.5 - (spec.jaws ? 0.035 : 0.012), noseCol, 0);
  for (let j = 0; j < M; j++) b.tri(nose, rings[1][j], rings[1][(j + 1) % M]);
  const tailCol = spec.color(1, 0, 0);
  const tailRoot = b.v(0, 0, 0.5, dark(tailCol, 0.9), 1);
  for (let j = 0; j < M; j++) b.tri(tailRoot, rings[N][(j + 1) % M], rings[N][j]);

  const finCol = col(spec.colors.fin);
  const fs = spec.finScale || 1;

  // спинной плавник
  {
    const t0 = 0.28, t1 = spec.shark ? 0.44 : 0.5;
    const [h0] = prof(t0), [h1] = prof(t1);
    const z0 = -0.5 + t0, z1 = -0.5 + t1;
    const tipH = (spec.shark ? 0.19 : 0.11) * fs;
    const a = b.v(0, h0 * 0.85, z0, finCol, t0);
    const bb = b.v(0, h1 * 0.85, z1, finCol, t1);
    const tip = b.v(0, h1 * 0.85 + tipH, z1 - 0.035, dark(finCol, 0.95), t1);
    const tipF = b.v(0, h1 * 0.85 + tipH * 0.35, z0 + 0.05, dark(finCol, 0.95), t0);
    b.tri(a, tipF, tip); b.tri(a, tip, bb);
    const a2 = b.v(0.004, h0 * 0.85, z0, finCol, t0);
    const b2 = b.v(0.004, h1 * 0.85, z1, finCol, t1);
    b.tri(a2, b2, tip); b.tri(a2, tip, tipF);
  }
  // анальный плавник
  {
    const t0 = 0.62, t1 = spec.shark ? 0.76 : 0.8;
    const [, w0] = prof(t0);
    const [, h0] = prof(t0), [h1] = prof(t1);
    const z0 = -0.5 + t0, z1 = -0.5 + t1;
    const a = b.v(0, -h0 * 0.85, z0, finCol, t0);
    const bb = b.v(0, -h1 * 0.85, z1, finCol, t1);
    const tip = b.v(0, -h1 * 0.85 - 0.08 * fs, z1 + 0.02, dark(finCol, 0.95), t1);
    b.tri(a, bb, tip);
    b.tri(a, tip, b.v(0.004, -h0 * 0.85, z0, finCol, t0));
  }
  // грудные плавники
  for (const side of [-1, 1]) {
    const t0 = 0.22;
    const [h0, w0] = prof(t0);
    const z0 = -0.5 + t0;
    const base = b.v(side * w0 * 0.9, -h0 * 0.15, z0, finCol, t0);
    const tip = b.v(side * (w0 + 0.09 * fs), -h0 * 0.5, z0 + 0.1, dark(finCol, 0.92), t0 + 0.06);
    const base2 = b.v(side * w0 * 0.9, -h0 * 0.5, z0 + 0.05, finCol, t0 + 0.03);
    b.tri(base, base2, tip);
    b.tri(base, tip, b.v(side * w0 * 0.75, -h0 * 0.05, z0 - 0.02, finCol, t0));
  }
  // хвост
  fishTail(b, spec, prof);

  // глаза
  for (const side of [-1, 1]) {
    const t0 = spec.hammer ? 0.055 : 0.1;
    const [h0, w0] = prof(t0);
    const z0 = -0.5 + t0;
    const ex = side * (spec.hammer ? w0 * spec.hammer * 0.92 : w0 * 0.82);
    const ey = h0 * 0.3;
    const r = spec.eye * 0.5;
    const white = col('#f7fbfd'), black = col('#1b2430');
    const c = b.v(ex, ey, z0, white, t0);
    const ring = [];
    const seg = quality === 'player' ? 8 : 6;
    for (let k = 0; k < seg; k++) {
      const a = (k / seg) * Math.PI * 2;
      ring.push(b.v(ex + side * r * 0.45, ey + Math.cos(a) * r, z0 + Math.sin(a) * r, white, t0));
    }
    for (let k = 0; k < seg; k++) b.tri(c, ring[k], ring[(k + 1) % seg]);
    const pupil = b.v(ex + side * r * 0.55, ey, z0, black, t0);
    const pr = [];
    for (let k = 0; k < seg; k++) {
      const a = (k / seg) * Math.PI * 2;
      pr.push(b.v(ex + side * r * 0.6, ey + Math.cos(a) * r * 0.55, z0 + Math.sin(a) * r * 0.55, black, t0));
    }
    for (let k = 0; k < seg; k++) b.tri(pupil, pr[k], pr[(k + 1) % seg]);
    b.v(ex + side * r * 0.7, ey + r * 0.25, z0 - r * 0.2, col('#ffffff'), t0);
  }
  return b.geometry();
}

// ---------- декорации ----------
function deformSphere(b, r, seg, rings, color, squash = 1, seed = 1, sp = 0.15) {
  const grid = [];
  for (let i = 0; i <= rings; i++) {
    const phi = (i / rings) * Math.PI;
    const row = [];
    for (let j = 0; j < seg; j++) {
      const th = (j / seg) * Math.PI * 2;
      const n = 0.75 + 0.5 * noise2(Math.cos(th) * 2 + seed, Math.sin(th) * 2 + phi * 2, seed);
      const x = Math.sin(phi) * Math.cos(th) * r * n;
      const y = Math.cos(phi) * r * n * squash;
      const z = Math.sin(phi) * Math.sin(th) * r * n;
      row.push(b.v(x, y, z, color, sp * (y / r + 0.5)));
    }
    grid.push(row);
  }
  for (let i = 0; i < rings; i++) {
    for (let j = 0; j < seg; j++) {
      const j2 = (j + 1) % seg;
      if (i === 0) b.tri(grid[0][0], grid[1][j], grid[1][j2]);
      else if (i === rings - 1) b.tri(grid[rings][0], grid[i][j2], grid[i][j]);
      else b.quad(grid[i][j], grid[i][j2], grid[i + 1][j2], grid[i + 1][j]);
    }
  }
}

function tubeGeo(b, pts, radii, sides, color, sp = 0.4) {
  const rings = [];
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    const prev = pts[Math.max(0, i - 1)], next = pts[Math.min(pts.length - 1, i + 1)];
    const dir = new THREE.Vector3(next[0] - prev[0], next[1] - prev[1], next[2] - prev[2]).normalize();
    const up = Math.abs(dir.y) > 0.9 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
    const nx = new THREE.Vector3().crossVectors(dir, up).normalize();
    const ny = new THREE.Vector3().crossVectors(nx, dir).normalize();
    const row = [];
    for (let j = 0; j < sides; j++) {
      const a = (j / sides) * Math.PI * 2;
      const x = p[0] + (nx.x * Math.cos(a) + ny.x * Math.sin(a)) * radii[i];
      const y = p[1] + (nx.y * Math.cos(a) + ny.y * Math.sin(a)) * radii[i];
      const z = p[2] + (nx.z * Math.cos(a) + ny.z * Math.sin(a)) * radii[i];
      row.push(b.v(x, y, z, color, sp));
    }
    rings.push(row);
  }
  for (let i = 0; i < rings.length - 1; i++) {
    for (let j = 0; j < sides; j++) {
      const j2 = (j + 1) % sides;
      b.quad(rings[i][j], rings[i][j2], rings[i + 1][j2], rings[i + 1][j]);
    }
  }
}

export const DECOR_TYPES = [
  { id: 'shell', size: [0.2, 0.45], biomes: ['reef', 'fields'], sway: 0, palette: ['#f2e2c8', '#f0c0b0', '#e8d0a0'] },
  { id: 'starfish', size: [0.2, 0.5], biomes: ['reef', 'fields'], sway: 0, palette: ['#ff7a3a', '#e8452f', '#a04cc8', '#ffa040', '#3a6adf'] },
  { id: 'urchin', size: [0.2, 0.45], biomes: ['reef', 'fields'], sway: 0, palette: ['#5a3070', '#6a3a80'] },
  { id: 'anemone', size: [0.3, 0.7], biomes: ['reef'], sway: 1, palette: ['#ff8fb8', '#ffb070', '#c890ff', '#ff6f7f', '#f4e6ff', '#7fe0c8', '#ffd36a'] },
  { id: 'sponge', size: [0.4, 1.1], biomes: ['reef', 'slope'], sway: 0.25, palette: ['#b070e0', '#ffb040', '#ff7050', '#e060a0', '#60b0e0', '#e8d050'] },
  { id: 'coralBranch', size: [0.5, 1.5], biomes: ['reef'], sway: 0.2, palette: ['#ff5f8f', '#ff86b5', '#ffcf3f', '#b58cff', '#ff8f4a', '#ff6a5a'] },
  { id: 'coralBrain', size: [0.5, 4.2], biomes: ['reef'], sway: 0, palette: ['#d9b36a', '#a8c070', '#c98ab0', '#e0a060', '#9fb0e0', '#e6c85a', '#b07fc0', '#8fc8a0'] },
  { id: 'coralFan', size: [0.6, 1.6], biomes: ['reef'], sway: 1, palette: ['#9a6cf0', '#ff6f7f', '#8fd96b', '#ffcf3f', '#5fd0e0'] },
  { id: 'coralBush', size: [1.0, 3.0], biomes: ['reef'], sway: 0.35, palette: ['#ff5f8f', '#8fd96b', '#b6e05a', '#ff8f4a', '#ffe066', '#b58cff'] },
  { id: 'seagrass', size: [0.3, 0.8], biomes: ['fields', 'reef'], sway: 1, palette: ['#4f9a3f', '#6aa84a', '#3f8a4a', '#5c9c36', '#74b04c'] },
  { id: 'kelp', size: [2, 8], biomes: ['slope'], sway: 1, palette: ['#7a8a2a', '#8a7a2a', '#6b7d30', '#9a8f3a'] },
  { id: 'rock', size: [0.3, 1.2], biomes: ['reef', 'fields', 'slope', 'ocean'], sway: 0, palette: ['#a39888', '#958c7e', '#8a847a', '#ab9f8a', '#9c917f'] },
  { id: 'rockAlgae', size: [0.5, 1.3], biomes: ['reef', 'slope'], sway: 0, palette: ['#9c917f', '#a8a08a', '#94998a'] },
  { id: 'bommie', size: [2, 6.5], biomes: ['reef'], sway: 0, palette: ['#c0909c', '#a88cb8', '#c0a088', '#9c8cb0', '#b89a9a'] },
  { id: 'pillar', size: [5, 10], biomes: ['slope', 'reef'], sway: 0, palette: ['#a8a294', '#9aa0a0', '#b0a898'] },
  { id: 'ledge', size: [3, 8], biomes: ['slope'], sway: 0, palette: ['#9aa0a8', '#a8a496', '#b0a89c'] },
  { id: 'arch', size: [4, 10], biomes: ['slope'], sway: 0, palette: ['#9aa0a8', '#a8a496'] },
  { id: 'wreck', size: [15, 30], biomes: ['fields', 'slope'], sway: 0, palette: ['#8a7c6a', '#9a8c78', '#7f8a86'] },
];

export function buildDecorPrototype(type, rnd) {
  const b = new MB();
  const pal = type.palette;
  const pick = () => col(pal[Math.floor(rnd() * pal.length)]);
  const c0 = pick();
  switch (type.id) {
    case 'shell': {
      const c = pick();
      for (let i = 0; i < 6; i++) {
        const a0 = (i / 6) * 1.6 - 0.8, a1 = ((i + 1) / 6) * 1.6 - 0.8;
        const v0 = b.v(Math.sin(a0) * 0.5, 0.12 * Math.cos(a0) + 0.05, Math.cos(a0) * 0.5, c, 0);
        const v1 = b.v(Math.sin(a1) * 0.5, 0.12 * Math.cos(a1) + 0.05, Math.cos(a1) * 0.5, c, 0);
        const o0 = b.v(Math.sin(a0) * 0.5, 0, Math.cos(a0) * 0.5, dark(c, 0.9), 0);
        const o1 = b.v(Math.sin(a1) * 0.5, 0, Math.cos(a1) * 0.5, dark(c, 0.9), 0);
        b.quad(v0, v1, o1, o0);
      }
      b.v(0, 0.14, 0, c, 0);
      break;
    }
    case 'starfish': {
      const c = pick(); const arms = 5; const ctr = b.v(0, 0.06, 0, dark(c, 0.9), 0);
      for (let i = 0; i < arms; i++) {
        const a = (i / arms) * Math.PI * 2;
        const a2 = ((i + 0.5) / arms) * Math.PI * 2;
        const tip = b.v(Math.cos(a) * 0.5, 0.02, Math.sin(a) * 0.5, c, 0);
        const m1 = b.v(Math.cos(a2) * 0.22, 0.05, Math.sin(a2) * 0.22, dark(c, 0.94), 0);
        const a3 = ((i - 0.5) / arms) * Math.PI * 2;
        const m2 = b.v(Math.cos(a3) * 0.22, 0.05, Math.sin(a3) * 0.22, dark(c, 0.94), 0);
        b.tri(ctr, m1, tip); b.tri(ctr, tip, m2);
      }
      break;
    }
    case 'urchin': {
      deformSphere(b, 0.32, 6, 4, dark(pick(), 0.7), 0.8, rnd() * 10, 0);
      const c = dark(pick(), 0.65);
      for (let i = 0; i < 10; i++) {
        const a = rnd() * Math.PI * 2, e = rnd() * 1.2 - 0.2;
        const x = Math.cos(a) * Math.cos(e), y = Math.sin(e), z = Math.sin(a) * Math.cos(e);
        const base = b.v(x * 0.28, y * 0.22, z * 0.28, c, 0);
        const tip = b.v(x * 0.55, y * 0.45, z * 0.55, c, 0);
        const p1 = b.v(x * 0.28 + 0.02, y * 0.22 + 0.02, z * 0.28, c, 0);
        b.tri(base, p1, tip);
      }
      break;
    }
    case 'anemone': {
      const c = pick();
      tubeGeo(b, [[0, 0, 0], [0, 0.2, 0], [0, 0.34, 0]], [0.16, 0.14, 0.13], 6, dark(c, 0.75), 0.1);
      for (let i = 0; i < 9; i++) {
        const a = (i / 9) * Math.PI * 2 + rnd() * 0.3;
        const r = 0.1 + rnd() * 0.06;
        const h = 0.25 + rnd() * 0.3;
        tubeGeo(b, [[Math.cos(a) * 0.08, 0.3, Math.sin(a) * 0.08], [Math.cos(a) * r, 0.3 + h * 0.6, Math.sin(a) * r], [Math.cos(a) * r * 1.3, 0.3 + h, Math.sin(a) * r * 1.3]], [0.022, 0.018, 0.008], 3, c, 0.8);
      }
      break;
    }
    case 'sponge': {
      const c = pick();
      const n = 2 + Math.floor(rnd() * 2);
      for (let i = 0; i < n; i++) {
        const x = (rnd() - 0.5) * 0.3, z = (rnd() - 0.5) * 0.3, h = 0.5 + rnd() * 0.5, r = 0.09 + rnd() * 0.05;
        tubeGeo(b, [[x, 0, z], [x * 1.1, h * 0.5, z * 1.1], [x * 1.2, h, z * 1.2]], [r, r * 0.95, r * 1.1], 5, mix(c, dark(c, 0.85), i / n), 0.3);
      }
      break;
    }
    case 'coralBranch': {
      const c = pick();
      const rec = (x, y, z, ang, len, rad, depth) => {
        const ex = x + Math.sin(ang) * len, ez = z + Math.cos(ang * 1.3) * len, ey = y + len * 0.9;
        tubeGeo(b, [[x, y, z], [(x + ex) / 2, (y + ey) / 2, (z + ez) / 2], [ex, ey, ez]], [rad, rad * 0.7, rad * 0.45], 4, mix(c, dark(c, 0.85), rnd() * 0.5), 0.2 + depth * 0.3);
        if (depth < 2) {
          rec(ex, ey, ez, ang + 0.6 + rnd() * 0.5, len * 0.62, rad * 0.6, depth + 1);
          rec(ex, ey, ez, ang - 0.5 - rnd() * 0.5, len * 0.58, rad * 0.6, depth + 1);
        }
      };
      rec(0, 0, 0, rnd() * 6.28, 0.45, 0.075, 0);
      break;
    }
    case 'coralBrain': {
      const c = pick();
      deformSphere(b, 0.5, 7, 5, c, 0.62, rnd() * 20, 0.1);
      break;
    }
    case 'coralFan': {
      const c = pick();
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * 1.9 - 0.95;
        const x0 = Math.sin(a) * 0.1, y0 = 0, x1 = Math.sin(a) * 0.5, y1 = 0.55 + Math.cos(a) * 0.12;
        const p0 = b.v(x0, y0, 0, dark(c, 0.9), 0.3);
        const p1 = b.v(x1, y1, 0.02 * i, c, 0.85);
        const p2 = b.v(x1 * 0.6, y1 * 0.8, -0.03, dark(c, 0.95), 0.7);
        b.tri(p0, p1, p2);
      }
      break;
    }
    case 'coralBush': {
      const c = pick();
      const n = 3 + Math.floor(rnd() * 3);
      for (let i = 0; i < n; i++) {
        const cx = (rnd() - 0.5) * 0.5, cz = (rnd() - 0.5) * 0.5, h = 0.4 + rnd() * 0.5;
        tubeGeo(b, [[cx, 0, cz], [cx * 1.4, h * 0.5, cz * 1.4], [cx * 1.8, h, cz * 1.8]], [0.09, 0.08, 0.05], 4, mix(c, dark(c, 0.8), rnd()), 0.3);
        for (let k = 0; k < 3; k++) {
          const a = rnd() * 6.28;
          tubeGeo(b, [[cx * 1.4, h * 0.6, cz * 1.4], [cx * 1.4 + Math.cos(a) * 0.15, h * 0.8, cz * 1.4 + Math.sin(a) * 0.15], [cx * 1.4 + Math.cos(a) * 0.25, h + 0.1, cz * 1.4 + Math.sin(a) * 0.25]], [0.045, 0.035, 0.02], 3, c, 0.6);
        }
      }
      break;
    }
    case 'seagrass': {
      const c = pick();
      const n = 5 + Math.floor(rnd() * 3);
      for (let i = 0; i < n; i++) {
        const a = (i / n) * 6.28 + rnd();
        const lean = 0.12 + rnd() * 0.2, h = 0.6 + rnd() * 0.5;
        const x0 = Math.cos(a) * 0.04, z0 = Math.sin(a) * 0.04;
        const p0 = b.v(x0, 0, z0, dark(c, 0.8), 0);
        const p1 = b.v(x0 + Math.cos(a) * lean * 0.5, h * 0.55, z0 + Math.sin(a) * lean * 0.5, c, 0.5);
        const p2 = b.v(x0 + Math.cos(a) * lean, h, z0 + Math.sin(a) * lean, c, 1);
        const w = 0.035;
        const q1 = b.v(x0 + Math.cos(a + 1.57) * w, 0, z0 + Math.sin(a + 1.57) * w, dark(c, 0.8), 0);
        const q2 = b.v(x0 + Math.cos(a) * lean * 0.5 + Math.cos(a + 1.57) * w * 0.7, h * 0.55, z0 + Math.sin(a) * lean * 0.5 + Math.sin(a + 1.57) * w * 0.7, c, 0.5);
        const q3 = b.v(x0 + Math.cos(a) * lean + Math.cos(a + 1.57) * w * 0.3, h, z0 + Math.sin(a) * lean + Math.sin(a + 1.57) * w * 0.3, c, 1);
        b.tri(p0, p2, q3); b.tri(p0, q3, q1); b.tri(q1, q2, q3); b.tri(p0, p1, p2);
      }
      break;
    }
    case 'kelp': {
      const c = pick();
      const n = 2 + Math.floor(rnd() * 2);
      for (let i = 0; i < n; i++) {
        const a = rnd() * 6.28, lean = 0.3 + rnd() * 0.4;
        const pts = [], rad = [];
        for (let k = 0; k <= 5; k++) {
          const f = k / 5;
          pts.push([Math.cos(a) * lean * f * f, f, Math.sin(a) * lean * f * f]);
          rad.push(0.07 * (1 - f * 0.6));
        }
        tubeGeo(b, pts, rad, 3, mix(c, dark(c, 0.8), rnd() * 0.6), 0.7);
        for (let k = 1; k < 5; k++) {
          const f = k / 5;
          const p0 = b.v(Math.cos(a) * lean * f * f, f, Math.sin(a) * lean * f * f, c, 0.7);
          const p1 = b.v(Math.cos(a) * lean * f * f + Math.cos(a + 1.6) * 0.22, f + 0.14, Math.sin(a) * lean * f * f + Math.sin(a + 1.6) * 0.22, c, 0.9);
          const p2 = b.v(Math.cos(a) * lean * f * f + Math.cos(a + 1.6) * 0.06, f + 0.3, Math.sin(a) * lean * f * f + Math.sin(a + 1.6) * 0.06, c, 0.9);
          b.tri(p0, p1, p2);
        }
      }
      break;
    }
    case 'rock': {
      const c = pick();
      deformSphere(b, 0.5, 6, 4, c, 0.55 + rnd() * 0.4, rnd() * 30, 0);
      break;
    }
    case 'rockAlgae': {
      const c = pick();
      deformSphere(b, 0.5, 6, 4, c, 0.6, rnd() * 30, 0);
      for (let i = 0; i < 4; i++) {
        const a = rnd() * 6.28;
        const p0 = b.v(Math.cos(a) * 0.3, 0.24, Math.sin(a) * 0.3, col('#7fae5e'), 0.6);
        const p1 = b.v(Math.cos(a) * 0.36, 0.34, Math.sin(a) * 0.36, col('#8fbe6a'), 0.9);
        const p2 = b.v(Math.cos(a + 0.4) * 0.3, 0.26, Math.sin(a + 0.4) * 0.3, col('#7fae5e'), 0.6);
        b.tri(p0, p1, p2);
      }
      break;
    }
    case 'bommie': {
      const c = pick();
      deformSphere(b, 0.5, 7, 5, c, 0.7, rnd() * 40, 0);
      const cc = col(['#ff86b5', '#ffcf3f', '#b58cff', '#8fd96b'][Math.floor(rnd() * 4)]);
      for (let i = 0; i < 6; i++) {
        const a = rnd() * 6.28, r = 0.3 + rnd() * 0.15;
        const p0 = b.v(Math.cos(a) * r, 0.32, Math.sin(a) * r, cc, 0.2);
        const p1 = b.v(Math.cos(a) * r * 1.2, 0.42, Math.sin(a) * r * 1.2, cc, 0.5);
        const p2 = b.v(Math.cos(a + 0.5) * r, 0.34, Math.sin(a + 0.5) * r, cc, 0.2);
        b.tri(p0, p1, p2);
      }
      break;
    }
    case 'pillar': {
      const c = pick();
      const pts = [[0, 0, 0], [0, 0.4, 0], [0.05, 0.75, 0.02], [0.02, 1, 0]];
      tubeGeo(b, pts, [0.22, 0.19, 0.17, 0.2], 7, c, 0);
      break;
    }
    case 'ledge': {
      const c = pick();
      const pts = [[0, 0, 0], [0, 0.35, 0.2], [0, 0.55, 0.55], [0, 0.6, 1.0]];
      for (let i = 0; i < 4; i++) {
        const p = pts[i];
        b.v(-0.5 + i * 0.05, p[1] * 0.5, p[2], c, 0);
        b.v(0.5 - i * 0.05, p[1] * 0.5, p[2], dark(c, 0.95), 0);
      }
      for (let i = 0; i < 3; i++) {
        const a0 = b.v(-0.5 + i * 0.05, pts[i][1] * 0.5, pts[i][2], c, 0);
        const a1 = b.v(0.5 - i * 0.05, pts[i][1] * 0.5, pts[i][2], c, 0);
        const b0 = b.v(-0.5 + (i + 1) * 0.05, pts[i + 1][1] * 0.5, pts[i + 1][2], c, 0);
        const b1 = b.v(0.5 - (i + 1) * 0.05, pts[i + 1][1] * 0.5, pts[i + 1][2], c, 0);
        b.quad(a0, a1, b1, b0);
      }
      break;
    }
    case 'arch': {
      const c = pick();
      const seg = 8, R = 0.5, tube = 0.07;
      for (let i = 0; i < seg; i++) {
        const a0 = Math.PI * (i / seg), a1 = Math.PI * ((i + 1) / seg);
        const p0 = [Math.cos(a0) * R, Math.sin(a0) * 1.2, 0];
        const p1 = [Math.cos(a1) * R, Math.sin(a1) * 1.2, 0];
        tubeGeo(b, [p0, [(p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2, 0], p1], [tube, tube, tube], 4, mix(c, dark(c, 0.9), i / seg), 0);
      }
      break;
    }
    case 'wreck': {
      const c = pick();
      // корпус
      const hull = new MB();
      for (let i = 0; i <= 6; i++) {
        const t = i / 6;
        const w = 0.5 * Math.sin(Math.PI * (0.15 + t * 0.8));
        const y = -0.15 + Math.sin(t * Math.PI) * 0.12;
        const cc = mix(c, dark(c, 0.85), rnd() * 0.4);
        b.v(-w, y + 0.12, -0.5 + t, cc, 0); b.v(w, y + 0.12, -0.5 + t, cc, 0);
        b.v(-w * 0.7, y - 0.1, -0.5 + t, dark(cc, 0.85), 0); b.v(w * 0.7, y - 0.1, -0.5 + t, dark(cc, 0.85), 0);
      }
      for (let i = 0; i < 6; i++) {
        const o = i * 4;
        b.quad(o, o + 4, o + 5, o + 1);
        b.quad(o + 2, o + 3, o + 7, o + 6);
        b.quad(o + 1, o + 5, o + 7, o + 3);
        b.quad(o, o + 2, o + 6, o + 4);
      }
      for (let i = 0; i < 4; i++) {
        const x = (rnd() - 0.5) * 0.5;
        tubeGeo(b, [[x, 0.1, -0.4 + i * 0.2], [x, 0.32, -0.4 + i * 0.2]], [0.02, 0.02], 3, dark(c, 0.8), 0);
      }
      break;
    }
    default:
      deformSphere(b, 0.4, 6, 4, c0, 0.7, 5, 0);
  }
  return b.geometry();
}

// ---------- суда, пловец, клетка, сундук ----------
function box(b, cx, cy, cz, sx, sy, sz, c) {
  const x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2;
  const v = [
    b.v(x0, y0, z0, c), b.v(x1, y0, z0, c), b.v(x1, y1, z0, c), b.v(x0, y1, z0, c),
    b.v(x0, y0, z1, c), b.v(x1, y0, z1, c), b.v(x1, y1, z1, c), b.v(x0, y1, z1, c),
  ];
  b.quad(v[0], v[1], v[2], v[3]);
  b.quad(v[5], v[4], v[7], v[6]);
  b.quad(v[4], v[0], v[3], v[7]);
  b.quad(v[1], v[5], v[6], v[2]);
  b.quad(v[3], v[2], v[6], v[7]);
  b.quad(v[4], v[5], v[1], v[0]);
}

export function buildShipGeometry(kind) {
  const b = new MB();
  const white = col('#eef4f6'), red = col('#d4553f'), darkc = col('#3d4a52'), grey = col('#a7b3ba');
  if (kind === 'boat') {
    // открытая лодка 6 м, нос по -Z
    const hull = col('#d9e2e4'), stripe = col('#c85a44');
    for (let i = 0; i <= 5; i++) {
      const t = i / 5;
      const w = 0.5 * Math.sin(Math.PI * (0.22 + t * 0.72));
      const yTop = 0.13 + 0.02 * Math.sin(t * 3), yBot = -0.12 + 0.06 * Math.sin(t * Math.PI);
      const z = -0.5 + t;
      b.v(-w, yBot, z, hull); b.v(w, yBot, z, hull);
      b.v(-w, yTop, z, stripe); b.v(w, yTop, z, stripe);
    }
    for (let i = 0; i < 5; i++) {
      const o = i * 4;
      b.quad(o, o + 4, o + 5, o + 1);
      b.quad(o + 2, o + 3, o + 7, o + 6);
      b.quad(o + 1, o + 5, o + 7, o + 3);
    }
    box(b, 0, 0.02, 0.15, 0.7, 0.04, 0.25, col('#c8b48c'));
    box(b, 0, 0.02, -0.15, 0.6, 0.04, 0.2, col('#c8b48c'));
    box(b, 0, 0.22, 0.1, 0.16, 0.3, 0.16, col('#e6d6b8')); // пассажир
    box(b, 0, 0.42, 0.1, 0.13, 0.13, 0.13, col('#f0c9a0'));
    box(b, 0, 0.3, 0.32, 0.35, 0.1, 0.3, col('#8fb6c4'));
  } else if (kind === 'yacht') {
    const hull = white;
    for (let i = 0; i <= 6; i++) {
      const t = i / 6;
      const w = 0.5 * Math.sin(Math.PI * (0.3 + t * 0.65)) * 0.95;
      const yTop = 0.12, yBot = -0.1 + 0.05 * Math.sin(t * 3.1);
      const z = -0.5 + t;
      b.v(-w, yBot, z, hull); b.v(w, yBot, z, hull);
      b.v(-w, yTop, z, white); b.v(w, yTop, z, white);
    }
    for (let i = 0; i < 6; i++) {
      const o = i * 4;
      b.quad(o, o + 4, o + 5, o + 1);
      b.quad(o + 2, o + 3, o + 7, o + 6);
      b.quad(o + 1, o + 5, o + 7, o + 3);
    }
    box(b, 0, 0.18, 0.05, 0.55, 0.18, 0.5, col('#f6fafb'));
    box(b, 0, 0.33, 0.08, 0.4, 0.14, 0.32, col('#3f6f92'));
    box(b, 0, 0.42, 0.08, 0.28, 0.06, 0.2, col('#f6fafb'));
    box(b, 0, 0.5, 0.1, 0.04, 0.4, 0.04, grey);
    box(b, 0, 0.1, -0.3, 0.5, 0.03, 0.2, col('#b9cdd6'));
  } else if (kind === 'cargo') {
    const hull = col('#3f5f74');
    for (let i = 0; i <= 6; i++) {
      const t = i / 6;
      const w = 0.5 * Math.sin(Math.PI * (0.42 + t * 0.55));
      const z = -0.5 + t;
      b.v(-w, -0.08, z, hull); b.v(w, -0.08, z, hull);
      b.v(-w, 0.08, z, col('#7d3f3f')); b.v(w, 0.08, z, col('#7d3f3f'));
    }
    for (let i = 0; i < 6; i++) {
      const o = i * 4;
      b.quad(o, o + 4, o + 5, o + 1);
      b.quad(o + 1, o + 5, o + 7, o + 3);
      b.quad(o, o + 2, o + 6, o + 4);
    }
    box(b, 0, 0.14, -0.34, 0.62, 0.14, 0.2, col('#e7edf0'));
    const cc = ['#d3553f', '#3f7fc8', '#e0b23a', '#4aa06a', '#9a5fc0'];
    for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++)
      box(b, (j - 0.5) * 0.28, 0.14, -0.12 + i * 0.26, 0.24, 0.12, 0.22, col(cc[(i * 2 + j) % 5]));
    box(b, 0, 0.38, 0.38, 0.3, 0.26, 0.18, col('#e7edf0'));
  } else if (kind === 'cruiser') {
    const hull = col('#8a949b');
    for (let i = 0; i <= 7; i++) {
      const t = i / 7;
      const w = 0.5 * Math.sin(Math.PI * (0.5 + t * 0.48));
      const z = -0.5 + t;
      b.v(-w, -0.07, z, col('#5f6b72')); b.v(w, -0.07, z, col('#5f6b72'));
      b.v(-w, 0.07, z, hull); b.v(w, 0.07, z, hull);
    }
    for (let i = 0; i < 7; i++) {
      const o = i * 4;
      b.quad(o, o + 4, o + 5, o + 1);
      b.quad(o + 1, o + 5, o + 7, o + 3);
      b.quad(o + 2, o + 3, o + 7, o + 6);
    }
    box(b, 0, 0.12, 0.0, 0.36, 0.1, 0.5, col('#9aa4aa'));
    box(b, 0, 0.24, -0.02, 0.22, 0.14, 0.22, col('#b6bfc4'));
    box(b, 0, 0.34, -0.02, 0.08, 0.08, 0.08, col('#d0d6d9'));
    box(b, 0, 0.3, 0.28, 0.03, 0.36, 0.03, grey);
    box(b, 0, 0.16, 0.22, 0.24, 0.1, 0.12, col('#7d878d'));
    // башни
    box(b, 0, 0.17, -0.2, 0.14, 0.07, 0.14, col('#6f7a80'));
    box(b, 0, 0.17, 0.16, 0.14, 0.07, 0.14, col('#6f7a80'));
    box(b, 0, 0.2, -0.28, 0.03, 0.03, 0.12, col('#59636a'));
    box(b, 0, 0.2, 0.08, 0.03, 0.03, 0.12, col('#59636a'));
  } else if (kind === 'swimmer') {
    const skin = col('#f0c9a0'), suit = col('#e2593f');
    box(b, 0, 0.42, 0, 0.12, 0.24, 0.08, suit);
    box(b, 0, 0.58, 0.0, 0.07, 0.07, 0.07, skin);
    box(b, 0, 0.4, 0.0, 0.15, 0.06, 0.1, col('#2f6fb0'));
  }
  return b.geometry();
}

export function buildChestGeometry() {
  const b = new MB();
  const wood = col('#a9752e'), wood2 = col('#8a5a20'), gold = col('#f2c14b');
  box(b, 0, 0.0, 0, 0.9, 0.5, 0.6, wood);
  box(b, 0, -0.26, 0, 0.94, 0.06, 0.64, wood2);
  box(b, 0, 0.06, 0, 0.92, 0.08, 0.62, gold);
  box(b, 0, 0.28, 0, 0.9, 0.1, 0.6, wood2);
  box(b, 0, 0.2, 0.31, 0.12, 0.16, 0.04, gold);
  return b.geometry();
}

export function buildCageGeometry() {
  const b = new MB();
  const metal = col('#8d959b'), rust = col('#b0743f');
  const n = 8;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const x = Math.cos(a) * 0.5, z = Math.sin(a) * 0.5;
    box(b, x, 0, z, 0.035, 1.0, 0.035, i % 3 === 0 ? rust : metal);
  }
  for (const y of [-0.45, 0.45]) {
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * Math.PI * 2, a1 = ((i + 1) / n) * Math.PI * 2;
      const x0 = Math.cos(a0) * 0.5, z0 = Math.sin(a0) * 0.5;
      const x1 = Math.cos(a1) * 0.5, z1 = Math.sin(a1) * 0.5;
      const p0 = b.v(x0, y, z0, metal), p1 = b.v(x1, y, z1, metal), p2 = b.v(x1, y + 0.05, z1, metal), p3 = b.v(x0, y + 0.05, z0, metal);
      b.quad(p0, p1, p2, p3);
    }
  }
  box(b, 0, 0.55, 0, 0.9, 0.1, 0.9, metal);
  box(b, 0, 0.62, 0, 0.06, 0.05, 0.06, rust);
  return b.geometry();
}

export function buildDiverGeometry() {
  const b = new MB();
  const suit = col('#2b3b46'), tank = col('#c9d3d8'), skin = col('#f0c9a0');
  box(b, 0, 0, 0, 0.16, 0.34, 0.12, suit);
  box(b, 0, 0.24, 0, 0.11, 0.11, 0.11, skin);
  box(b, 0, 0.24, -0.06, 0.12, 0.06, 0.06, col('#7fd0e8'));
  box(b, 0, 0.04, -0.11, 0.1, 0.26, 0.07, tank);
  box(b, -0.05, 0.02, -0.14, 0.03, 0.04, 0.04, col('#b9c2c7'));
  box(b, 0.05, 0.02, -0.14, 0.03, 0.04, 0.04, col('#b9c2c7'));
  box(b, 0, -0.24, 0.02, 0.12, 0.16, 0.1, suit);
  box(b, 0, 0.02, -0.2, 0.04, 0.04, 0.3, col('#5f6b72'));
  return b.geometry();
}
